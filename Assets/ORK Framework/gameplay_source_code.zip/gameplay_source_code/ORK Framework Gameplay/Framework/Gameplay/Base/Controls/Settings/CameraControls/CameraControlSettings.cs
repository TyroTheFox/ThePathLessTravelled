
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CameraControlSettings : BaseData
	{
		[ORKEditorHelp("Camera Control Type", "Select the camera control type:\n" +
			"- None: No control is added to the camera. " +
			"You have to add a camera control component to the camera in each scene by hand.\n" +
			"- Follow: The camera will follow behind the player.\n" +
			"- Look: The camera will look at the player.\n" +
			"- Mouse: The camera will follow the player. " +
			"Height and rotation can be changed by mouse/touch control.\n" +
			"- First Person: The camera is linked to the player (or a child object). " +
			"It can be moved horizontally/vertically (e.g. by mouse).\n" +
			"- Top Down Border: The camera follows the player until the he crosses a border. " +
			"The border is defined using a 'Camera Border' component with a 'Box Collider' in the scene.", "")]
		public CameraControlType type = CameraControlType.Follow;


		// follow
		[ORKEditorLayout("type", CameraControlType.Follow, endCheckGroup=true)]
		public FollowCameraSettings followControl = new FollowCameraSettings();


		// look
		[ORKEditorLayout("type", CameraControlType.Look, endCheckGroup=true)]
		public LookCameraSettings lookControl = new LookCameraSettings();


		// mouse
		[ORKEditorLayout("type", CameraControlType.Mouse, endCheckGroup=true)]
		public MouseCameraSettings mouseControl = new MouseCameraSettings();


		// first person
		[ORKEditorLayout("type", CameraControlType.FirstPerson, endCheckGroup=true)]
		public FirstPersonCameraSettings firstPersonControl = new FirstPersonCameraSettings();


		// top down border
		[ORKEditorLayout("type", CameraControlType.TopDownBorder, endCheckGroup=true)]
		public TopDownBorderCameraSettings topDownBorderControl = new TopDownBorderCameraSettings();


		// camera control target transition
		[ORKEditorInfo("Control Target Transition", "You can optionally use a transition when changing the camera control target.", "",
			endFoldout=true)]
		public CameraControlTargetTransition targetTransition = new CameraControlTargetTransition();


		// collision camera settings
		[ORKEditorInfo("Collision Camera Settings", "You can optionally use camera collision.\n" +
			"The collision camera uses raycasts to determine if an object is between the player and the screen.\n" +
			"If an object is found, the camera will be placed at the collision point.\n" +
			"The 'CollisionCamera' component is added to the scene's camera automatically, " +
			"unless the component is already attached " +
			"(i.e. you can add the component to scene cameras to use different settings).\n" +
			"The collision camera can also be used with custom controls and with events " +
			"(i.e. even when the camera controls are blocked).", "",
			endFoldout=true)]
		public CollisionCameraSettings collisionCamera = new CollisionCameraSettings();

		public CameraControlSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("onChild"))
			{
				// follow
				data.Get("onChild", ref this.followControl.onChild);
				data.Get("distanceFollow", ref this.followControl.distance);
				data.Get("heightFollow", ref this.followControl.height);
				data.Get("heightDampingFollow", ref this.followControl.heightDamping);
				data.Get("rotationDampingFollow", ref this.followControl.rotationDamping);

				// look
				data.Get("onChild", ref this.lookControl.onChild);
				data.Get("smooth", ref this.lookControl.smooth);
				data.Get("damping", ref this.lookControl.damping);

				// mouse
				data.Get("onChild", ref this.mouseControl.onChild);
				data.Get("distanceMouse", ref this.mouseControl.distance);
				data.Get("heightMouse", ref this.mouseControl.height);
				data.Get("minHeight", ref this.mouseControl.minHeight);
				data.Get("maxHeight", ref this.mouseControl.maxHeight);
				data.Get("heightDampingMouse", ref this.mouseControl.heightDamping);
				this.mouseControl.mouseTouch.SetData(data.GetFile("mouseTouch"));
				data.Get("allowRotation", ref this.mouseControl.allowRotation);
				data.Get("rotation", ref this.mouseControl.rotation);
				data.Get("rotationDampingMouse", ref this.mouseControl.rotationDamping);
				data.Get("rotationFactor", ref this.mouseControl.rotationFactor);
				data.Get("allowZoom", ref this.mouseControl.allowZoom);
				data.Get("zoomFactor", ref this.mouseControl.zoomFactor);
				data.Get("zoomAxis", ref this.mouseControl.zoomAxis.useAxis);
				data.Get("zoomAxisKey", ref this.mouseControl.zoomAxis.axisKey);
				data.Get("zoomPlusKey", ref this.mouseControl.zoomAxis.plusKey);
				data.Get("zoomMinusKey", ref this.mouseControl.zoomAxis.minusKey);
				data.Get("zoomKeyChange", ref this.mouseControl.zoomKeyChange);
				data.Get("mLimitChange", ref this.mouseControl.limitChange);

				// first person
				data.Get("onChild", ref this.firstPersonControl.onChild);
				float[] tmp = null;
				data.Get("offset", out tmp);
				if(tmp != null)
				{
					this.firstPersonControl.offset = ArrayHelper.GetVector3(tmp);
				}
				data.Get("verticalAxis", ref this.firstPersonControl.verticalAxis);
				data.Get("horizontalAxis", ref this.firstPersonControl.horizontalAxis); tmp = null;
				data.Get("sensitivity", out tmp);
				if(tmp != null)
				{
					this.firstPersonControl.sensitivity = ArrayHelper.GetVector2(tmp);
				}
				data.Get("lockCursor", ref this.firstPersonControl.lockCursor);

				// top down border
				data.Get("onChild", ref this.topDownBorderControl.onChild);
				data.Get("tdbInitialDamping", ref this.topDownBorderControl.initialDamping);
				data.Get("tdbPositionDamping", ref this.topDownBorderControl.positionDamping);
				tmp = null;
				data.Get("tdbPositionPadding", out tmp);
				if(tmp != null)
				{
					this.topDownBorderControl.positionPadding = ArrayHelper.GetVector4(tmp);
				}
				data.Get("tdbDistance", ref this.topDownBorderControl.distance);
				data.Get("tdbHeight", ref this.topDownBorderControl.height);
				data.Get("tdbHeightDamping", ref this.topDownBorderControl.heightDamping);
				data.Get("tdbRotation", ref this.topDownBorderControl.rotation);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsFollowControl()
		{
			return CameraControlType.Follow == this.type;
		}

		public bool IsLookControl()
		{
			return CameraControlType.Look == this.type;
		}

		public bool IsMouseControl()
		{
			return CameraControlType.Mouse == this.type;
		}

		public bool IsFirstPersonControl()
		{
			return CameraControlType.FirstPerson == this.type;
		}

		public bool IsTopDownBorderControl()
		{
			return CameraControlType.TopDownBorder == this.type;
		}


		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void AddCameraControl(GameObject camera)
		{
			ORK.GameControls.customControl.AddControlsToCamera(camera);

			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					this.followControl.Setup(camera);
				}
				else if(this.IsLookControl())
				{
					this.lookControl.Setup(camera);
				}
				else if(this.IsMouseControl())
				{
					this.mouseControl.Setup(camera);
				}
				else if(this.IsFirstPersonControl())
				{
					this.firstPersonControl.Setup(camera);
				}
				else if(this.IsTopDownBorderControl())
				{
					this.topDownBorderControl.Setup(camera);
				}
			}

			this.collisionCamera.Add(camera);
		}

		public void RemoveCameraControl(GameObject camera)
		{
			ORK.GameControls.customControl.RemoveControlsFromCamera(camera);

			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					SmoothFollow comp = camera.GetComponent<SmoothFollow>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsLookControl())
				{
					SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsMouseControl())
				{
					TouchCamera comp = camera.GetComponent<TouchCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsFirstPersonControl())
				{
					FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsTopDownBorderControl())
				{
					TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}
	}
}
