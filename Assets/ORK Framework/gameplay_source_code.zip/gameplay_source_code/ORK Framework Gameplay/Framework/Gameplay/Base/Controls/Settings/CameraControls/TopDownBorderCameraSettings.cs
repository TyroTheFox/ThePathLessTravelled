﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TopDownBorderCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";

		[ORKEditorHelp("Initial Damping", "Damping (position/height) will be used when first " +
			"adjusting the camera position to the player.\n" +
			"If disabled, the camera position will be set directly the first update.", "")]
		[ORKEditorInfo(separator=true)]
		public bool initialDamping = true;

		[ORKEditorHelp("Position Damping", "Used for smoother position changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float positionDamping = 0;

		[ORKEditorHelp("Position Padding", "Padding added to the border.\n" +
			"Left + X, top - Y, right - Z, bottom + W.\n" +
			"If the player steps outside the border left or right, the camera will stop following on the X-axis.\n" +
			"If the player steps outside the border to or bottom, the camera will stop following on the Z-axis.", "")]
		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);

		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		public float distance = 15.0f;

		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float height = 15.0f;

		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;

		[ORKEditorHelp("Distance Damping", "Used for smoother distance changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float distanceDamping = 2.0f;

		[ORKEditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float rotationDamping = 2.0f;

		[ORKEditorHelp("Rotation", "The rotation of the camera.\n" +
			"This defines the looking direction of the camera, e.g.:" +
			"- 0 looks north\n" +
			"- 90 looks east\n" +
			"- 180 looks south\n" +
			"- 270 (or -90) will look west", "")]
		public float rotation = 0;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;


		// rotation input
		[ORKEditorHelp("Use Rotation In", "Select when camera rotation can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[ORKEditorInfo("Rotation Settings", "The camera can optionally be rotated.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public UseableIn useRotationIn = UseableIn.None;

		[ORKEditorHelp("Remember Rotation", "The rotation will be remembered when changing between scenes.\n" +
			"The camera's rotation will be transfered over to the new scene.", "")]
		[ORKEditorLayout("useRotationIn", UseableIn.None, elseCheckGroup=true)]
		public bool rememberRotation = false;

		[ORKEditorHelp("Reset On Target Change", "The rotation is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetRotation = false;

		[ORKEditorHelp("Block On Target Change", "Rotating is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockRotation = false;

		[ORKEditorHelp("Rotation Input Change", "Define the rotation change (in degree) each time the rotate left/right keys are used.\n" +
			"The rotate right key will negate the defined value (e.g. -90 instead of 90).", "")]
		public float rotationInputChange = 90;

		[ORKEditorHelp("Use Delta Time", "The rotation input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool rotateDeltaTime = false;

		public AxisControl rotationAxis = new AxisControl();

		[ORKEditorHelp("Mouse/Touch Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the rotation change.\n" +
			"Set to negative numbers to invert rotation.", "")]
		public float rotationFactor = 1;

		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MouseTouchControl rotationMouseTouch = new MouseTouchControl(false, 1, false, 2, 1, MouseTouch.Move);


		// panning
		[ORKEditorHelp("Use Panning In", "Select when camera panning can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[ORKEditorInfo("Panning Settings", "The camera can optionally pan from the player.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public UseableIn usePanningIn = UseableIn.None;

		[ORKEditorHelp("Remember Panning", "The camera panning will be remembered when changing between scenes.\n" +
			"The camera's panning will be transfered over to the new scene.", "")]
		[ORKEditorLayout("usePanningIn", UseableIn.None, elseCheckGroup=true)]
		public bool rememberPanning = false;

		[ORKEditorHelp("Reset On Target Change", "The panning is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetPanning = false;

		[ORKEditorHelp("Block On Target Change", "Panning is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockPanning = false;

		[ORKEditorHelp("Panning Speed", "The speed used for panning in world units per second.", "")]
		public float panningSpeed = 10;

		[ORKEditorHelp("Horizontal Panning Key", "The input key used for horizontal panning.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalPanningKeyID = 0;

		[ORKEditorHelp("Vertical Panning Key", "The input key used for vertical panning.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalPanningKeyID = 0;

		[ORKEditorHelp("Center Key", "The input key used to center the camera back on the player.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int centerPanningKeyID = 0;

		[ORKEditorHelp("Limit Panning", "Limit the panning to a defined distance to the player.", "")]
		public bool limitPanning = true;

		[ORKEditorHelp("Distance Limit Field", "The distance to the player in world units the panning is limited to in the field.", "")]
		[ORKEditorLayout("limitPanning", true)]
		public float panningDistanceLimitField = 20;

		[ORKEditorHelp("Distance Limit Battle", "The distance to the player in world units the panning is limited to in battles.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float panningDistanceLimitBattle = 20;

		// screen edge panning
		[ORKEditorHelp("Use Edge Panning In", "Select when panning by moving the mouse cursor to the edge of the screen can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Screen Edge Panning")]
		public UseableIn useScreenEdgePanningIn = UseableIn.None;

		[ORKEditorHelp("UI Blocks Panning", "Screen edge panning is blocked when the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorLayout("useScreenEdgePanningIn", UseableIn.None, elseCheckGroup=true)]
		public bool screenEdgePanningUIBlock = false;

		[ORKEditorHelp("Edge Panning Speed", "The speed used for panning when using screen edge panning in world units per second.", "")]
		public float screenEdgePanningSpeed = 10;

		[ORKEditorHelp("Screen Edge Distance", "Distance to the edges of the screen to start panning.\n" +
			"Left = X, top = Y, right = Z, bottom = W.", "")]
		public Vector4 screenEdgeDistance = new Vector4(100, 100, 100, 100);

		[ORKEditorHelp("Distance In", "The distance is either defined in a fixed 'Value' or 'Percent' of the screen size.n" +
			"When using 'Percent', the screen width will be used for left/right panning, the screen height for top/bottom panning.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public ValueSetter screenEdgeValueSetter = ValueSetter.Value;


		// zooming
		[ORKEditorHelp("Use Zooming In", "Select when camera zooming can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[ORKEditorInfo("Zoom Settings", "The camera can optionally be zoomed in/out.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public UseableIn useZoomingIn = UseableIn.None;

		[ORKEditorHelp("Remember Zoom", "The camera zoom will be remembered when changing between scenes.\n" +
			"The camera's zoom will be transfered over to the new scene.", "")]
		[ORKEditorLayout("useZoomingIn", UseableIn.None, elseCheckGroup=true)]
		public bool rememberZoom = false;

		[ORKEditorHelp("Reset On Target Change", "The zoom is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetZoom = false;

		[ORKEditorHelp("Block On Target Change", "Zoom is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockZoom = false;

		[ORKEditorHelp("UI Blocks Zooming", "Zooming is blocked when the cursor is over a GUI box (e.g. a HUD).", "")]
		public bool zoomUIBlock = false;

		[ORKEditorHelp("Height Input Change", "Define the height change (in world units) per zoom input.\n" +
			"Use negative values to inverse the height changes.", "")]
		public float zoomHeightInputChange = 3;

		[ORKEditorHelp("Distance Input Change", "Define the distance change (in world units) per zoom input.\n" +
			"Use negative values to inverse the distance changes.", "")]
		public float zoomDistanceInputChange = 3;

		[ORKEditorHelp("Use Delta Time", "The zoom input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool zoomDeltaTime = false;

		public AxisControl zoomAxis = new AxisControl();

		// field height/distance
		[ORKEditorHelp("Min Height Field", "The minimum height that can be reached through zooming in the field.", "")]
		[ORKEditorInfo(separator=true, labelText="Field Height/Distance")]
		public float zoomMinHeightField = 5;

		[ORKEditorHelp("Max Height Field", "The maximum height that can be reached through zooming in the field.", "")]
		public float zoomMaxHeightField = 15;

		[ORKEditorHelp("Min Distance Field", "The minimum distance that can be reached through zooming in the field.", "")]
		[ORKEditorInfo(separator=true)]
		public float zoomMinDistanceField = 5;

		[ORKEditorHelp("Max Distance Field", "The maximum distance that can be reached through zooming in the field.", "")]
		public float zoomMaxDistanceField = 15;

		// battle height/distance
		[ORKEditorHelp("Min Height Battle", "The minimum height that can be reached through zooming in battle.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Height/Distance")]
		public float zoomMinHeightBattle = 5;

		[ORKEditorHelp("Max Height Battle", "The maximum height that can be reached through zooming in battle.", "")]
		public float zoomMaxHeightBattle = 15;

		[ORKEditorHelp("Min Distance Battle", "The minimum distance that can be reached through zooming in battle.", "")]
		[ORKEditorInfo(separator=true)]
		public float zoomMinDistanceBattle = 5;

		[ORKEditorHelp("Max Distance Battle", "The maximum distance that can be reached through zooming in battle.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float zoomMaxDistanceBattle = 15;


		// in-game
		private bool hasStoredValues = false;

		private float storedRotation = 0;

		private float storedInputRotation = 0;

		private float storedLastTargetRotation = 0;

		private Vector3 storedInputPanning = Vector3.zero;

		private Vector2 storedInputZoom = Vector2.zero;

		private float storedLastTargetDistance = 0;

		public TopDownBorderCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("rotateLeftKeyID"))
			{
				data.Get("rotateLeftKeyID", ref this.rotationAxis.plusKey);
				data.Get("rotateRightKeyID", ref this.rotationAxis.minusKey);
			}
			if(data.Contains<int>("zoomPlusKeyID"))
			{
				data.Get("zoomPlusKeyID", ref this.zoomAxis.plusKey);
				data.Get("zoomMinusKeyID", ref this.zoomAxis.minusKey);
			}
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<TopDownBorderCamera>();

					comp.onChild = this.onChild;
					comp.initialDamping = this.initialDamping;
					comp.positionDamping = this.positionDamping;
					comp.positionPadding = this.positionPadding;
					comp.distance = this.distance;
					comp.height = this.height;
					comp.heightDamping = this.heightDamping;
					comp.distanceDamping = this.distanceDamping;
					comp.rotationDamping = this.rotationDamping;
					comp.rotation = this.rotation;
					comp.horizontalPlane = this.horizontalPlane;

					// rotation
					comp.useRotationIn = this.useRotationIn;
					comp.rememberRotation = this.rememberRotation;
					comp.rotationInputChange = this.rotationInputChange;
					comp.rotationAxis = this.rotationAxis;
					comp.rotateDeltaTime = this.rotateDeltaTime;
					comp.rotationFactor = this.rotationFactor;
					comp.rotationMouseTouch = this.rotationMouseTouch;
					comp.cameraTargetChangeResetRotation = this.cameraTargetChangeResetRotation;
					comp.cameraTargetChangeBlockRotation = this.cameraTargetChangeBlockRotation;

					// panning
					comp.usePanningIn = this.usePanningIn;
					comp.rememberPanning = this.rememberPanning;
					comp.panningSpeed = this.panningSpeed;
					comp.horizontalPanningKeyID = this.horizontalPanningKeyID;
					comp.verticalPanningKeyID = this.verticalPanningKeyID;
					comp.centerPanningKeyID = this.centerPanningKeyID;
					comp.limitPanning = this.limitPanning;
					comp.panningDistanceLimitField = this.panningDistanceLimitField;
					comp.panningDistanceLimitBattle = this.panningDistanceLimitBattle;
					comp.cameraTargetChangeResetPanning = this.cameraTargetChangeResetPanning;
					comp.cameraTargetChangeBlockPanning = this.cameraTargetChangeBlockPanning;
					comp.useScreenEdgePanningIn = this.useScreenEdgePanningIn;
					comp.screenEdgePanningUIBlock = this.screenEdgePanningUIBlock;
					comp.screenEdgePanningSpeed = this.screenEdgePanningSpeed;
					comp.screenEdgeDistance = this.screenEdgeDistance;
					comp.screenEdgeValueSetter = this.screenEdgeValueSetter;

					// zooming
					comp.useZoomingIn = this.useZoomingIn;
					comp.rememberZoom = this.rememberZoom;
					comp.zoomUIBlock = this.zoomUIBlock;
					comp.zoomHeightInputChange = this.zoomHeightInputChange;
					comp.zoomDistanceInputChange = this.zoomDistanceInputChange;
					comp.zoomDeltaTime = this.zoomDeltaTime;
					comp.zoomAxis = this.zoomAxis;
					comp.zoomMinHeightField = this.zoomMinHeightField;
					comp.zoomMaxHeightField = this.zoomMaxHeightField;
					comp.zoomMinDistanceField = this.zoomMinDistanceField;
					comp.zoomMaxDistanceField = this.zoomMaxDistanceField;
					comp.zoomMinHeightBattle = this.zoomMinHeightBattle;
					comp.zoomMaxHeightBattle = this.zoomMaxHeightBattle;
					comp.zoomMinDistanceBattle = this.zoomMinDistanceBattle;
					comp.zoomMaxDistanceBattle = this.zoomMaxDistanceBattle;
					comp.cameraTargetChangeResetZoom = this.cameraTargetChangeResetZoom;
					comp.cameraTargetChangeBlockZoom = this.cameraTargetChangeBlockZoom;
				}

				if(comp != null)
				{
					ORK.Control.AddCameraControl(comp);
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreRotation(float rotation, float inputRotation, float lastTargetRotation)
		{
			this.hasStoredValues = true;
			this.storedRotation = rotation;
			this.storedInputRotation = inputRotation;
			this.storedLastTargetRotation = lastTargetRotation;
		}

		public void GetStoredRotation(ref float rotation, ref float inputRotation, ref float lastTargetRotation)
		{
			if(this.hasStoredValues)
			{
				rotation = this.storedRotation;
				inputRotation = this.storedInputRotation;
				lastTargetRotation = this.storedLastTargetRotation;
			}
		}

		public void StorePanning(Vector3 inputPanning)
		{
			this.hasStoredValues = true;
			this.storedInputPanning = inputPanning;
		}

		public void GetStoredPanning(ref Vector3 inputPanning)
		{
			if(this.hasStoredValues)
			{
				inputPanning = this.storedInputPanning;
			}
		}

		public void StoreZoom(Vector2 inputZoom, float lastTargetDistance)
		{
			this.hasStoredValues = true;
			this.storedInputZoom = inputZoom;
			this.storedLastTargetDistance = lastTargetDistance;
		}

		public void GetStoredZoom(ref Vector2 inputZoom, ref float lastTargetDistance)
		{
			if(this.hasStoredValues)
			{
				inputZoom = this.storedInputZoom;
				lastTargetDistance = this.storedLastTargetDistance;
			}
		}
	}
}
