﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FirstPersonCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";

		[ORKEditorHelp("Offset", "The offset added to the player/child position when placing the camera.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 offset = Vector3.zero;

		[ORKEditorHelp("Vertical Axis", "The key used for vertical camera changes.\n" +
			"Vertical camera changes will turn the camera along the X-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true)]
		public int verticalAxis = 2;

		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal camera changes.\n" +
			"Horizontal camera changes will turn the camera along the Y-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;

		[ORKEditorHelp("Sensitivity", "The sensitivity of the horizontal (X) and vertical (Y) camera moves.\n" +
			"Use negative numbers to invert control.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector2 sensitivity = new Vector2(15, 15);

		[ORKEditorHelp("Lock Cursor", "The mouse cursor will be locked when the camera control is enabled " +
			"(i.e. the mouse cursor is centered in the screen, hidden and can't be moved).", "")]
		[ORKEditorInfo(separator=true)]
		public bool lockCursor = false;

		public FirstPersonCameraSettings()
		{

		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<FirstPersonCamera>();

					comp.onChild = this.onChild;
					comp.offset = this.offset;
					comp.horizontalAxis = this.horizontalAxis;
					comp.verticalAxis = this.verticalAxis;
					comp.sensitivity = this.sensitivity;
					comp.lockCursor = this.lockCursor;
				}
				if(comp != null)
				{
					ORK.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
