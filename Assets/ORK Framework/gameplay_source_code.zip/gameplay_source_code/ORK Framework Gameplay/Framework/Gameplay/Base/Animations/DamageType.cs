
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this damage type.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and animation types of this damage type.", "",
			expandWidth=true)]
		public string name = "";


		// animation types
		// damage animation
		[ORKEditorHelp("Use Damage Animation", "Play a damage animation when a combatant takes damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Animation")]
		public bool useDamage = true;

		[ORKEditorHelp("Damage", "Select the animation type used for the damage animation " +
			"(i.e. when the combatant takes damage).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		[ORKEditorLayout("useDamage", true, endCheckGroup=true)]
		public int damageAnimationTypeID = 0;

		// critical damage animation
		[ORKEditorHelp("Use Critical Animation", "Play a critical damage animation when a combatant takes critical damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Critical Damage Animation")]
		public bool useCriticalDamage = true;

		[ORKEditorHelp("Critical Damage", "Select the animation type used for the critical damage animation " +
			"(i.e. when the combatant takes critical damage).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		[ORKEditorLayout("useCriticalDamage", true, endCheckGroup=true)]
		public int criticalDamageAnimationTypeID = 0;


		// evade animation
		[ORKEditorHelp("Use Evade Animation", "Play an evade animation when a combatant evades an attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Evade Animation")]
		public bool useEvade = true;

		[ORKEditorHelp("Evade", "Select the animation type used for the evade animation " +
			"(i.e. when the combatant evades an attack).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		[ORKEditorLayout("useEvade", true, endCheckGroup=true)]
		public int evadeAnimationTypeID = 0;


		// block animation
		[ORKEditorHelp("Use Block Animation", "Play a block animation when a combatant blocks an attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Block Animation")]
		public bool useBlock = false;

		[ORKEditorHelp("Block", "Select the animation type used for the block animation " +
			"(i.e. when the combatant blocks an attack).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType, endFoldout=true)]
		[ORKEditorLayout("useBlock", true, endCheckGroup=true)]
		public int blockAnimationTypeID = 0;

		public DamageType()
		{

		}

		public DamageType(string name)
		{
			this.name = name;
		}

		public DamageType(string name, int damageID, int criticalID, int evadeID)
		{
			this.name = name;
			this.damageAnimationTypeID = damageID;
			this.criticalDamageAnimationTypeID = criticalID;
			this.evadeAnimationTypeID = evadeID;
		}
	}
}
