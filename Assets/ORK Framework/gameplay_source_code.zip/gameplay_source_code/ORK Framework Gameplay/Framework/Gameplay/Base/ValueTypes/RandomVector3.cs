
using UnityEngine;

namespace ORKFramework
{
	public class RandomVector3 : BaseData
	{
		[ORKEditorHelp("Minimum Random", "The minimum random value (inclusive).", "")]
		public Vector3 min = Vector3.zero;
		
		[ORKEditorHelp("Maximum Random", "The maximum random value (inclusive).", "")]
		public Vector3 max = Vector3.zero;
		
		public RandomVector3()
		{
			
		}
		
		public Vector3 GetValue()
		{
			return new Vector3(
				UnityWrapper.Range(this.min.x, this.max.x),
				UnityWrapper.Range(this.min.y, this.max.y),
				UnityWrapper.Range(this.min.z, this.max.z));
		}
	}
}
