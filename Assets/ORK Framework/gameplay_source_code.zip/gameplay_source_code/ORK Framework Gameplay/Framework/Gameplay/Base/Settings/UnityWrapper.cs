﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework
{
	public class UnityWrapper : BaseData
	{
		// instantiate game objects
		[ORKEditorHelp("Use Custom Instantiate", "Use custom functions for instantiating game objects.\n" +
			"Requires 2 static functions, one for spawning a prefab without position and rotation, " +
			"one for spawning a prefab with position and rotation.", "")]
		[ORKEditorInfo(labelText="Instantiate Game Object")]
		public bool useCustomInstantiate = false;

		[ORKEditorHelp("Class Name", "The name of the class that contains the instantiation functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("useCustomInstantiate", true)]
		public string instantiateClassName = "";

		[ORKEditorHelp("Instantiate Function", "The name of the static function that is used to instantiate a game object.\n" +
			"Requires a 'GameObject' (the prefab) as the parameter.\n" +
			"Requires to return a 'GameObject' type.\n\n" +
			"public static GameObject Instantiate(GameObject prefab)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string instantiateFunctionName = "";

		[ORKEditorHelp("Instantiate Function 2", "The name of the static function that is used to instantiate a game object.\n" +
			"Requires a 'GameObject' (the prefab), a 'Vector3' (position) and a 'Quaternion' (rotation) as parameters.\n" +
			"Requires to return a 'GameObject' type.\n\n" +
			"public static GameObject Instantiate(GameObject prefab, Vector3 position, Quaternion rotation)", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string instantiateFunctionName2 = "";


		// destroy game object
		[ORKEditorHelp("Use Custom Destroy", "Use custom functions for destroying game objects.\n" +
			"Requires 2 static functions, one for destroying a game object, " +
			"one for destroying a game object after some time.", "")]
		[ORKEditorInfo(separator=true, labelText="Destroy Game Object")]
		public bool useCustomDestroy = false;

		[ORKEditorHelp("Class Name", "The name of the class that contains the destroy functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("useCustomDestroy", true)]
		public string destroyClassName = "";

		[ORKEditorHelp("Destroy Function", "The name of the static function that is used to destroy a game object.\n" +
			"Requires a 'GameObject' (the object that should be destroyed) as the parameter.\n\n" +
			"public static void Destroy(GameObject gameObject)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string destroyFunctionName = "";

		[ORKEditorHelp("Destroy Function 2", "The name of the static function that is used to destroy a game object.\n" +
			"Requires a 'GameObject' (the object that should be destroyed) and a " +
			"'float' (the time until the object is destroyed) as parameters.\n\n" +
			"public static void Destroy(GameObject gameObject, float time)", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string destroyFunctionName2 = "";


		// load scene
		[ORKEditorHelp("Use Custom Load Scene", "Use custom functions for loading scenes.\n" +
			"Requires 2 static functions, one for loading a scene, " +
			"one for loading a scene asynchronously.", "")]
		[ORKEditorInfo(separator=true, labelText="Load Scene")]
		public bool useCustomLoadScene = false;

		[ORKEditorHelp("Class Name", "The name of the class that contains the destroy functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("useCustomLoadScene", true)]
		public string loadSceneClassName = "";

		[ORKEditorHelp("Load Scene Function", "The name of the static function that is used to load a scene.\n" +
			"Requires a 'string' (scene name) and a 'LoadSceneMode' as parameters.\n\n" +
			"public static void LoadScene(string sceneName, LoadSceneMode mode)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string loadSceneFunctionName = "";

		[ORKEditorHelp("Load Scene Async Function", "The name of the static function that is used to load a scene asynchronously.\n" +
			"Requires a 'string' (scene name) and a 'LoadSceneMode' as parameters.\n\n" +
			"public static void LoadSceneAsync(string sceneName, LoadSceneMode mode)", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string loadSceneAsyncFunctionName = "";


		// random number
		[ORKEditorHelp("Use Custom Random Number", "Use custom functions for random number generation.\n" +
			"Requires 2 static functions, one for generating a random int, one for generating a random float.", "")]
		[ORKEditorInfo(separator=true, labelText="Random Number Generation")]
		public bool useCustomRandomNumber = false;

		[ORKEditorHelp("Class Name", "The name of the class that contains the destroy functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("useCustomRandomNumber", true)]
		public string randomNumberClassName = "";

		[ORKEditorHelp("Random Int Function", "The name of the static function that is used to generate a random int value.\n" +
			"Requires two 'int' (min, max) parameters and must return an 'int' value.\n\n" +
			"public static int Random(int min, int max)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string randomNumberIntFunctionName = "";

		[ORKEditorHelp("Random Float Function", "The name of the static function that is used to generate a random float value.\n" +
			"Requires two 'float' (min, max) parameters and must return a 'float' value.\n\n" +
			"public static float Random(float min, float max", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string randomNumberFloatFunctionName = "";


		// in-game
		private MethodInfo instantiate;

		private MethodInfo instantiate2;

		private MethodInfo destroy;

		private MethodInfo destroy2;

		private MethodInfo loadScene;

		private MethodInfo loadSceneAsync;

		private MethodInfo randomInt;

		private MethodInfo randomFloat;

		public UnityWrapper()
		{

		}

		private void Init()
		{
			// instantiate
			if(this.useCustomInstantiate &&
				this.instantiate == null)
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(this.instantiateClassName);
				if(classType != null)
				{
					this.instantiate = classType.GetMethod(this.instantiateFunctionName,
						new System.Type[] { typeof(GameObject) });
					this.instantiate2 = classType.GetMethod(this.instantiateFunctionName2,
						new System.Type[] { typeof(GameObject), typeof(Vector3), typeof(Quaternion) });
				}
			}

			// destroy
			if(this.useCustomDestroy &&
				this.destroy == null)
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(this.destroyClassName);
				if(classType != null)
				{
					this.destroy = classType.GetMethod(this.destroyFunctionName,
						new System.Type[] { typeof(GameObject) });
					this.destroy2 = classType.GetMethod(this.destroyFunctionName2,
						new System.Type[] { typeof(GameObject), typeof(float) });
				}
			}

			// load scene
			if(this.useCustomLoadScene &&
				this.loadScene == null)
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(this.loadSceneClassName);
				if(classType != null)
				{
					this.loadScene = classType.GetMethod(this.loadSceneFunctionName,
						new System.Type[] { typeof(string), typeof(LoadSceneMode) });
					this.loadSceneAsync = classType.GetMethod(this.loadSceneAsyncFunctionName,
						new System.Type[] { typeof(string), typeof(LoadSceneMode) });
				}
			}

			// random number
			if(this.useCustomRandomNumber &&
				this.randomInt == null)
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(this.randomNumberClassName);
				if(classType != null)
				{
					this.randomInt = classType.GetMethod(this.randomNumberIntFunctionName,
						new System.Type[] { typeof(int), typeof(int) });
					this.randomFloat = classType.GetMethod(this.randomNumberFloatFunctionName,
						new System.Type[] { typeof(float), typeof(float) });
				}
			}
		}


		/*
		============================================================================
		Instantiate functions
		============================================================================
		*/
		public static GameObject Instantiate(GameObject prefab)
		{
			return ORK.GameSettings.unityWrapper.InstantiateGameObject(prefab);
		}

		public GameObject InstantiateGameObject(GameObject prefab)
		{
			if(this.useCustomInstantiate)
			{
				if(this.instantiate == null)
				{
					this.Init();
				}
				if(this.instantiate != null)
				{
					try
					{
						object value = this.instantiate.Invoke(null, new object[] { prefab });
						if(value is GameObject)
						{
							return (GameObject)value;
						}
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.instantiateClassName + "): " +
							this.instantiateFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
					}
				}
			}
			return GameObject.Instantiate(prefab);
		}

		public static GameObject Instantiate(GameObject prefab, Vector3 position, Quaternion rotation)
		{
			return ORK.GameSettings.unityWrapper.InstantiateGameObject(prefab, position, rotation);
		}

		public GameObject InstantiateGameObject(GameObject prefab, Vector3 position, Quaternion rotation)
		{
			if(this.useCustomInstantiate)
			{
				if(this.instantiate2 == null)
				{
					this.Init();
				}
				if(this.instantiate2 != null)
				{
					try
					{
						object value = this.instantiate2.Invoke(null, new object[] { prefab, position, rotation });
						if(value is GameObject)
						{
							return (GameObject)value;
						}
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.instantiateClassName + "): " +
							this.instantiateFunctionName2 + "\n" + ex.Message + "\n" + ex.StackTrace);
					}
				}
			}
			return GameObject.Instantiate(prefab, position, rotation);
		}


		/*
		============================================================================
		Destroy functions
		============================================================================
		*/
		public static void Destroy(GameObject gameObject)
		{
			ORK.GameSettings.unityWrapper.DestroyGameObject(gameObject);
		}

		public void DestroyGameObject(GameObject gameObject)
		{
			if(this.useCustomDestroy)
			{
				if(this.destroy == null)
				{
					this.Init();
				}
				if(this.destroy != null)
				{
					try
					{
						this.destroy.Invoke(null, new object[] { gameObject });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.destroyClassName + "): " +
							this.destroyFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						GameObject.Destroy(gameObject);
					}
				}
			}
			else
			{
				GameObject.Destroy(gameObject);
			}
		}

		public static void Destroy(GameObject gameObject, float time)
		{
			ORK.GameSettings.unityWrapper.DestroyGameObject(gameObject, time);
		}

		public void DestroyGameObject(GameObject gameObject, float time)
		{
			if(this.useCustomDestroy)
			{
				if(this.destroy2 == null)
				{
					this.Init();
				}
				if(this.destroy2 != null)
				{
					try
					{
						this.destroy2.Invoke(null, new object[] { gameObject, time });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.destroyClassName + "): " +
							this.destroyFunctionName2 + "\n" + ex.Message + "\n" + ex.StackTrace);
						GameObject.Destroy(gameObject, time);
					}
				}
			}
			else
			{
				GameObject.Destroy(gameObject, time);
			}
		}


		/*
		============================================================================
		Load scene functions
		============================================================================
		*/
		public static void LoadScene(string sceneName, LoadSceneMode mode)
		{
			ORK.GameSettings.unityWrapper.CallLoadScene(sceneName, mode);
		}

		public void CallLoadScene(string sceneName, LoadSceneMode mode)
		{
			if(this.useCustomLoadScene)
			{
				if(this.loadScene == null)
				{
					this.Init();
				}
				if(this.loadScene != null)
				{
					try
					{
						this.loadScene.Invoke(null, new object[] { sceneName, mode });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.loadSceneClassName + "): " +
							this.loadSceneFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						SceneManager.LoadScene(sceneName, mode);
					}
				}
			}
			else
			{
				SceneManager.LoadScene(sceneName, mode);
			}
		}

		public static void LoadSceneAsync(string sceneName, LoadSceneMode mode)
		{
			ORK.GameSettings.unityWrapper.CallLoadSceneAsync(sceneName, mode);
		}

		public void CallLoadSceneAsync(string sceneName, LoadSceneMode mode)
		{
			if(this.useCustomLoadScene)
			{
				if(this.loadSceneAsync == null)
				{
					this.Init();
				}
				if(this.loadSceneAsync != null)
				{
					try
					{
						this.loadSceneAsync.Invoke(null, new object[] { sceneName, mode });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.loadSceneClassName + "): " +
							this.loadSceneAsyncFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						SceneManager.LoadSceneAsync(sceneName, mode);
					}
				}
			}
			else
			{
				SceneManager.LoadSceneAsync(sceneName, mode);
			}
		}


		/*
		============================================================================
		Random number functions
		============================================================================
		*/
		public static int Range(int min, int max)
		{
			return ORK.GameSettings.unityWrapper.CallRange(min, max);
		}

		public int CallRange(int min, int max)
		{
			if(this.useCustomRandomNumber)
			{
				if(this.randomInt == null)
				{
					this.Init();
				}
				if(this.randomInt != null)
				{
					try
					{
						return (int)this.randomInt.Invoke(null, new object[] { min, max });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.randomNumberClassName + "): " +
							this.randomNumberIntFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
					}
				}
			}
			return Random.Range(min, max);
		}

		public static float Range(float min, float max)
		{
			return ORK.GameSettings.unityWrapper.CallRange(min, max);
		}

		public float CallRange(float min, float max)
		{
			if(this.useCustomRandomNumber)
			{
				if(this.randomFloat == null)
				{
					this.Init();
				}
				if(this.randomFloat != null)
				{
					try
					{
						return (float)this.randomFloat.Invoke(null, new object[] { min, max });
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Method call failed (" + this.randomNumberClassName + "): " +
							this.randomNumberFloatFunctionName + "\n" + ex.Message + "\n" + ex.StackTrace);
					}
				}
			}
			return Random.Range(min, max);
		}
	}
}
