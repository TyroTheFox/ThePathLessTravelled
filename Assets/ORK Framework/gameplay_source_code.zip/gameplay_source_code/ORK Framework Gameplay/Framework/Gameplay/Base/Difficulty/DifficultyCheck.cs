﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DifficultyCheck : BaseData
	{
		[ORKEditorHelp("Difficulty", "Select the difficulty to check for.", "")]
		[ORKEditorInfo(ORKDataType.Difficulty)]
		public int id = 0;

		[ORKEditorHelp("Check Type", "Checks if the game's difficulty is equal, not equal, less or greater than the selected difficulty.\n" +
			"The difficulty (level) is determined by the ID of the difficulty, e.g. ID 0 is less than ID 1, ID 3 is greater than ID 2.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;

		public DifficultyCheck()
		{

		}

		public bool Check()
		{
			return ValueHelper.CheckValue(ORK.Game.Difficulty, this.id, this.check);
		}

		public override string ToString()
		{
			return this.check.ToString() + " " + ORK.Difficulties.GetName(this.id);
		}
	}
}
