﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CursorChange : BaseData
	{
		[ORKEditorHelp("Cursor Texture", "Select the texture that will be used as mouse cursor.", "")]
		public Texture2D texture;

		[ORKEditorHelp("Cursor Hotspot", "The offset from the top left corner of the texture to use as the target point.\n" +
				"Must be within the bounds of the cursor.", "")]
		[ORKEditorLayout("texture", null, elseCheckGroup=true)]
		public Vector2 hotSpot = Vector2.zero;

		[ORKEditorHelp("Cursor Mode", "Select the mode of the cursor:\n" +
			"- Auto: Use hardware cursors on supported platforms.\n" +
			"- Force Software: Force the use of software cursors.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public CursorMode cursorMode = CursorMode.Auto;

		public CursorChange()
		{

		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public bool SetCursor()
		{
			if(this.texture != null)
			{
				Cursor.SetCursor(this.texture, this.hotSpot, this.cursorMode);
				return true;
			}
			return false;
		}

		public void ResetCursor()
		{
			if(this.texture != null)
			{
				Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
			}
		}
	}
}
