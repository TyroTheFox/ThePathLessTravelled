
using UnityEngine;
using ORKFramework;
using System.Collections;

namespace ORKFramework.Animations
{
	public class LegacyAnimation : LegacyAnimationBase
	{
		[ORKEditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Stop Fade (s)", "The time in seconds used to fade out before stopping the animation.\n" +
			"Set to 0 if the animation should stop immediately.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float stopFade = 0.1f;
		
		public LegacyAnimation()
		{
			
		}
		
		public void Stop(Animation animation, Combatant user)
		{
			if(animation[this.name] != null)
			{
				if(this.stopFade > 0 && user.Object.Component != null && animation.IsPlaying(this.name))
				{
					user.Animations.LegacyFade(this.name, this.stopFade);
				}
				else
				{
					user.Animations.LegacyRemoveStop(this.name);
					animation.Stop(this.name);
				}
			}
		}
	}
}
