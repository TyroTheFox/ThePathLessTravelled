
using UnityEngine;
using UnityEngineInternal;
using ORKFramework;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Animations
{
	public class MecanimAnimation : BaseData
	{
		[ORKEditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int typeID = 0;

		[ORKEditorHelp("State Name", "The name of the animation state (without layer name).", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Layer Index", "The index of the AnimatorController layer the animation state is on.", "")]
		public int layer = 0;

		// set layer weight
		[ORKEditorHelp("Set Layer Weight", "Set the current weight of the animation's layer before playing the animation.", "")]
		public bool setLayerWeight = false;

		[ORKEditorHelp("Layer Weight", "The current weight the layer will be set to.", "")]
		[ORKEditorLayout("setLayerWeight", true, endCheckGroup=true)]
		public float layerWeight = 1;

		// duration for wait in events
		[ORKEditorHelp("Duration (s)", "The duration of the state's animation clip.\n" +
			"This value is used in game events to set the wait time for animation steps.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float duration = 0;


		// play
		[ORKEditorHelp("Play Mode", "Select how the state will be played:\n" +
			"- None: The state will not be played directly, only through setting parameters.\n" +
			"- Play: Uses Animator.Play to play the state directly.\n" +
			"- Cross Fade: Uses Animator.CrossFade to fade between the current and this state.", "")]
		[ORKEditorInfo(separator=true)]
		public MecanimPlayMode playMode = MecanimPlayMode.None;

		[ORKEditorHelp("Transition Duration", "The duration of the transition from the source state (current state) to this state.\n" +
			"defined in normalized time (between 0 and 1) of the source state.", "")]
		[ORKEditorLayout("playMode", MecanimPlayMode.CrossFade, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float transitionDuration = 0.1f;

		[ORKEditorHelp("Set Normalized Time", "Set the normalized time of the animation state when playing it.", "")]
		[ORKEditorLayout("playMode", MecanimPlayMode.None, elseCheckGroup=true)]
		public bool setNormalizedTime = false;

		[ORKEditorHelp("Normalized Time", "The normalized time the animation state will be set to when playing (0-1).\n" +
			"E.g. 1 will be the end of the animation, 0.5 in the middle of the animation.", "")]
		[ORKEditorLayout("setNormalizedTime", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float normalizedTime = 0;

		// parameters
		[ORKEditorArray(false, "Add Parameter (Play)", "Adds a parameter that will be set when the animation is played.", "",
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Set Parameter (Play)", "The parameter will be set to the defined value when the animation is played.", ""
		})]
		public MecanimParameter[] playParameter = new MecanimParameter[0];


		// stop parameters
		[ORKEditorArray(false, "Add Parameter (Stop)", "Adds a parameter that will be set when the animation is stopped.", "",
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {"Set Parameter (Stop)", "The parameter will be set to the defined value when the animation is stopped.\n" +
				"This is used when a combatant animation is stopped using the event system.", ""})]
		public MecanimParameter[] stopParameter = new MecanimParameter[0];

		public MecanimAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("usePlay"))
			{
				bool tmp = false;
				data.Get("usePlay", ref tmp);
				if(tmp)
				{
					this.playMode = MecanimPlayMode.Play;
				}
			}
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public AnimInfo Play(Animator animator, bool randomTime)
		{
			if(this.setLayerWeight)
			{
				animator.SetLayerWeight(this.layer, this.layerWeight);
			}

			for(int i = 0; i < this.playParameter.Length; i++)
			{
				this.playParameter[i].Set(animator);
			}

			if(MecanimPlayMode.Play == this.playMode)
			{
				if(randomTime)
				{
					animator.Play(this.name, this.layer, UnityWrapper.Range(0.0f, 1.0f));
				}
				else if(this.setNormalizedTime)
				{
					animator.Play(this.name, this.layer, this.normalizedTime);
				}
				else
				{
					animator.Play(this.name, this.layer);
				}
			}
			else if(MecanimPlayMode.CrossFade == this.playMode)
			{
				if(randomTime)
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer, UnityWrapper.Range(0.0f, 1.0f));
				}
				else if(this.setNormalizedTime)
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer, this.normalizedTime);
				}
				else
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer);
				}
			}

			return new AnimInfo(AnimationSystem.Mecanim, animator.GetLayerName(this.layer) + "." + this.name, this.duration);
		}

		public void Stop(Animator animator)
		{
			for(int i = 0; i < this.stopParameter.Length; i++)
			{
				this.stopParameter[i].Set(animator);
			}
		}
	}
}
