
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class PlayAudioCombatant : BaseData
	{
		[ORKEditorHelp("Use Sound Type", "The combatant's defined sound of a selected sound type will be used.", "")]
		public bool useSoundType = false;

		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;

		[ORKEditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public AudioClip audioClip;

		[ORKEditorHelp("Volume", "The volume used to play the audio clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		public PlayAudioCombatant()
		{

		}

		public void Play(Combatant combatant)
		{
			if(combatant != null)
			{
				AudioClip clip = this.useSoundType ?
					combatant.Animations.GetAudioClip(this.soundTypeID) :
					clip = this.audioClip;

				if(clip != null)
				{
					AudioSource source = combatant.Object.GetAudioSource();

					if(source != null)
					{
						source.PlayOneShot(clip, this.volume * ORK.Game.SoundVolume);
					}
				}
			}
		}
	}
}
