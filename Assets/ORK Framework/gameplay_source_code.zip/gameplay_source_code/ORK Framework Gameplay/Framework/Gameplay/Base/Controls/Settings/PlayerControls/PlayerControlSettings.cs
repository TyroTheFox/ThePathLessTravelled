
using UnityEngine;
using UnityEngine.AI;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PlayerControlSettings : BaseData
	{
		// TODO: 2D controls
		[ORKEditorHelp("Player Control Type", "Select the player control type:\n" +
			"- None: No control is added, you have to add your own components to the player prefab.\n" +
			"- Button: Keyboard/joystick controls are used to move the player.\n" +
			"- Mouse: Mouse/touch controls are used to move the player.\n" +
			"Depending on your control type selection you'll have different settings available.\n\n" +
			"The 'Mouse' control uses raycasting to set the move target.\n" +
			"You can set up areas that block clicks/touches for player movement - " +
			"add a NoClickMove component to a game object with a collider. " +
			"The bounds are used to check if the clicked/touched position is a valid move position. " +
			"The Y-position of the game object is ignored for the check.", "")]
		public PlayerControlType type = PlayerControlType.Button;


		// overall controls
		[ORKEditorHelp("SC Destroy Player", "Destroy the player's game object before changing scenes.\n" +
			"Enabling this option can help with some custom player controls setting that set the player's game object to don't destroy on load.", "")]
		[ORKEditorInfo(separator=true)]
		public bool sceneChangeDestroyPlayer = false;

		[ORKEditorHelp("Move Dead", "You can control the player, even when the player combatant is dead.", "")]
		public bool moveDead = true;

		[ORKEditorHelp("Use Combatant Speed", "The speed of the player combatant according to its move speed settings is used.", "")]
		public bool useSpeed = true;

		[ORKEditorHelp("Speed", "The speed in world units per second the player will move at.", "")]
		[ORKEditorLayout("useSpeedDefault", false, endCheckGroup=true)]
		[ORKEditorLimit(0.1f, false)]
		public float runSpeed = 8.0f;

		[ORKEditorHelp("Gravity", "The gravity used when moving.\n" +
			"Use negative numbers.", "")]
		public float gravity = Physics.gravity.y;

		[ORKEditorHelp("Speed Smoothing", "Used to have a smooth transition between no movement and full move speed.", "")]
		public float speedSmoothing = 10.0f;


		// button controller
		[ORKEditorLayout("type", PlayerControlType.Button, endCheckGroup=true)]
		public ButtonPlayerControlSettings buttonController = new ButtonPlayerControlSettings();


		// mouse controller
		[ORKEditorLayout("type", PlayerControlType.Mouse, endCheckGroup=true)]
		public MousePlayerControlSettings mouseController = new MousePlayerControlSettings();

		public PlayerControlSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<float>("rotateSpeed"))
			{
				this.buttonController.SetData(data);
				this.mouseController.SetData(data);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsButtonControl()
		{
			return PlayerControlType.Button == this.type;
		}

		public bool IsMouseControl()
		{
			return PlayerControlType.Mouse == this.type;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			ORK.GameControls.interaction.AddInteractionController(player);
			ORK.GameControls.customControl.AddControlsToPlayer(player);

			if(this.IsButtonControl())
			{
				this.buttonController.AddPlayerControl(player);
			}
			else if(this.IsMouseControl())
			{
				this.mouseController.AddPlayerControl(player);
			}
		}

		public void RemovePlayerControl(GameObject player)
		{
			ORK.GameControls.interaction.RemoveInteractionController(player);
			ORK.GameControls.customControl.RemoveControlsFromPlayer(player);

			if(this.IsButtonControl())
			{
				this.buttonController.RemovePlayerControl(player);
			}
			else if(this.IsMouseControl())
			{
				this.mouseController.RemovePlayerControl(player);
			}
		}
	}
}
