﻿
using UnityEngine;
using UnityEngine.AI;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MousePlayerControlSettings : BaseData
	{
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "",
			endFoldout=true, separatorForce=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl(true);


		// raycast
		[ORKEditorHelp("Raycast Distance", "The distance the raycast will check to set the move target.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float raycastDistance = 100.0f;

		[ORKEditorHelp("Layer Mask", "Select the layers the raycast will check.", "")]
		public LayerMask layerMask = -1;


		// cursor
		[ORKEditorHelp("Cursor Prefab", "The prefab used to display a cursor on the position of the move target.\n" +
			"Select none if no cursor should be displayed.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject cursorObject;

		[ORKEditorHelp("Cursor Respawn", "Respawn the cursor each time it is placed.\n" +
			"Depending on your prefab (e.g. using particle effects) it might be " +
			"neccessary to spawn a new instance of your cursor prefab.\n" +
			"If disabled, ORK will reuse the spawned prefab instance while it's available (e.g. during movement).", "")]
		public bool cursorRespawn = false;

		[ORKEditorHelp("Cursor Offset", "The offset added to the move target position for displaying the cursor.", "")]
		public Vector3 cursorOffset = Vector3.zero;

		[ORKEditorHelp("Min. Move Distance", "The minimum distance to the move target the player must reach to stop moving.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.1f, false)]
		public float minimumMoveDistance = 0.2f;

		[ORKEditorHelp("Ignore Height Distance", "The distance along the height axis will be ignored for the " +
			"minimum move distance check.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = true;

		[ORKEditorHelp("Move Type", "Select how the player will be moved:\n" +
			"- Character Controller: Moves using a 'CharacterController' component.\n" +
			"- Event Mover: Uses the ORK event mover to move the transform using linear interpolation.\n" +
			"- NavMesh Agent: Moves using a 'NavMeshAgent' component.", "")]
		public MouseControlMoveType mouseMoveType = MouseControlMoveType.CharacterController;


		// nav mesh
		[ORKEditorHelp("Sample Distance", "Maximum distance used to find the nearest point on the NavMesh to the clicked position.", "")]
		[ORKEditorLayout("mouseMoveType", MouseControlMoveType.NavMeshAgent)]
		public float navMeshSampleDistance = 1.0f;

		[ORKEditorHelp("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
			"Defaults to all areas (-1).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int navMeshSampleAreaMask = NavMesh.AllAreas;


		// secure move
		[ORKEditorHelp("Secure Move", "The movement will end if the player couldn't move for a defined amount of time.\n" +
			"If disabled, the player will move until it reached it's target.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("mouseMoveType", MouseControlMoveType.EventMover, elseCheckGroup=true)]
		public bool secureMove = false;

		[ORKEditorHelp("Secure Time (s)", "The time in seconds the player mustn't move to stop the movement.", "")]
		[ORKEditorLayout("secureMove", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.1f, false)]
		public float secureTime = 0.5f;

		[ORKEditorHelp("Remove Cursor No Control", "The cursor will automatically be removed when " +
			"control is not possible (e.g. when an event starts).", "")]
		public bool autoRemoveCursor = true;

		[ORKEditorHelp("Remove Cursor Target", "The cursor will automatically be removed when " +
			"the target destination is reached (or movement stopped).", "")]
		public bool autoRemoveCursorTarget = true;

		[ORKEditorHelp("Auto Stop Move", "The move will be stopped when e.g. an event starts.", "")]
		public bool autoStopMove = true;

		public MousePlayerControlSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useEventMover"))
			{
				bool tmp = false;
				data.Get("useEventMover", ref tmp);
				if(tmp)
				{
					this.mouseMoveType = MouseControlMoveType.EventMover;
				}
			}
			if(data.Contains<bool>("ignoreYDistance"))
			{
				data.Get("ignoreYDistance", ref this.ignoreHeightDistance);
			}
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			MousePlayerController comp = player.GetComponent<MousePlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<MousePlayerController>();
			}
			comp.mouseTouch.SetData(this.mouseTouch.GetData());
			comp.moveDead = ORK.GameControls.playerControl.moveDead;
			comp.useCharacterSpeed = ORK.GameControls.playerControl.useSpeed;
			comp.runSpeed = ORK.GameControls.playerControl.runSpeed;
			comp.gravity = ORK.GameControls.playerControl.gravity;
			comp.speedSmoothing = ORK.GameControls.playerControl.speedSmoothing;
			comp.raycastDistance = this.raycastDistance;
			comp.layerMask = this.layerMask;
			comp.cursorOffset = this.cursorOffset;
			comp.minimumMoveDistance = this.minimumMoveDistance;
			comp.ignoreHeightDistance = this.ignoreHeightDistance;
			comp.mouseMoveType = this.mouseMoveType;
			comp.navMeshSampleDistance = this.navMeshSampleDistance;
			comp.navMeshSampleAreaMask = this.navMeshSampleAreaMask;
			comp.autoRemoveCursor = this.autoRemoveCursor;
			comp.autoRemoveCursorTarget = this.autoRemoveCursorTarget;
			comp.autoStopMove = this.autoStopMove;
			comp.secureMove = this.secureMove;
			comp.secureTime = this.secureTime;

			comp.cursorObject = this.cursorObject;
			comp.cursorRespawn = this.cursorRespawn;

			ORK.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			MousePlayerController comp = player.GetComponent<MousePlayerController>();
			if(comp != null)
			{
				ORK.Control.RemovePlayerControl(comp);
				comp.ClearCursor();
				GameObject.Destroy(comp);
			}
		}
	}
}
