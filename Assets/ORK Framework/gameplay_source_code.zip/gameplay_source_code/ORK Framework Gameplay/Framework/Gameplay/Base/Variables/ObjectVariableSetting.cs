
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ObjectVariableSetting : BaseData
	{
		[ORKEditorHelp("Local Variables", "Use the object variables as local variables.\n" +
			"Local variables are only available as long as the game object exists " +
			"and aren't shared between multiple objects.", "")]
		public bool isLocal = false;

		[ORKEditorHelp("Object ID", "Define the object ID used by the 'Object Variables' component.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("isLocal", false)]
		public string objectVariablesID = "";


		// default variables
		[ORKEditorHelp("Always Initialize", "The object variables will be initialized each time " +
			"the component is created.\n" +
			"If disabled, the object variables are only initialized the first time " +
			"(i.e. if the variable handler doesn't exist yet).", "")]
		[ORKEditorInfo(separatorForce=true, labelTextForce="Initial Variables")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool alwaysInitialize = false;

		public VariableSetter initialVariables = new VariableSetter();

		public ObjectVariableSetting()
		{

		}

		public ObjectVariablesComponent AddComponent(GameObject gameObject)
		{
			ObjectVariablesComponent comp = gameObject.GetComponent<ObjectVariablesComponent>();
			if(comp == null ||
				comp.localVariables != this.isLocal ||
				(!this.isLocal && comp.objectID != this.objectVariablesID))
			{
				comp = gameObject.AddComponent<ObjectVariablesComponent>();
				comp.localVariables = this.isLocal;
				comp.objectID = this.objectVariablesID;
			}

			if(this.alwaysInitialize || !comp.HandlerExists())
			{
				this.initialVariables.SetVariables(comp.GetHandler());
			}

			return comp;
		}

		public VariableHandler GetHandler()
		{
			VariableHandler handler = null;
			if(this.isLocal ||
				this.objectVariablesID == "")
			{
				handler = new VariableHandler(false);
				this.initialVariables.SetVariables(handler);
			}
			else
			{
				if(ORK.Game.Scene.ObjectVariablesExist(this.objectVariablesID))
				{
					handler = ORK.Game.Scene.GetObjectVariables(this.objectVariablesID);
					if(this.alwaysInitialize)
					{
						this.initialVariables.SetVariables(handler);
					}
				}
				else
				{
					handler = ORK.Game.Scene.GetObjectVariables(this.objectVariablesID);
					this.initialVariables.SetVariables(handler);
				}
			}
			return handler;
		}
	}
}
