﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ButtonPlayerControlSettings : BaseData
	{
		[ORKEditorHelp("Rotation Speed", "The speed used when rotating the character.", "")]
		public float rotateSpeed = 500.0f;

		[ORKEditorHelp("First Person", "The axis keys will be used for first person control, " +
			"i.e. vertical axis will move forward/backward, vertical axis will move sidewards.", "")]
		[ORKEditorInfo(separator=true)]
		public bool firstPerson = false;

		[ORKEditorHelp("Use Camera Direction", "The axis keys will move the player based on the camera view.\n" +
			"If disabled, the vertical axis key moves the player forward/backward, the horizontal axis key turns the player.", "")]
		public bool useCamDirection = true;

		[ORKEditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the movement 45 degrees to the camera view.", "")]
		[ORKEditorLayout("useCamDirection", true, endCheckGroup=true)]
		public float camDirectionOffset = 0;

		[ORKEditorHelp("Vertical Axis", "The key used for vertical control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true)]
		public int verticalAxis = 2;

		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;


		// jump
		[ORKEditorHelp("Use Jump", "The player can jump.", "")]
		[ORKEditorInfo("Jump Settings", "Optionally allow the player to jump.", "")]
		public bool useJump = false;

		[ORKEditorHelp("Jump Key", "The key used to jump.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useJump", true)]
		public int jumpKey = 0;

		[ORKEditorHelp("Jump Duration (s)", "The time in seconds the player will move up before falling down again.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float jumpDuration = 0.5f;

		[ORKEditorHelp("Jump Delay (s)", "The time inseconds before the actual jump will be performed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float jumpDelay = 0;

		[ORKEditorHelp("Jump Speed", "The vertical speed in world units used when jumping.\n" +
			"Use positive numbers.", "")]
		public float jumpSpeed = -Physics.gravity.y;

		[ORKEditorHelp("Jump Interpolation", "The interpolation used for changing the jump speed over time.\n" +
			"E.g. EaseOutQuad will decrease the jump speed at the end of the jump.", "")]
		public EaseType jumpInterpolation = EaseType.EaseOutQuad;

		[ORKEditorHelp("In Air Modifier", "This setting effects the move speed while in the air.\n" +
			"A value below 1 will decrease the speed, above will increase.", "")]
		public float inAirModifier = 0.5f;

		[ORKEditorHelp("Maximum Ground Angle", "The maximum angle of the ground to allow jumping.\n" +
			"Use this setting to prevent jumping from steep slopes.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float jumpMaxGroundAngle = 45;


		// sprint
		[ORKEditorHelp("Use Sprint", "The player can sprint.", "")]
		[ORKEditorInfo("Sprint Settings", "Optionally allow the player to sprint.", "")]
		public bool useSprint = false;

		[ORKEditorHelp("Sprint Key", "The key used to sprint.\n" +
			"The key must be held down to sprint - select handling type Hold in the settings of the key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useSprint", true)]
		public int sprintKey = 0;

		[ORKEditorHelp("Sprint Factor", "The players move speed will be multiplied with this number when sprinting.\n" +
			"E.g. 2 will double the move speed.", "")]
		public float sprintFactor = 2.0f;

		[ORKEditorHelp("Use Energy", "Sprinting will consume energy.", "")]
		public bool useEnergy = false;

		[ORKEditorInfo("Maximum Energy", "The maximum sprint energy.", "", endFoldout=true)]
		[ORKEditorLayout("useEnergy", true, autoInit=true)]
		public FloatValue maxEnergy;

		[ORKEditorInfo("Energy Consume", "The energy consumed per second when sprinting.", "", endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue energyConsume;

		[ORKEditorInfo("Energy Regeneration", "The energy regenerated per second.", "", endFoldout=true, endFolds=2)]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true, endGroups=2)]
		public FloatValue energyRegeneration;

		public ButtonPlayerControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<ButtonPlayerController>();
			}
			comp.moveDead = ORK.GameControls.playerControl.moveDead;
			comp.useCharacterSpeed = ORK.GameControls.playerControl.useSpeed;
			comp.runSpeed = ORK.GameControls.playerControl.runSpeed;
			comp.gravity = ORK.GameControls.playerControl.gravity;
			comp.speedSmoothing = ORK.GameControls.playerControl.speedSmoothing;
			comp.rotateSpeed = this.rotateSpeed;
			comp.verticalAxis = this.verticalAxis;
			comp.horizontalAxis = this.horizontalAxis;
			comp.useJump = this.useJump;
			comp.jumpKey = this.jumpKey;
			comp.jumpDuration = this.jumpDuration;
			comp.jumpDelay = this.jumpDelay;
			comp.jumpSpeed = this.jumpSpeed;
			comp.jumpInterpolation = this.jumpInterpolation;
			comp.inAirModifier = this.inAirModifier;
			comp.jumpMaxGroundAngle = this.jumpMaxGroundAngle;
			comp.useSprint = this.useSprint;
			comp.sprintKey = this.sprintKey;
			comp.sprintFactor = this.sprintFactor;
			comp.useEnergy = this.useEnergy;
			comp.maxEnergy = this.maxEnergy;
			comp.energyConsume = this.energyConsume;
			comp.energyRegeneration = this.energyRegeneration;
			comp.firstPerson = this.firstPerson;
			comp.useCamDirection = this.useCamDirection;
			comp.camDirectionOffset = this.camDirectionOffset;

			ORK.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
			if(comp != null)
			{
				ORK.Control.RemovePlayerControl(comp);
				GameObject.Destroy(comp);
			}
		}
	}
}
