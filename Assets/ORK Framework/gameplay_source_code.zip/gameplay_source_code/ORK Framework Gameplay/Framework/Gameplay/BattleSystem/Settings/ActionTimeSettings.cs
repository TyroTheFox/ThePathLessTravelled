﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionTimeSettings : BaseData
	{
		[ORKEditorHelp("Use Action Time", "Enables using action time.\n" +
			"Action time allows a combatant to select actions within a defined amount of time during their turn.\n" +
			"When the time is up, the combatant's turn ends (finishing already performing or fired actions).", "")]
		public bool useActionTime = false;

		[ORKEditorHelp("Keep Unused Time", "The action time will be added to the combatant's previous action time, " +
			"i.e. unused time can be saved for the next turn.\n" +
			"If disabled, the action time will be set each turn, i.e. unused time will be lost.", "")]
		[ORKEditorLayout("useActionTime", true)]
		public bool keepUnusedTime = false;

		[ORKEditorHelp("Decrease Time", "Select when the action time will decrease:\n" +
			 "- Always: Always during a combatant's turn.\n" +
			"- While Choosing: While the combatant is selecting an action.\n" +
			"- While In Action: While the combatant is performing an action.", "")]
		public ActionTimeDecreaseType decreaseType = ActionTimeDecreaseType.Always;


		// actions per turn
		[ORKEditorInfo("Default Action Time", "The time in seconds a combatant is able to select actions in.\n" +
			"When the combatant's action time reaches 0, the combatant is no longer able to select new actions until the next turn.\n" +
			"Each combatant can individually override the default action time.", "",
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public FloatValue actionTime = new FloatValue(1);

		public ActionTimeSettings()
		{

		}

		public void SetActionTime(Combatant combatant)
		{
			if(combatant != null &&
				this.useActionTime)
			{
				combatant.Battle.InitActionTime(
					combatant.Setting.ownActionTime ?
						combatant.Setting.actionTime.GetValue(combatant, combatant) :
						this.actionTime.GetValue(combatant, combatant),
					this.keepUnusedTime);
			}
		}

		public bool CanDecrease(Combatant combatant)
		{
			if(this.useActionTime &&
				combatant != null &&
				combatant.Battle.ActionTimeRunning &&
				combatant.Battle.ActionTime > 0)
			{
				if(ActionTimeDecreaseType.Always == this.decreaseType)
				{
					return true;
				}
				else if(ActionTimeDecreaseType.WhileChoosing == this.decreaseType)
				{
					return combatant.Actions.IsChoosing;
				}
				else if(ActionTimeDecreaseType.WhileInAction == this.decreaseType)
				{
					return combatant.Actions.ActionState == CombatantActionState.InAction;
				}
			}
			return false;
		}
	}
}
