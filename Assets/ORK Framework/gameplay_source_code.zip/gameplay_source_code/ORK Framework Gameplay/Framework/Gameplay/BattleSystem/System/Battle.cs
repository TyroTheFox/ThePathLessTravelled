
using UnityEngine;
using System.Collections.Generic;
using ORKFramework.Behaviours;
using ORKFramework.Events;

namespace ORKFramework
{
	public class Battle : ISaveData
	{
		private static Battle instance;

		private BattleSystemSettings settings;

		private BattleSystemType type = BattleSystemType.TurnBased;


		// battle
		private BaseBattle currentSystem;

		private int currentTurn = 0;

		private bool inBattle = false;

		private bool battleEnd = false;

		private bool canEscape = true;

		private int maxPlayerBattleGroupSize = 0;


		// battle advantages
		private GroupAdvantageType battleAdvantage = GroupAdvantageType.None;


		// actions
		private BattleActionHandler actionHandler = new BattleActionHandler();


		// gains
		private List<IShortcut> loot = new List<IShortcut>();

		private Dictionary<int, List<ExperienceLoot>> expGains = new Dictionary<int, List<ExperienceLoot>>();

		private Dictionary<int, int> normalSVGains = new Dictionary<int, int>();


		// battle arena
		private BattleComponent battleArena;

		private BattleGridComponent grid;

		private GameObject groupCenter;

		private GameObject combatantCenter;


		// real time areas
		private int realTimeAreaCount = 0;


		// battle menu
		private List<Combatant> choosingCombatants = new List<Combatant>();

		private List<Combatant> menuUser = new List<Combatant>();

		private int menuIndex = 0;

		private Combatant cursorOverCombatant = null;

		private int targetSelectionActive = 0;


		// outcome
		private BattleOutcome waitForLastActionOutcome = BattleOutcome.None;


		// enemy counting
		private Dictionary<int, int> enemyCounter = new Dictionary<int, int>();

		private Dictionary<int, int> enemyCounter2 = new Dictionary<int, int>();


		// events
		private Notify startBattleHandler;
		public event Notify BattleStarted
		{
			add { this.startBattleHandler += value; }
			remove { this.startBattleHandler -= value; }
		}

		private Notify systemChangedHandler;
		public event Notify SystemChanged
		{
			add { this.systemChangedHandler += value; }
			remove { this.systemChangedHandler -= value; }
		}

		private Notify endBattleHandler;
		public event Notify BattleEnded
		{
			add { this.endBattleHandler += value; }
			remove { this.endBattleHandler -= value; }
		}

		private CombatantChanged enemyKilledHandler;
		public event CombatantChanged EnemyKilled
		{
			add { this.enemyKilledHandler += value; }
			remove { this.enemyKilledHandler -= value; }
		}

		private CombatantChanged latestTurnHandler;
		public event CombatantChanged LatestTurn
		{
			add { this.latestTurnHandler += value; }
			remove { this.latestTurnHandler -= value; }
		}

		private CombatantChanged combatantJoinedHandler;
		public event CombatantChanged CombatantJoined
		{
			add { this.combatantJoinedHandler += value; }
			remove { this.combatantJoinedHandler -= value; }
		}

		private CombatantChanged combatantRemovedHandler;
		public event CombatantChanged CombatantRemoved
		{
			add { this.combatantRemovedHandler += value; }
			remove { this.combatantRemovedHandler -= value; }
		}


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private Battle()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of Battle!");
			}
			else
			{
				instance = this;
			}
			this.SetSettings();
		}

		public static Battle Instance()
		{
			if(instance == null)
			{
				new Battle();
			}
			return instance;
		}

		public void SetSettings()
		{
			this.settings = ORK.BattleSystem;
			BattleGridHelper.SetInstance(this.settings);
		}

		public BattleSystemSettings Settings
		{
			get { return this.settings; }
		}


		/*
		============================================================================
		Clearing functions
		============================================================================
		*/
		public void ClearBattle()
		{
			ORK.Control.ClearInBattle();
			this.EndBattle();
			this.Actions.StopActiveActions();
			ORK.Game.Combatants.EndBattle();
			this.currentSystem = null;
			this.currentTurn = 0;
			this.battleEnd = false;
			this.waitForLastActionOutcome = BattleOutcome.None;
			this.battleArena = null;
			this.Grid = null;
			this.cursorOverCombatant = null;
		}


		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public int Turn
		{
			get { return this.currentTurn; }
			set { this.currentTurn = value; }
		}

		public BattleActionHandler Actions
		{
			get { return this.actionHandler; }
		}

		public BaseBattle System
		{
			get { return this.currentSystem; }
		}

		public bool InBattle
		{
			get { return this.inBattle; }
		}

		public bool BattleEnd
		{
			get { return this.battleEnd; }
		}

		public bool WaitForLastAction
		{
			get { return BattleOutcome.None != this.waitForLastActionOutcome; }
		}

		public bool CanEscape
		{
			get { return this.canEscape; }
		}

		public bool CanCounter
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.CanCounter;
				}
				else
				{
					return ORK.Battle.Settings.fieldMode.canCounter;
				}
			}
		}

		public bool DeathImmediately
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.DeathImmediately;
				}
				else
				{
					return true;
				}
			}
		}

		public bool MenuBlockAutoAttack
		{
			get
			{
				return this.currentSystem != null &&
					this.currentSystem.MenuBlockAutoAttack;
			}
		}

		public bool CanAutoAttack
		{
			get
			{
				return this.currentSystem != null &&
					this.inBattle && !this.battleEnd &&
					this.currentSystem.CanAutoAttack;
			}
		}

		public bool DefendFirst
		{
			get
			{
				return this.currentSystem != null &&
					this.currentSystem.DefendFirst;
			}
		}

		public BattleComponent BattleArena
		{
			get { return this.battleArena; }
		}

		public BattleGridComponent Grid
		{
			get { return this.grid; }
			set
			{
				if(this.grid != value)
				{
					this.grid = value;
					if(this.grid != null)
					{
						this.grid.Init();
					}
				}
			}
		}

		public int RealTimeAreaCount
		{
			get { return this.realTimeAreaCount; }
			set
			{
				this.realTimeAreaCount = value;
				if(this.realTimeAreaCount < 0)
				{
					this.realTimeAreaCount = 0;
				}

				// end battle
				if(this.IsBattleRunning() &&
					this.realTimeAreaCount == 0)
				{
					this.EndBattle();

					if(ORK.Battle.Settings.realTime.leaveAreaCollectGains &&
						this.HasGains())
					{
						ORK.Battle.Settings.realTime.collectGainsLeaveArea.CollectGains(null, -1);
					}
					this.ClearGains();
					this.ClearObjectsAndAnimations();
					ORK.Game.Combatants.EndBattle();

					ORK.Control.SetInBattle(-1);
					this.DoBattleBlock(-1);
					this.DoMoveAIBlock(-1);
					this.ClearBattle();
				}
				// start battle
				else if(!this.IsBattleRunning() &&
					this.realTimeAreaCount > 0)
				{
					ORK.Control.SetInBattle(1);
					this.SetType(BattleSystemType.RealTime);
					this.DoBattleBlock(1);

					// TODO: spawn whole groups?

					// join all spawned combatants
					List<Combatant> combatants = ORK.Game.Combatants.GetAll();
					for(int i = 0; i < combatants.Count; i++)
					{
						if(combatants[i].Group == ORK.Game.ActiveGroup ||
							BattleSystemType.RealTime == combatants[i].Group.BattleType)
						{
							this.Join(combatants[i]);
						}
					}

					this.StartBattle(false);
				}
			}
		}

		public GroupAdvantageType Advantage
		{
			get { return this.battleAdvantage; }
		}

		public int PlayerMaxBattleGroupSize
		{
			get { return this.maxPlayerBattleGroupSize; }
			set
			{
				if(this.maxPlayerBattleGroupSize != value)
				{
					this.maxPlayerBattleGroupSize = value;
					if(this.maxPlayerBattleGroupSize < 1)
					{
						this.maxPlayerBattleGroupSize = 1;
					}
					ORK.Game.PlayerHandler.CheckMaxBattleGroups();
				}
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsTurnBased()
		{
			return this.currentSystem != null &&
				BattleSystemType.TurnBased == this.type;
		}

		public bool IsActiveTime()
		{
			return this.currentSystem != null &&
				BattleSystemType.ActiveTime == this.type;
		}

		public bool IsRealTime()
		{
			return this.currentSystem != null &&
				BattleSystemType.RealTime == this.type;
		}

		public bool IsRealTimeArea()
		{
			return this.currentSystem != null &&
				BattleSystemType.RealTime == this.type &&
				this.realTimeAreaCount > 0;
		}

		public bool IsPhase()
		{
			return this.currentSystem != null &&
				BattleSystemType.Phase == this.type;
		}

		public bool IsType(BattleSystemType type)
		{
			return this.currentSystem != null &&
				type == this.type;
		}

		public bool IsBattleRunning()
		{
			return this.currentSystem != null &&
				this.inBattle && !this.battleEnd;
		}

		public bool IsDynamicCombat()
		{
			return this.currentSystem != null &&
				this.currentSystem.IsDynamicCombat();
		}

		public bool CanChoose(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.CanChoose(combatant);
			}
			return !combatant.Actions.IsWaiting;
		}

		public bool CanDecreaseActionTime(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.CanDecreaseActionTime(combatant);
			}
			return false;
		}

		public void SetDecisionTime(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.SetDecisionTime(combatant);
			}
		}


		/*
		============================================================================
		Action cost functions
		============================================================================
		*/
		public float GetDefendActionCost(Combatant user)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.GetDefendActionCost(user);
			}
			return 0;
		}

		public float GetEscapeActionCost(Combatant user)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.GetEscapeActionCost(user);
			}
			return 0;
		}

		public float GetNoneActionCost(Combatant user)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.GetNoneActionCost(user);
			}
			return 0;
		}

		public float GetChangeMemberActionCost(Combatant user)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.GetChangeMemberActionCost(user);
			}
			return 0;
		}

		public float GetGridMoveActionCost(Combatant user)
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.GetGridMoveActionCost(user);
			}
			return 0;
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public void Join(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				this.Join(list[i]);
			}
		}

		public void Join(Combatant combatant)
		{
			bool fireAction = false;
			ORK.Game.Combatants.Add(combatant, true);
			ORK.Game.Bestiary.Encounter(combatant);

			// create/set spots
			if(this.battleArena != null)
			{
				// player spots
				if(combatant.Group == ORK.Game.ActiveGroup)
				{
					this.battleArena.SetNextPlayerSpot(combatant, this.battleAdvantage);
				}
				// enemy spots
				else if(combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					this.battleArena.SetNextEnemySpot(combatant, this.battleAdvantage);
				}
				// ally spots
				else
				{
					this.battleArena.SetNextAllySpot(combatant, this.battleAdvantage);
				}
			}

			// spawn and counting
			if(this.IsBattleRunning())
			{
				// enemy counting
				if(combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader) &&
					EnemyCounting.None != ORK.BattleSettings.enemyCounter)
				{
					if(this.enemyCounter.ContainsKey(combatant.RealID))
					{
						this.enemyCounter[combatant.RealID]++;
					}
					else
					{
						this.enemyCounter.Add(combatant.RealID, 1);
						this.enemyCounter2.Add(combatant.RealID, 0);
					}

					if(this.enemyCounter[combatant.RealID] > 1)
					{
						combatant.NameCount = TextHelper.GetCounter(
							ORK.BattleSettings.enemyCounter,
							this.enemyCounter2[combatant.RealID]++);
					}
				}

				if(combatant.Object.BattleSpot != null)
				{
					if(this.grid != null)
					{
						if(combatant.Grid.Cell != null)
						{
							combatant.Object.SetBattleSpotPosition(combatant.Grid.Cell.transform.position);
						}
						else
						{
							BattleGridCellComponent cell = this.grid.GetNearestCell(
								combatant.Object.BattleSpot.transform.position, Mathf.Infinity,
								BattleGridHelper.IsUnblockedEmptyCell);
							if(cell != null)
							{
								cell.SetCombatant(combatant, false);
								combatant.Object.BattleSpot.transform.position = cell.transform.position;
							}
						}
					}

					if(combatant.GameObject == null)
					{
						combatant.Object.Spawn(combatant.Object.BattleSpot.transform.position,
							true, combatant.Object.BattleSpot.transform.eulerAngles.y,
							ORK.BattleSpots.useScale, combatant.Object.BattleSpot.transform.localScale);
					}
					else if(combatant.IsAnimateJoinBattle())
					{
						fireAction = true;
					}
					else
					{
						combatant.Object.PlaceAt(combatant.Object.BattleSpot.transform.position,
							true, combatant.Object.BattleSpot.transform.eulerAngles.y,
							ORK.BattleSpots.useScale, combatant.Object.BattleSpot.transform.localScale);
					}
				}

				// look at enemies
				if(!fireAction && combatant.IsLookAtJoinBattle())
				{
					this.DoLookAt(combatant, ORK.Game.Combatants.Get(combatant, true,
						Range.Infinity, Consider.Yes, Consider.No, Consider.Yes, null));
				}
			}

			// start battle for combatant
			combatant.Battle.StartBattle();
			if(this.IsActiveTime())
			{
				combatant.Battle.ActionBar = ORK.Formulas.Get(ORK.Battle.Settings.activeTime.startFormulaID).
					Calculate(new FormulaCall(ORK.Battle.Settings.activeTime.initialValueStart, combatant, combatant));
				if(combatant.Battle.ActionBar > ORK.Battle.Settings.activeTime.maxTimebar)
				{
					combatant.Battle.ActionBar = ORK.Battle.Settings.activeTime.maxTimebar;
				}
			}

			// fire join action
			if(fireAction)
			{
				this.Actions.Unshift(new JoinBattleAction(combatant));
			}

			this.FireCombatantJoined(combatant);
		}

		public void RemoveCombatant(Combatant combatant, bool died)
		{
			combatant.Battle.EndBattle();
			if(combatant.Group.InFormation)
			{
				combatant.Group.GridFormation.CombatantRemoved(combatant);
			}

			if(!died || !combatant.Setting.deathKeepPrefab)
			{
				combatant.Object.DestroyPrefab();
			}
			if(combatant == combatant.Group.BattleLeader)
			{
				combatant.Group.FindNewBattleLeader();
			}

			// free battle spot
			if(this.battleArena != null)
			{
				this.battleArena.SetSpot(combatant, null);
			}

			if(this.IsTurnBased())
			{
				ORK.Battle.Settings.turnBased.FireHUDUpdate();
			}

			this.CheckBattleEnd();

			this.FireCombatantRemoved(combatant);
		}

		public void EnemyDefeated(Combatant combatant)
		{
			// exp+items
			if(combatant != null)
			{
				ORK.Statistic.EnemyKilled(combatant.RealID);

				// update bestiary
				if(ORK.GameSettings.bestiary.useBestiary)
				{
					List<Combatant> attackedBy = combatant.Battle.GetAttackedBy();
					for(int i = 0; i < attackedBy.Count; i++)
					{
						if(attackedBy[i] != null &&
							attackedBy[i].IsPlayerControlled())
						{
							ORK.Game.Bestiary.Killed(combatant);
							break;
						}
					}
				}

				this.GetGainsFrom(combatant);

				// remove enemy
				this.RemoveCombatant(combatant, true);

				// fire killed enemy callback
				if(this.enemyKilledHandler != null)
				{
					this.enemyKilledHandler(combatant);
				}
			}
		}

		public void GetGainsFrom(Combatant combatant)
		{
			if(combatant != null &&
				!combatant.LootCollected)
			{
				combatant.LootCollected = true;

				// battle gains
				if(this.currentSystem != null)
				{
					// combatant gains
					combatant.GetLoot(ref this.loot, this.currentSystem.gainsUseInventoryAddType);

					// group gains
					if(combatant.Group.AllDeadBattle() &&
						combatant.Group.HasLoot)
					{
						for(int i = 0; i < combatant.Group.Loot.Count; i++)
						{
							ShortcutHelper.Add(ref this.loot, combatant.Group.Loot[i],
								this.currentSystem.gainsUseInventoryAddType);
						}
					}
				}

				// experience reward
				if(combatant.Setting.useExpReward)
				{
					if(combatant.Setting.expReward != null)
					{
						for(int i = 0; i < combatant.Setting.expReward.Length; i++)
						{
							if(!combatant.Setting.expReward[i].useChance ||
								ORK.GameSettings.CheckRandom(
									combatant.Setting.expReward[i].chance.GetValue(combatant, combatant)))
							{
								DifficultyFaction factionMultipliers = ORK.Difficulties.Get(ORK.Game.Difficulty).
									GetMultipliers(combatant.Group.FactionID);
								int exp = (int)(combatant.Setting.expReward[i].rewardValue.GetValue(combatant, combatant) *
									(factionMultipliers != null ?
										factionMultipliers.statusMultiplier[combatant.Setting.expReward[i].statusID] : 1));
								if(exp != 0)
								{
									if(ORK.BattleEnd.splitExp)
									{
										if(ORK.BattleEnd.wholePartyExp)
										{
											exp /= ORK.Game.ActiveGroup.Size;
										}
										else
										{
											exp /= ORK.Game.ActiveGroup.BattleSize;
										}
										if(exp == 0)
										{
											exp = 1;
										}
									}

									this.AddExperienceReward(combatant.Setting.expReward[i].statusID,
										exp, combatant.Status.Level, combatant.Class.Level);
								}
							}
						}
					}
				}
				else
				{
					for(int i = 0; i < ORK.StatusValues.Count; i++)
					{
						if(combatant.Status[i].IsExperience())
						{
							int exp = combatant.Status[i].GetBaseValue();
							if(exp != 0)
							{
								if(ORK.BattleEnd.splitExp)
								{
									if(ORK.BattleEnd.wholePartyExp)
									{
										exp /= ORK.Game.ActiveGroup.Size;
									}
									else
									{
										exp /= ORK.Game.ActiveGroup.BattleSize;
									}
									if(exp == 0)
									{
										exp = 1;
									}
								}

								this.AddExperienceReward(i, exp, combatant.Status.Level, combatant.Class.Level);
							}
						}
					}
				}

				// noraml status value reward
				for(int i = 0; i < combatant.Setting.normalSVReward.Length; i++)
				{
					if(!combatant.Setting.normalSVReward[i].useChance ||
						ORK.GameSettings.CheckRandom(
							combatant.Setting.normalSVReward[i].chance.GetValue(combatant, combatant)))
					{
						int value = (int)combatant.Setting.normalSVReward[i].rewardValue.GetValue(combatant, combatant);
						if(value != 0)
						{
							if(ORK.BattleEnd.splitNormalSV)
							{
								if(ORK.BattleEnd.wholePartyNormalSV)
								{
									value /= ORK.Game.ActiveGroup.Size;
								}
								else
								{
									value /= ORK.Game.ActiveGroup.BattleSize;
								}
							}

							this.AddNormalStatusValueReward(
								combatant.Setting.normalSVReward[i].statusID, value);
						}
					}
				}

				// collect gains
				if(this.currentSystem != null &&
					this.currentSystem.gainsCollectImmediately)
				{
					if(combatant.GameObject != null &&
						(this.currentSystem.gainsDropItems ||
							this.currentSystem.gainsDropMoney ||
							this.currentSystem.gainsDropAI ||
							this.currentSystem.gainsDropRecipes))
					{
						for(int i = 0; i < this.loot.Count; i++)
						{
							if((this.currentSystem.gainsDropMoney &&
									this.loot[i] is MoneyShortcut) ||
								(this.currentSystem.gainsDropItems &&
									(this.loot[i] is ItemShortcut ||
									this.loot[i] is EquipShortcut)) ||
								(this.currentSystem.gainsDropAI &&
									(this.loot[i] is AIBehaviourShortcut ||
									this.loot[i] is AIRulesetShortcut)) ||
								(this.currentSystem.gainsDropRecipes &&
									this.loot[i] is CraftingRecipeShortcut))
							{
								ORK.Game.Scene.Drop(this.loot[i],
									combatant.GameObject.transform.position,
									ORK.InventorySettings.dropUseRotation ?
										combatant.GameObject.transform.eulerAngles :
										Vector3.zero);
								this.loot.RemoveAt(i--);
							}
						}
					}

					this.currentSystem.collectGains.CollectGains(null, -1);
				}
			}
		}

		/// <summary>
		/// Notifies all listeners to the 'LatestTurn' event handler that a combatant's turn started.
		/// </summary>
		/// <param name="combatant">The combatant who's turn started.</param>
		public void FireLatestTurn(Combatant combatant)
		{
			if(this.latestTurnHandler != null)
			{
				this.latestTurnHandler(combatant);
			}
		}

		/// <summary>
		/// Notifies all listeners to the 'CombatantJoined' event handler that a combatant joined the battle.
		/// </summary>
		/// <param name="combatant">The combatant who joined.</param>
		public void FireCombatantJoined(Combatant combatant)
		{
			if(this.combatantJoinedHandler != null)
			{
				this.combatantJoinedHandler(combatant);
			}
		}

		/// <summary>
		/// Notifies all listeners to the 'CombatantRemoved' event handler that a combatant was removed from battle.
		/// </summary>
		/// <param name="combatant">The combatant who was removed.</param>
		public void FireCombatantRemoved(Combatant combatant)
		{
			if(this.combatantRemovedHandler != null)
			{
				this.combatantRemovedHandler(combatant);
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Tick()
		{
			if(!ORK.Game.Paused)
			{
				this.Actions.Tick();

				if(this.currentSystem != null)
				{
					if(this.grid != null &&
						!this.battleEnd)
					{
						this.settings.gridSettings.Tick();
						this.settings.gridHighlights.Tick();
					}

					if(this.inBattle)
					{
						// camera
						ORK.BattleSettings.camera.Tick();

						// battle system type
						this.currentSystem.Tick();

						if(BattleOutcome.None != this.waitForLastActionOutcome &&
							this.Actions.CanEndBattle(this.currentSystem.EndImmediately))
						{
							this.battleEnd = true;
							if(BattleOutcome.Victory == this.waitForLastActionOutcome)
							{
								this.BattleVictory();
							}
							else if(BattleOutcome.Defeat == this.waitForLastActionOutcome)
							{
								this.BattleLost();
							}
							else if(BattleOutcome.Escape == this.waitForLastActionOutcome)
							{
								this.BattleEscaped();
							}
							else if(BattleOutcome.LeaveArena == this.waitForLastActionOutcome)
							{
								this.BattleLeftArena();
							}
						}
						else if(this.battleArena != null)
						{
							// leave arena
							if(this.currentSystem.useLeaveArena &&
								this.currentSystem.leaveArenaRange.OutOfRange(
									this.battleArena.transform.position, ORK.Game.ActiveGroup.Leader))
							{
								if(this.currentSystem.EndImmediately &&
									this.Actions.CanEndBattle(this.currentSystem.EndImmediately))
								{
									this.BattleLeftArena();
								}
								else
								{
									this.waitForLastActionOutcome = BattleOutcome.LeaveArena;
								}
							}
							// auto join
							else if(this.battleArena.useDefaultAutoJoin &&
								ORK.BattleSettings.autoJoin.runningBattle)
							{
								this.Join(ORK.BattleSettings.autoJoin.GetCombatants(this.battleArena.transform.position));
							}
							else if(this.battleArena.autoJoin != null &&
								this.battleArena.autoJoin.runningBattle)
							{
								this.Join(this.battleArena.autoJoin.GetCombatants(this.battleArena.transform.position));
							}
						}
					}
				}
			}
		}

		public bool DoCombatantTick()
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.DoCombatantTick();
			}
			return true;
		}

		public void RemoveFromOrder(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.RemoveFromOrder(combatant);
			}
		}

		public void OrderChange(Combatant combatant, int change)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.OrderChange(combatant, change);
			}
		}

		public void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			ORK.Battle.Actions.RemoveFromUser(oldCombatant);
			ORK.Battle.Actions.RemoveTarget(oldCombatant);
			if(this.currentSystem != null)
			{
				this.currentSystem.CombatantChanged(oldCombatant, newCombatant);
			}
			// add player controls if old combatant is player
			Combatant realPlayer = ORK.Game.ActiveGroup.MemberAt(0);
			if(newCombatant != null &&
				(oldCombatant == realPlayer || newCombatant == realPlayer))
			{
				ORK.Control.ControlledPlayer = newCombatant.GameObject;
			}

			this.FireCombatantRemoved(oldCombatant);
			this.FireCombatantJoined(newCombatant);
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public void SetType(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased == type)
			{
				this.currentSystem = ORK.Battle.Settings.turnBased;
			}
			else if(BattleSystemType.ActiveTime == type)
			{
				this.currentSystem = ORK.Battle.Settings.activeTime;
			}
			else if(BattleSystemType.RealTime == type)
			{
				this.currentSystem = ORK.Battle.Settings.realTime;
			}
			else if(BattleSystemType.Phase == type)
			{
				this.currentSystem = ORK.Battle.Settings.phase;
			}
			this.type = type;
			ORK.Battle.DoMoveAIBlock(1);
		}

		public void SetBattleArena(BattleComponent arena)
		{
			this.battleArena = arena;
			this.battleAdvantage = GroupAdvantageType.None;

			if(this.battleArena != null)
			{
				// grid
				this.Grid = null;
				if(GridUseBattleType.DefinedGrid == this.battleArena.gridUseType)
				{
					this.Grid = this.battleArena.gridObject;
				}
				else if(GridUseBattleType.NearestGrid == this.battleArena.gridUseType)
				{
					this.Grid = ComponentHelper.GetNearest<BattleGridComponent>(this.battleArena.transform.position);
				}

				// battle advantage
				float rnd = ORK.GameSettings.GetRandom();

				float paChance = ORK.BattleSettings.playerAdvantage.chance;
				if(this.battleArena.overridePAChance)
				{
					paChance = this.battleArena.paChance;
				}

				float eaChance = ORK.BattleSettings.enemyAdvantage.chance;
				if(this.battleArena.overrideEAChance)
				{
					eaChance = this.battleArena.eaChance;
				}

				if(ORK.BattleSettings.playerAdvantage.enabled &&
					this.battleArena.enablePA &&
					paChance > 0 && rnd <= paChance)
				{
					this.battleAdvantage = GroupAdvantageType.Player;
				}
				else if(ORK.BattleSettings.enemyAdvantage.enabled &&
					this.battleArena.enableEA &&
					eaChance > 0 && rnd >= ORK.GameSettings.maxRandomRange - eaChance)
				{
					this.battleAdvantage = GroupAdvantageType.Enemy;
				}
			}
		}

		public void StartBattle(bool canEscape)
		{
			this.canEscape = canEscape;
			this.waitForLastActionOutcome = BattleOutcome.None;
			this.currentTurn = 0;

			if(this.battleArena != null)
			{
				// additional item gains
				for(int i = 0; i < this.battleArena.itemGains.Length; i++)
				{
					if(this.battleArena.itemGains[i].CheckChance())
					{
						ShortcutHelper.Add(ref this.loot,
							this.battleArena.itemGains[i].CreateShortcut(),
							this.currentSystem.gainsUseInventoryAddType);
					}
				}
				ORK.BattleSettings.camera.StartBattle(this.battleArena);
			}

			if(this.IsRealTime() &&
				this.realTimeAreaCount > 0)
			{
				this.battleAdvantage = GroupAdvantageType.None;
			}

			if((GroupAdvantageType.Player == this.battleAdvantage &&
					ORK.BattleSettings.playerAdvantage.blockEscape) ||
				(GroupAdvantageType.Enemy == this.battleAdvantage &&
					ORK.BattleSettings.enemyAdvantage.blockEscape))
			{
				this.canEscape = false;
			}

			List<Combatant> allies = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader,
				true, Range.Infinity, Consider.No, Consider.No, Consider.Yes, null);
			List<Combatant> enemies = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader,
				true, Range.Infinity, Consider.Yes, Consider.No, Consider.Yes, null);

			// player/allies set up
			for(int i = 0; i < allies.Count; i++)
			{
				if(GroupAdvantageType.Player == this.battleAdvantage)
				{
					ORK.BattleSettings.playerAdvantage.playerGroupCondition.Apply(allies[i]);
				}
				else if(GroupAdvantageType.Enemy == this.battleAdvantage)
				{
					ORK.BattleSettings.enemyAdvantage.playerGroupCondition.Apply(allies[i]);
				}
				else
				{
					if(this.IsActiveTime())
					{
						allies[i].Battle.ActionBar = ORK.Formulas.Get(ORK.Battle.Settings.activeTime.startFormulaID).
							Calculate(new FormulaCall(ORK.Battle.Settings.activeTime.initialValueStart, allies[i], allies[i]));
						if(allies[i].Battle.ActionBar > ORK.Battle.Settings.activeTime.maxTimebar)
						{
							allies[i].Battle.ActionBar = ORK.Battle.Settings.activeTime.maxTimebar;
						}
					}
					this.StartBonus(allies[i]);
				}
			}

			// prepare enemy name counting
			this.enemyCounter.Clear();
			this.enemyCounter2.Clear();

			if(EnemyCounting.None != ORK.BattleSettings.enemyCounter)
			{
				for(int i = 0; i < enemies.Count; i++)
				{
					if(this.enemyCounter.ContainsKey(enemies[i].RealID))
					{
						this.enemyCounter[enemies[i].RealID]++;
					}
					else
					{
						this.enemyCounter.Add(enemies[i].RealID, 1);
						this.enemyCounter2.Add(enemies[i].RealID, 0);
					}
				}
			}

			// enemies set up
			for(int i = 0; i < enemies.Count; i++)
			{
				if(EnemyCounting.None != ORK.BattleSettings.enemyCounter &&
					this.enemyCounter[enemies[i].RealID] > 1)
				{
					enemies[i].NameCount = TextHelper.GetCounter(
						ORK.BattleSettings.enemyCounter,
						this.enemyCounter2[enemies[i].RealID]++);
				}

				if(GroupAdvantageType.Player == this.battleAdvantage)
				{
					ORK.BattleSettings.playerAdvantage.enemyGroupCondition.Apply(enemies[i]);
				}
				else if(GroupAdvantageType.Enemy == this.battleAdvantage)
				{
					ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.Apply(enemies[i]);
				}
				else
				{
					if(this.IsActiveTime())
					{
						enemies[i].Battle.ActionBar = ORK.Formulas.Get(ORK.Battle.Settings.activeTime.startFormulaID).
							Calculate(new FormulaCall(ORK.Battle.Settings.activeTime.initialValueStart, enemies[i], enemies[i]));
						if(enemies[i].Battle.ActionBar > ORK.Battle.Settings.activeTime.maxTimebar)
						{
							enemies[i].Battle.ActionBar = ORK.Battle.Settings.activeTime.maxTimebar;
						}
					}
					this.StartBonus(enemies[i]);
				}
			}

			this.ClearChoosingCombatants();
			this.ClearMenuUsers();
			this.Actions.Clear();

			this.battleEnd = false;
			this.inBattle = true;

			if(!this.IsRealTime() &&
				this.realTimeAreaCount > 0)
			{
				ORK.Statistic.BattleStarted();
			}

			if(this.startBattleHandler != null)
			{
				this.startBattleHandler();
			}
			this.currentSystem.StartBattle(false);
		}

		public void ChangeType(BattleSystemType type, bool clearActions, bool stopActions)
		{
			if(this.inBattle && !this.battleEnd &&
				this.currentSystem != null && !this.IsType(type))
			{
				if(clearActions)
				{
					this.Actions.ClearStack();
				}
				if(stopActions)
				{
					this.Actions.StopActiveActions();
				}

				this.currentSystem.EndBattle();
				this.DoMoveAIBlock(-1);
				this.SetType(type);
				if(this.systemChangedHandler != null)
				{
					this.systemChangedHandler();
				}
				this.currentSystem.StartBattle(true);
			}
		}


		/*
		============================================================================
		Bonus functions
		============================================================================
		*/
		public void StartBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.StartBonus(combatant);
			}
		}

		public void TurnBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.TurnBonus(combatant);
			}
		}

		public void EndBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.EndBonus(combatant);
			}
		}

		public void ReviveBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.ReviveBonus(combatant);
			}
		}


		/*
		============================================================================
		End functions
		============================================================================
		*/
		public void EndBattle(BattleOutcome outcome)
		{
			if(BattleOutcome.None != outcome &&
				this.IsBattleRunning())
			{
				if(this.currentSystem.EndImmediately &&
					this.Actions.CanEndBattle(this.currentSystem.EndImmediately))
				{
					if(BattleOutcome.Victory == outcome)
					{
						this.BattleVictory();
					}
					else if(BattleOutcome.Defeat == outcome)
					{
						this.BattleLost();
					}
					else if(BattleOutcome.Escape == outcome)
					{
						this.BattleEscaped();
					}
					else if(BattleOutcome.LeaveArena == outcome)
					{
						this.BattleLeftArena();
					}
				}
				else
				{
					this.waitForLastActionOutcome = outcome;
				}
			}
		}

		public void CancelBattleEnd()
		{
			this.waitForLastActionOutcome = BattleOutcome.None;
		}

		public void CheckBattleEnd()
		{
			if(this.IsBattleRunning() &&
				BattleOutcome.None == this.waitForLastActionOutcome &&
				(!this.IsRealTime() || this.realTimeAreaCount == 0))
			{
				this.waitForLastActionOutcome = BattleOutcome.None;
				ORK.Game.Combatants.CheckDeath();

				// all enemies gone
				if(this.IsAllEnemiesDefeated())
				{
					if(this.currentSystem.EndImmediately &&
						this.Actions.CanEndBattle(this.currentSystem.EndImmediately))
					{
						this.BattleVictory();
					}
					else
					{
						this.waitForLastActionOutcome = BattleOutcome.Victory;
					}
				}
				// check player group
				else
				{
					bool alive = false;
					if(this.currentSystem.DefeatOnPlayerDeath)
					{
						if(!ORK.Game.ActiveGroup.Leader.Status.IsDead)
						{
							alive = true;
						}
					}
					else
					{
						List<Combatant> group = ORK.Game.ActiveGroup.GetBattle();
						for(int i = 0; i < group.Count; i++)
						{
							if(!group[i].Status.IsDead)
							{
								alive = true;
								break;
							}
						}
					}
					if(!alive)
					{
						if(this.currentSystem.EndImmediately &&
							this.Actions.CanEndBattle(this.currentSystem.EndImmediately))
						{
							this.BattleLost();
						}
						else
						{
							this.waitForLastActionOutcome = BattleOutcome.Defeat;
						}
					}
				}
			}
		}

		private bool IsAllEnemiesDefeated()
		{
			List<Combatant> enemies = ORK.Game.Combatants.Get(
				ORK.Game.ActiveGroup.Leader, false, Range.Infinity,
				Consider.Yes, Consider.Ignore, Consider.Yes, null);

			for(int i = 0; i < enemies.Count; i++)
			{
				if(enemies[i] != null && !enemies[i].Status.IsDead)
				{
					return false;
				}
			}
			return true;
		}

		private void EndBattle()
		{
			this.waitForLastActionOutcome = BattleOutcome.None;
			if(this.currentSystem != null)
			{
				this.currentSystem.EndBattle();
			}
			this.battleEnd = true;
			ORK.BattleSettings.camera.EndBattle();
			this.inBattle = false;
			this.ClearChoosingCombatants();
			this.ClearMenuUsers();
			if(this.grid != null)
			{
				this.settings.gridSettings.EndBattle();
			}

			if(this.endBattleHandler != null)
			{
				this.endBattleHandler();
			}
		}

		public void BattleVictory()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleWon();
			}
			this.EndBattle();

			// player/allies celebrate
			if(ORK.BattleSettings.playVictoryAnimation)
			{
				List<Combatant> group = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader,
					true, Range.Infinity, Consider.No, Consider.Ignore, Consider.Yes, null);
				for(int i = 0; i < group.Count; i++)
				{
					if(!group[i].Status.IsDead)
					{
						group[i].Animations.Play(ORK.AnimationTypes.victoryID);
					}
				}
			}

			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Victory);
			}
		}

		public void BattleEscaped()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleEscaped();
			}
			this.EndBattle();

			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Escape);
			}
		}

		public void BattleLost()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleLost();
			}
			this.EndBattle();

			// enemies celebrate
			if(ORK.BattleSettings.playVictoryAnimation)
			{
				List<Combatant> group = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader,
					true, Range.Infinity, Consider.Yes, Consider.Ignore, Consider.Yes, null);
				for(int i = 0; i < group.Count; i++)
				{
					if(!group[i].Status.IsDead)
					{
						group[i].Animations.Play(ORK.AnimationTypes.victoryID);
					}
				}
			}

			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Defeat);
			}
		}

		public void BattleLeftArena()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleEscaped();
			}
			this.EndBattle();

			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.LeaveArena);
			}
		}

		public void ClearObjectsAndAnimations()
		{
			if(this.groupCenter)
			{
				UnityWrapper.Destroy(this.groupCenter);
			}
			if(this.combatantCenter)
			{
				UnityWrapper.Destroy(this.combatantCenter);
			}

			List<Combatant> list = ORK.Game.Combatants.Get(true, Consider.No, Consider.Yes, null);
			for(int i = 0; i < list.Count; i++)
			{
				if(!list[i].Status.IsDead)
				{
					list[i].Animations.Stop(ORK.AnimationTypes.victoryID);
					list[i].Animations.Play(ORK.AnimationTypes.idleID);
				}
			}

			List<Combatant> group = ORK.Game.ActiveGroup.GetBattle();
			for(int i = 0; i < group.Count; i++)
			{
				if(!group[i].Status.IsDead)
				{
					group[i].Animations.Stop(ORK.AnimationTypes.victoryID);
					group[i].Animations.Play(ORK.AnimationTypes.idleID);
				}
			}
			if(this.IsRealTime())
			{
				ORK.Control.ClearInBattle();
			}

			// if player not spawned, spawn it again
			ORK.Game.PlayerHandler.AfterBattleSpawn();
		}


		/*
		============================================================================
		Gain functions
		============================================================================
		*/
		public bool HasGains()
		{
			return this.loot.Count > 0 ||
				this.expGains.Count > 0 ||
					this.normalSVGains.Count > 0;
		}

		public void ClearGains()
		{
			this.loot.Clear();
			this.expGains.Clear();
			this.normalSVGains.Clear();
		}

		public void AddLoot(ItemGain item)
		{
			if(this.currentSystem != null &&
				item != null && item.CheckChance())
			{
				ShortcutHelper.Add(ref this.loot, item.CreateShortcut(),
					this.currentSystem.gainsUseInventoryAddType);
			}
		}

		public void AddExperienceReward(int statusID, int exp, int level, int classLevel)
		{
			if(!this.expGains.ContainsKey(statusID))
			{
				this.expGains.Add(statusID, new List<ExperienceLoot>());
			}
			this.expGains[statusID].Add(new ExperienceLoot(exp, level, classLevel));
		}

		public void AddNormalStatusValueReward(int statusID, int value)
		{
			if(!this.normalSVGains.ContainsKey(statusID))
			{
				this.normalSVGains.Add(statusID, 0);
			}
			this.normalSVGains[statusID] += value;
		}

		public void CollectGains(bool collectLoot, bool collectExp,
			bool showGains, float autoClose, bool autoCloseControlable,
			bool useItemBox, bool itemBoxAddType, string itemBoxID,
			BaseEvent baseEvent, int next)
		{
			List<Tuple<BattleGainsTextType, Combatant, string>> endTexts = new List<Tuple<BattleGainsTextType, Combatant, string>>();

			string moneyText = "";
			string itemText = "";
			string expText = "";
			string normalSVText = "";
			int[] totalMoney = new int[ORK.Currencies.Count];

			// loot
			if(collectLoot)
			{
				if(useItemBox)
				{
					ORK.Game.Scene.AddToItemBox(itemBoxID, this.loot, itemBoxAddType);
				}

				for(int i = 0; i < this.loot.Count; i++)
				{
					int addedQuantity = this.loot[i].Quantity;
					if(useItemBox ||
						ORK.Game.ActiveGroup.Leader.Inventory.Add(this.loot[i], ref addedQuantity, true, true, true))
					{
						if(this.loot[i] is MoneyShortcut)
						{
							totalMoney[this.loot[i].ID] += this.loot[i].Quantity;
						}
						else if(this.loot[i] is ItemShortcut ||
							this.loot[i] is EquipShortcut ||
							this.loot[i] is AIBehaviourShortcut ||
							this.loot[i] is AIRulesetShortcut ||
							this.loot[i] is CraftingRecipeShortcut)
						{
							string tmp = ORK.BattleEnd.victoryGains.GetItemText(
								ORK.Game.ActiveGroup.Leader, this.loot[i], addedQuantity);
							if("" != tmp)
							{
								itemText += tmp + "\n";
							}
						}
					}
				}

				for(int i = 0; i < totalMoney.Length; i++)
				{
					if(totalMoney[i] > 0)
					{
						string tmp = ORK.BattleEnd.victoryGains.GetMoneyText(
							ORK.Game.ActiveGroup.Leader, i, totalMoney[i]);
						if("" != tmp)
						{
							moneyText += tmp + "\n";
						}
					}
				}

				this.loot.Clear();
			}

			if(collectExp)
			{
				List<Combatant> group = null;
				if(ORK.BattleEnd.wholePartyExp)
				{
					group = ORK.Game.ActiveGroup.GetGroup();
				}
				else
				{
					group = ORK.Game.ActiveGroup.GetBattle();
				}

				// combatant gains
				for(int i = 0; i < group.Count; i++)
				{
					string combatantExpText = "";
					string combatantNormalSVText = "";

					// experience gains
					if(ORK.BattleEnd.deadExp || !group[i].Status.IsDead)
					{
						foreach(KeyValuePair<int, List<ExperienceLoot>> pair in this.expGains)
						{
							int exp = 0;
							for(int j = 0; j < pair.Value.Count; j++)
							{
								exp += group[i].Status[pair.Key].Setting.GetExperience(
									pair.Value[j].experience,
									group[i].Status.Level - pair.Value[j].baseLevel,
									group[i].Class.Level - pair.Value[j].classLevel);
							}

							if(exp > 0)
							{
								int oldValue = group[i].Status[pair.Key].GetValue();
								exp = (int)(exp * group[i].Status.ExperienceFactor);
								group[i].Status[pair.Key].AddValue(exp, false, true, false, false, true, true);

								// victory gains
								string tmp = ORK.BattleEnd.victoryGains.GetExperienceText(
									group[i], pair.Key, exp,
									oldValue, group[i].Status[pair.Key].GetValue());
								if(tmp != "")
								{
									expText += tmp + "\n";
								}

								// combatant gains
								tmp = ORK.BattleEnd.combatantGains.GetExperienceText(
									group[i], pair.Key, exp,
									oldValue, group[i].Status[pair.Key].GetValue());
								if(tmp != "")
								{
									combatantExpText += tmp + "\n";
								}
							}
						}
					}
					// normal gains
					if(ORK.BattleEnd.deadNormalSV || !group[i].Status.IsDead)
					{
						foreach(KeyValuePair<int, int> pair in this.normalSVGains)
						{
							if(pair.Value > 0)
							{
								int oldValue = group[i].Status[pair.Key].GetValue();
								int oldBaseValue = group[i].Status[pair.Key].GetBaseValue();
								group[i].Status[pair.Key].AddBaseValue(pair.Value);
								group[i].Status[pair.Key].AddValue(pair.Value, false, true, false, false, true, true);

								// victory gains
								string tmp = ORK.BattleEnd.victoryGains.GetNormalStatusValueText(
									group[i], pair.Key, pair.Value,
									oldValue, group[i].Status[pair.Key].GetValue(),
									oldBaseValue, group[i].Status[pair.Key].GetBaseValue());
								if(tmp != "")
								{
									normalSVText += tmp + "\n";
								}

								// combatant gains
								tmp = ORK.BattleEnd.combatantGains.GetNormalStatusValueText(
									group[i], pair.Key, pair.Value,
									oldValue, group[i].Status[pair.Key].GetValue(),
									oldBaseValue, group[i].Status[pair.Key].GetBaseValue());
								if(tmp != "")
								{
									combatantNormalSVText += tmp + "\n";
								}
							}
						}
					}

					// check level up
					string levelUpText = "";
					bool isLevelUp = group[i].Status.CheckLevelUp(ref levelUpText);

					if(ORK.BattleEnd.combatantGains.showGains)
					{
						string gainsText = ORK.BattleEnd.combatantGains.GetGainText(
							group[i], combatantExpText, combatantNormalSVText, levelUpText, isLevelUp);
						if(gainsText != "")
						{
							endTexts.Add(new Tuple<BattleGainsTextType, Combatant, string>(
								BattleGainsTextType.Combatant, group[i], gainsText));
						}
						if(ORK.BattleEnd.combatantGains.combineLevelUps)
						{
							isLevelUp = false;
						}
					}
					if(isLevelUp &&
						ORK.BattleEnd.levelUp.showLevelUp &&
						levelUpText != "")
					{
						endTexts.Add(new Tuple<BattleGainsTextType, Combatant, string>(
							BattleGainsTextType.LevelUp, group[i], levelUpText));
					}
				}

				this.expGains.Clear();
				this.normalSVGains.Clear();
			}

			if(ORK.BattleEnd.victoryGains.showGains &&
				(moneyText != "" ||
					itemText != "" ||
					expText != "" ||
					normalSVText != ""))
			{
				string gainsText = ORK.BattleEnd.victoryGains.GetGainText(
					moneyText, itemText, expText, normalSVText);

				if(gainsText != "")
				{
					endTexts.Insert(0, new Tuple<BattleGainsTextType, Combatant, string>(
						BattleGainsTextType.Victory, null, gainsText));
				}
			}

			if(showGains &&
				endTexts.Count > 0)
			{
				new BattleEndChoice().Show(endTexts, autoClose, autoCloseControlable, baseEvent, next);
			}
		}


		/*
		============================================================================
		Looking functions
		============================================================================
		*/
		public void SetLooks(Combatant user)
		{
			this.DoLookAt(user,
				ORK.Game.Combatants.Get(user != null ? user : ORK.Game.ActiveGroup.Leader,
					true, Range.Infinity, Consider.No, Consider.Ignore, Consider.Yes, null),
				ORK.Game.Combatants.Get(user != null ? user : ORK.Game.ActiveGroup.Leader,
					true, Range.Infinity, Consider.Yes, Consider.Ignore, Consider.Yes, null));
		}

		public void DoLookAt(Combatant user, List<Combatant> group, List<Combatant> enemies)
		{
			if(enemies != null && enemies.Count > 0 &&
				group != null && group.Count > 0)
			{
				this.GroupLookAt(user, group, this.GetGroupCenterPosition(enemies));
				this.GroupLookAt(user, enemies, this.GetGroupCenterPosition(group));
			}
		}

		public void DoLookAt(Combatant user, List<Combatant> targets)
		{
			if(user != null && targets.Count > 0)
			{
				this.UserLookAt(user, this.GetGroupCenterPosition(targets));
			}
		}

		public Vector3 GetGroupCenterPosition(List<Combatant> cs)
		{
			int count = 0;
			Vector3 center = Vector3.zero;
			for(int i = 0; i < cs.Count; i++)
			{
				if(cs[i] != null && cs[i].GameObject != null)
				{
					center += cs[i].GameObject.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				center /= count;
			}
			return center;
		}

		public GameObject GetGroupCenter(List<Combatant> cs)
		{
			int count = 0;
			Vector3 cen = Vector3.zero;
			for(int i = 0; i < cs.Count; i++)
			{
				if(cs[i] != null && cs[i].GameObject != null)
				{
					cen += cs[i].GameObject.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				cen /= count;
				if(this.groupCenter == null)
				{
					this.groupCenter = new GameObject("_tmp");
					if(this.battleArena != null)
					{
						this.groupCenter.transform.SetParent(this.battleArena.transform.parent);
					}
				}
				this.groupCenter.transform.position = cen;
			}
			return this.groupCenter;
		}

		public GameObject GetGroupBaseCenter(List<Combatant> cs)
		{
			int count = 0;
			Vector3 cen = Vector3.zero;
			for(int i = 0; i < cs.Count; i++)
			{
				if(cs[i] != null && cs[i].Object.BattleSpot != null)
				{
					cen += cs[i].Object.BattleSpot.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				cen /= count;
				if(this.groupCenter == null)
				{
					this.groupCenter = new GameObject("_tmp");
					if(this.battleArena != null)
					{
						this.groupCenter.transform.SetParent(this.battleArena.transform.parent);
					}
				}
				this.groupCenter.transform.position = cen;
			}
			return this.groupCenter;
		}

		public void GroupLookAt(Combatant user, List<Combatant> cs, Vector3 position)
		{
			for(int i = 0; i < cs.Count; i++)
			{
				if(cs[i] != null && cs[i].GameObject != null &&
					(cs[i].Actions.ActionState == CombatantActionState.Available || cs[i] == user))
				{
					cs[i].Object.LookAt(position);
					if(this.grid != null)
					{
						Vector3 tmpRotation = cs[i].GameObject.transform.eulerAngles;
						tmpRotation.y = BattleGridHelper.GetDirectionRotation(
							cs[i].GameObject, GridDirectionRotationType.Nearest, true);
						cs[i].GameObject.transform.eulerAngles = tmpRotation;
					}
				}
			}
		}

		public void UserLookAt(Combatant user, Vector3 position)
		{
			if(user != null && user.GameObject != null)
			{
				user.Object.LookAt(position);
				if(this.grid != null)
				{
					Vector3 tmpRotation = user.GameObject.transform.eulerAngles;
					tmpRotation.y = BattleGridHelper.GetDirectionRotation(
						user.GameObject, GridDirectionRotationType.Nearest, true);
					user.GameObject.transform.eulerAngles = tmpRotation;
				}
			}
		}

		public GameObject GetCombatantCenter()
		{
			if(this.combatantCenter == null)
			{
				this.combatantCenter = new GameObject();
			}
			int count = 0;
			this.combatantCenter.transform.position = Vector3.zero;

			List<Combatant> list = ORK.Game.Combatants.Get(true, Consider.No, Consider.Yes, null);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					this.combatantCenter.transform.position += list[i].GameObject.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				this.combatantCenter.transform.position /= count;
			}
			return this.combatantCenter;
		}

		public GameObject GetArenaCenter()
		{
			if(this.battleArena == null)
			{
				return this.GetCombatantCenter();
			}
			else
			{
				return this.battleArena.gameObject;
			}
		}


		/*
		============================================================================
		Choosing combatant functions
		============================================================================
		*/
		public void AddChoosingCombatant(Combatant combatant)
		{
			if(this.IsBattleRunning())
			{
				if(!this.choosingCombatants.Contains(combatant))
				{
					this.choosingCombatants.Add(combatant);
				}

				if(!ORK.BattleSettings.camera.IsNone &&
					combatant.GameObject != null)
				{
					ORK.BattleSettings.camera.SetSelectingUser(
						combatant.GameObject.transform,
						combatant.GameObject.transform);
				}
			}
		}

		public void RemoveChoosingCombatant(Combatant combatant)
		{
			if(this.IsBattleRunning() &&
				this.choosingCombatants.Contains(combatant))
			{
				this.choosingCombatants.Remove(combatant);
			}
		}

		public void ClearChoosingCombatants()
		{
			this.choosingCombatants.Clear();
		}

		public bool HasChoosingCombatants
		{
			get { return this.choosingCombatants.Count > 0; }
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public bool DisplayInfoTexts()
		{
			if(this.currentSystem != null)
			{
				if(this.IsTurnBased())
				{
					return ORK.BattleTexts.infoInTurnBased;
				}
				else if(this.IsActiveTime())
				{
					return ORK.BattleTexts.infoInActiveTime;
				}
				else if(this.IsRealTime())
				{
					return ORK.BattleTexts.infoInRealTime;
				}
				else if(this.IsPhase())
				{
					return ORK.BattleTexts.infoPhase;
				}
			}
			else
			{
				return ORK.BattleTexts.infoInField;
			}
			return false;
		}

		public bool IsMenuBackAllowed
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.IsMenuBackAllowed;
				}
				return true;
			}
		}

		public bool MenuActive
		{
			get { return this.menuUser.Count > 0; }
		}

		public int MenuCount
		{
			get { return this.menuUser.Count; }
		}

		public Combatant GetMenuUser()
		{
			if(this.menuIndex >= 0 && this.menuIndex < this.menuUser.Count)
			{
				return this.menuUser[this.menuIndex];
			}
			return null;
		}

		public void AddMenuUser(Combatant c)
		{
			if(!this.menuUser.Contains(c))
			{
				this.menuUser.Add(c);

				if(this.menuUser.Count == 1)
				{
					this.CheckMenuIndex();
					if(!ORK.BattleSettings.camera.IsNone &&
						this.menuUser[this.menuIndex].GameObject != null)
					{
						Transform user = this.menuUser[this.menuIndex].GameObject.transform;
						ORK.BattleSettings.camera.SetMenuUser(user, user);
					}
				}
			}
		}

		public void RemoveMenuUser(Combatant combatant)
		{
			if(this.menuUser.Contains(combatant))
			{
				this.menuUser.Remove(combatant);

				if(this.menuUser.Count > 0)
				{
					this.CheckMenuIndex();
					this.menuUser[this.menuIndex].Battle.BattleMenu.Reset(true);

					if(this.currentSystem != null)
					{
						this.menuUser[this.menuIndex].Battle.TurnControlAllowed = combatant.Battle.TurnControlAllowed;
						combatant.Battle.TurnControlAllowed = AllowTurnControl.None;
						this.menuUser[this.menuIndex].Battle.TurnCameraControlAllowed = combatant.Battle.TurnCameraControlAllowed;
						combatant.Battle.TurnCameraControlAllowed = AllowTurnControl.None;
						this.currentSystem.SelectingCombatant = this.menuUser[this.menuIndex];
						this.TransferPlayerControl(this.menuUser[this.menuIndex], false);
					}

					if(!ORK.BattleSettings.camera.IsNone &&
						this.menuUser[this.menuIndex].GameObject != null)
					{
						Transform user = this.menuUser[this.menuIndex].GameObject.transform;
						ORK.BattleSettings.camera.SetMenuUser(user, user);
					}
				}
				else
				{
					if(!ORK.BattleSettings.camera.IsNone &&
						this.menuUser.Count == 0)
					{
						ORK.BattleSettings.camera.SetMenuUser(null, null);
					}
				}
			}
		}

		public void ClearMenuUsers()
		{
			for(int i = 0; i < this.menuUser.Count; i++)
			{
				this.menuUser[i].Battle.EndBattleMenu(true);
			}
			this.menuUser = new List<Combatant>();

			if(!ORK.BattleSettings.camera.IsNone)
			{
				ORK.BattleSettings.camera.SetMenuUser(null, null);
			}
		}

		public bool CombatantClicked(Combatant combatant)
		{
			if(this.menuUser.Count > 0)
			{
				return this.menuUser[this.menuIndex].Battle.BattleMenu.CombatantClicked(combatant);
			}
			else if(this.currentSystem != null)
			{
				return this.currentSystem.CombatantClicked(combatant);
			}
			return false;
		}

		public Combatant CursorOverCombatant
		{
			get { return this.cursorOverCombatant; }
		}

		public void ResetCursorOverCombatant()
		{
			this.cursorOverCombatant = null;
			ORK.GUI.Drag.CheckBattleCursorOver();
		}

		public bool CombatantCursorOver(Combatant combatant)
		{
			bool changed = this.cursorOverCombatant != combatant;
			this.cursorOverCombatant = combatant;

			if(this.IsTargetSelectionActive)
			{
				ORK.BattleSettings.CursorOverTargetInformation(combatant, changed);
			}
			if(this.menuUser.Count > 0)
			{
				return this.menuUser[this.menuIndex].Battle.BattleMenu.CombatantCursorOver(combatant, changed);
			}
			else if(this.SelectingCombatant != null &&
				this.SelectingCombatant.Actions.IsChoosing &&
				this.SelectingCombatant.Battle.BattleMenu != null)
			{
				return this.SelectingCombatant.Battle.BattleMenu.CombatantCursorOver(combatant, changed);
			}
			return false;
		}

		private void CheckMenuIndex()
		{
			if(this.menuIndex < 0)
			{
				this.menuIndex = this.menuUser.Count - 1;
			}
			else if(this.menuIndex >= this.menuUser.Count)
			{
				this.menuIndex = 0;
			}
		}

		public void ChangeMenuUserIndex(int change)
		{
			if(this.menuUser.Count > 1 &&
				this.menuUser[this.menuIndex].Battle.BattleMenu.Controlable)
			{
				// old user
				if(this.menuUser[this.menuIndex].Battle.BattleMenu.Box != null)
				{
					this.menuUser[this.menuIndex].Battle.BattleMenu.Box.Audio.PlayUserChange();
				}
				this.menuUser[this.menuIndex].Battle.BattleMenu.Reset(false);

				AllowTurnControl control = this.menuUser[this.menuIndex].Battle.TurnControlAllowed;
				this.menuUser[this.menuIndex].Battle.TurnControlAllowed = AllowTurnControl.None;
				AllowTurnControl camControl = this.menuUser[this.menuIndex].Battle.TurnCameraControlAllowed;
				this.menuUser[this.menuIndex].Battle.TurnCameraControlAllowed = AllowTurnControl.None;

				// change user
				this.menuIndex += change;
				this.CheckMenuIndex();

				// new user
				this.menuUser[this.menuIndex].Battle.BattleMenu.Reset(true);
				if(this.currentSystem != null)
				{
					this.menuUser[this.menuIndex].Battle.TurnControlAllowed = control;
					this.menuUser[this.menuIndex].Battle.TurnCameraControlAllowed = camControl;
					this.currentSystem.SelectingCombatant = this.menuUser[this.menuIndex];
					this.TransferPlayerControl(this.menuUser[this.menuIndex], false);
				}

				if(this.menuUser[this.menuIndex].GameObject != null &&
					!ORK.BattleSettings.camera.IsNone)
				{
					Transform user = this.menuUser[this.menuIndex].GameObject.transform;
					ORK.BattleSettings.camera.SetMenuUser(user, user);
				}
			}
		}

		public void ChangeMenuAbilityLevel(int change)
		{
			if(this.menuUser.Count > 0)
			{
				this.menuUser[this.menuIndex].Battle.BattleMenu.ChangeAbilityLevel(change);
			}
		}

		public void BattleMenuCanceled(Combatant user)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.BattleMenuCanceled(user);
			}
		}

		public Combatant SelectingCombatant
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.SelectingCombatant;
				}
				return null;
			}
		}

		public bool IsTargetSelectionActive
		{
			get { return this.targetSelectionActive > 0; }
			set
			{
				bool tmp = this.targetSelectionActive > 0;
				if(value)
				{
					this.targetSelectionActive++;
				}
				else
				{
					this.targetSelectionActive--;
				}
				if(this.targetSelectionActive < 0)
				{
					this.targetSelectionActive = 0;
				}
			}
		}


		/*
		============================================================================
		Control block functions
		============================================================================
		*/
		public void DoBattleBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.Battle == this.currentSystem.playerControl)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(BattleControlBlock.Battle == this.currentSystem.cameraControl)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
		}

		public void DoBattleMenuBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(this.currentSystem.playerBattleMenu)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(this.currentSystem.cameraBattleMenu)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
			else
			{
				if(ORK.Battle.Settings.fieldMode.playerBattleMenu)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(ORK.Battle.Settings.fieldMode.cameraBattleMenu)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
		}

		public void DoAllActionsBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.AllActions == this.currentSystem.playerControl)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(BattleControlBlock.AllActions == this.currentSystem.cameraControl)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
		}

		public void DoPlayerActionsBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.PlayerActions == this.currentSystem.playerControl)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(BattleControlBlock.PlayerActions == this.currentSystem.cameraControl)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
			else
			{
				if(ORK.Battle.Settings.fieldMode.blockPlayerControl)
				{
					ORK.Control.SetBlockPlayer(add, true);
				}
				if(ORK.Battle.Settings.fieldMode.blockCameraControl)
				{
					ORK.Control.SetBlockCamera(add, true);
				}
			}
		}

		public void AllowPlayerTurnControl(int add, Combatant combatant, AllowTurnControl state)
		{
			if(this.currentSystem != null &&
				combatant != null &&
				combatant.GameObject != null)
			{
				if(BattleControlBlock.Battle == this.currentSystem.playerControl &&
					this.currentSystem.playerControlAllowTurn == state &&
					((add < 0 && ORK.Control.ControlledPlayer == combatant.GameObject) ||
						(add > 0 && combatant.Battle.TurnControlAllowed == state)))
				{
					ORK.Control.SetBlockPlayer(add, true);
					combatant.Battle.TurnControlAllowed = add < 0 ? state : AllowTurnControl.None;
				}
				if(BattleControlBlock.Battle == this.currentSystem.cameraControl &&
					this.currentSystem.cameraControlAllowTurn == state &&
					((add < 0 && ORK.Control.ControlledPlayer == combatant.GameObject) ||
						(add > 0 && combatant.Battle.TurnCameraControlAllowed == state)))
				{
					ORK.Control.SetBlockCamera(add, true);
					combatant.Battle.TurnCameraControlAllowed = add < 0 ? state : AllowTurnControl.None;
				}
			}
		}

		public void TransferPlayerControl(Combatant combatant, bool reset)
		{
			if(this.currentSystem != null &&
				this.currentSystem.transferPlayerControl &&
				combatant != null &&
				(reset || this.currentSystem.SelectingCombatant == combatant) &&
				combatant.GameObject != null &&
				combatant.IsPlayerControlled() &&
				!combatant.IsAIControlled())
			{
				if(!reset)
				{
					ORK.Control.ControlledPlayer = combatant.GameObject;
				}
				else if(ORK.Control.ControlledPlayer == combatant.GameObject)
				{
					ORK.Control.ResetControlledPlayer();
				}
			}
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public bool CanUseMoveAI(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				return combatant.Object.MoveAI != null &&
					this.currentSystem.allowMoveAI &&
					(!this.currentSystem.blockInBattleMoveAI ||
						!combatant.Battle.InBattle ||
						(this.currentSystem.allowInTurnMoveAI &&
							CombatantTurnState.InTurn == combatant.Battle.TurnState)) &&
					(!combatant.Battle.InBattle ||
						this.grid == null) &&
					(!this.currentSystem.useMoveAIRange ||
						this.currentSystem.moveAIRange.InRange(combatant,
							ORK.Game.ActiveGroup.GetSpawnedBattleLeader()));
			}
			return combatant.Object.MoveAI != null &&
				(!ORK.BattleSettings.useMoveAIRange ||
					ORK.BattleSettings.moveAIRange.InRange(combatant, ORK.Game.ActiveGroup.Leader));
		}

		public void DoMoveAIBlock(int add)
		{
			if(this.currentSystem != null && !this.currentSystem.allowMoveAI)
			{
				ORK.Control.SetBlockMoveAI(add);
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			// max battle group
			if(ORK.SaveGameMenu.savePlayerMaxBattleGroupSize)
			{
				data.Set("maxPlayerBattleGroupSize", this.maxPlayerBattleGroupSize);
			}

			// battle gains
			if(ORK.SaveGameMenu.saveBattleGains)
			{
				// loot
				if(this.loot.Count > 0)
				{
					DataObject[] lootData = new DataObject[this.loot.Count];
					for(int i = 0; i < lootData.Length; i++)
					{
						lootData[i] = this.loot[i].SaveGame();
					}
					data.Set("loot", lootData);
				}

				// exp gains
				if(this.expGains.Count > 0)
				{
					DataObject expGainsData = new DataObject();
					foreach(KeyValuePair<int, List<ExperienceLoot>> pair in this.expGains)
					{
						DataObject[] expLootData = new DataObject[pair.Value.Count];
						for(int i = 0; i < expLootData.Length; i++)
						{
							expLootData[i] = pair.Value[i].SaveGame();
						}
						expGainsData.Set(pair.Key.ToString(), expLootData);
					}
					data.Set("expGains", expGainsData);
				}

				// normal SV gains
				if(this.normalSVGains.Count > 0)
				{
					DataObject normalSVGainsData = new DataObject();
					Dictionary<string, int> tmpGain = new Dictionary<string, int>();
					foreach(KeyValuePair<int, int> pair in this.normalSVGains)
					{
						tmpGain.Add(pair.Key.ToString(), pair.Value);
					}
					normalSVGainsData.SetData<int>(tmpGain, typeof(int));
					data.Set("normalSVGains", normalSVGainsData);
				}
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.ClearGains();

			if(data != null)
			{
				// max battle group
				this.maxPlayerBattleGroupSize = ORK.GameSettings.maxBattleGroup;
				if(ORK.SaveGameMenu.savePlayerMaxBattleGroupSize)
				{
					data.Get("maxPlayerBattleGroupSize", ref this.maxPlayerBattleGroupSize);
				}

				// battle gains
				if(ORK.SaveGameMenu.saveBattleGains)
				{
					// loot
					DataObject[] lootData = data.GetFileArray("loot");
					if(lootData != null)
					{
						for(int i = 0; i < lootData.Length; i++)
						{
							IShortcut tmpShortcut = ShortcutHelper.Load(lootData[i]);
							if(tmpShortcut != null)
							{
								this.loot.Add(tmpShortcut);
							}
						}
					}

					// exp gains
					DataObject expGainsData = data.GetFile("expGains");
					if(expGainsData != null)
					{
						Dictionary<string, DataObject[]> expLootData = data.GetData<DataObject[]>(typeof(DataObject[]));
						if(expLootData != null && expLootData.Count > 0)
						{
							foreach(KeyValuePair<string, DataObject[]> pair in expLootData)
							{
								List<ExperienceLoot> list = new List<ExperienceLoot>();
								for(int i = 0; i < pair.Value.Length; i++)
								{
									list.Add(new ExperienceLoot(pair.Value[i]));
								}
								this.expGains.Add(int.Parse(pair.Key), list);
							}
						}
					}

					// normal SV gains
					DataObject noralSVGainsData = data.GetFile("normalSVGains");
					if(noralSVGainsData != null)
					{
						Dictionary<string, int> tmpGain = noralSVGainsData.GetData<int>(typeof(int));
						if(tmpGain != null && tmpGain.Count > 0)
						{
							foreach(KeyValuePair<string, int> pair in tmpGain)
							{
								this.normalSVGains.Add(int.Parse(pair.Key), pair.Value);
							}
						}
					}
				}
			}
		}
	}
}
