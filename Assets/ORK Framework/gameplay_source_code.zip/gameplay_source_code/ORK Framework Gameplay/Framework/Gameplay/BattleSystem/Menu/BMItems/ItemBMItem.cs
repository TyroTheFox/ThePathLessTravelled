
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ItemBMItem : BMItem
	{
		private ItemShortcut item;

		private bool blockBattleCamera = false;

		public ItemBMItem(ItemShortcut item, ChoiceContent content) : this(item, content, false)
		{

		}

		public ItemBMItem(ItemShortcut item, ChoiceContent content, bool blockBattleCamera)
		{
			this.item = item;
			this.content = content;
			this.blockBattleCamera = blockBattleCamera;
		}

		public override void CreateDrag(Combatant owner)
		{
			if(this.content.Data == null)
			{
				// drag+drop
				this.content.isDragable = ORK.BattleSettings.bmDrag;
				this.content.clickCount = ORK.BattleSettings.bmClick ? ORK.BattleSettings.bmClickCount : 0;
				this.content.isTooltip = ORK.BattleSettings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.Data = this.item.GetDrag(owner);
				}
			}

			// portrait
			if(this.content.portrait == null &&
				owner.Battle.BattleMenu.Settings.showItemPortraits)
			{
				this.content.portrait = this.item.GetPortrait(owner.Battle.BattleMenu.Settings.itemPortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.item.CanUse(owner, true, true) &&
				(this.item.IsNoneTarget() ||
					this.item.HasPossibleTargets(owner, null));
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.Battle.BattleMenu.TargetHighlight.SelectAction(this.item);
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.Battle.BattleMenu != null)
			{
				if(this.item.Setting.targetSettings.TargetSelf())
				{
					BaseAction action = new ItemAction(owner, this.item);
					action.blockBattleCamera = this.blockBattleCamera;
					action.SetTarget(owner);
					owner.Battle.BattleMenu.AddAction(action);
					return true;
				}
				else if(this.item.IsNoneTarget())
				{
					if(ORK.Battle.Grid != null &&
						this.item.Setting.targetSettings.noneSelectGridCell)
					{
						owner.Battle.BattleMenu.StartGridTargetCellSelection(this.item, this.blockBattleCamera);
						owner.Battle.BattleMenu.CloseSilent();
					}
					else
					{
						BaseAction action = new ItemAction(owner, this.item);
						action.blockBattleCamera = this.blockBattleCamera;
						if(action.targetRaycast.NeedInteraction())
						{
							owner.Battle.BattleMenu.RayAction = action;
							owner.Battle.BattleMenu.CloseSilent();
						}
						else
						{
							if(action.targetRaycast.active)
							{
								action.targetRaycast.GetAutoPoint(owner.GameObject, VectorHelper.GetScreenCenter(), action);
							}
							owner.Battle.BattleMenu.AddAction(action);
						}
					}
					return true;
				}
				else
				{
					// use on group target
					if(owner.Battle.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.Battle.BattleMenu.AddAction(action);
							return true;
						}
					}
					// use on individual target
					if(owner.Battle.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.Battle.BattleMenu.AddAction(action);
							return true;
						}
					}

					// display target menu
					owner.Battle.BattleMenu.TargetHighlight.AcceptAction(this.item);
					List<BMItem> list = new List<BMItem>();

					int selection = -1;
					if(this.item.IsSingleTarget())
					{
						for(int i = 0; i < owner.Battle.BattleMenu.TargetHighlight.AvailableTargets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]);
							list.Add(new TargetBMItem(
								owner.Battle.BattleMenu.GetCombatantChoice(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]),
								this.item, tmp, this.blockBattleCamera));

							if(selection < 0 && this.item.Setting.targetSettings.useAutoTarget &&
								this.item.Setting.targetSettings.autoTarget.Check(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.item.IsGroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								this.item.Setting.targetSettings.targetType,
								owner.Battle.BattleMenu.Settings.contentLayout),
							this.item, new List<Combatant>(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets),
							this.blockBattleCamera));
					}

					if(list.Count > 0)
					{
						if(ORK.BattleSettings.useTargetMenu)
						{
							owner.Battle.BattleMenu.Settings.AddBack(list);
						}

						owner.Battle.BattleMenu.TargetHighlight.AcceptHighlights();
						owner.Battle.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
						return true;
					}
				}
			}
			return false;
		}
	}
}
