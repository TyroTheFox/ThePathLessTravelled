﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class StoredCell : ISaveData
	{
		private bool isStored = false;

		private Vector3 coord = Vector3.zero;

		private int direction = 0;

		public StoredCell()
		{

		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public bool IsStored
		{
			get { return this.isStored; }
		}

		public void Store(Combatant combatant)
		{
			this.isStored = true;
			this.coord = combatant.Grid.Cell.CubeCoord.ToVector3();
			this.direction = BattleGridHelper.GetCombatantDirection(combatant, true);
		}

		public void Restore(Combatant combatant)
		{
			if(this.isStored &&
				ORK.Battle.Grid != null)
			{
				BattleGridCellComponent cell = ORK.Battle.Grid.GetCell(CubeCoord.FromVector3(this.coord));
				if(cell != null &&
					cell.IsEmpty &&
					!cell.IsBlocked)
				{
					float angle = BattleGridHelper.DirectionToAngle(this.direction, true);
					if(combatant.GameObject == null)
					{
						combatant.Object.Spawn(cell.transform.position,
							true, angle, false, Vector3.zero);
					}
					else
					{
						combatant.Object.PlaceAt(cell.transform.position,
							true, angle, false, Vector3.zero);
					}
					combatant.Grid.Cell = cell;
				}
			}
		}

		public void Clear()
		{
			this.isStored = false;
			this.coord = Vector3.zero;
			this.direction = 0;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			data.Set("isStored", this.isStored);
			data.Set("coord", ArrayHelper.ToArray(this.coord));
			data.Set("direction", direction);
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("isStored", ref this.isStored);
				data.Get("direction", ref this.direction);

				float[] tmp = null;
				data.Get("coord", out tmp);
				if(tmp != null)
				{
					this.coord = ArrayHelper.GetVector3(tmp);
				}
			}
		}
	}
}
