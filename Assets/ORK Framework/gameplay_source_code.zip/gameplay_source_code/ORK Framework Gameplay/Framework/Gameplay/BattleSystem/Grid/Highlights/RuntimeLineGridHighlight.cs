﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RuntimeLineGridHighlight
	{
		private LineGridHighlight settings;

		private bool allowDiagonal = false;


		// cells
		private HashSet<BattleGridCellComponent> cellHash = new HashSet<BattleGridCellComponent>();

		private List<BattleGridCellComponent> cells = new List<BattleGridCellComponent>();

		private bool changed = false;


		// prefabs
		private List<GameObject> spawnedPrefabs = new List<GameObject>();

		private int currentCount = 0;

		private bool hidden = false;

		public RuntimeLineGridHighlight(LineGridHighlight settings, GridHighlightType type)
		{
			this.settings = settings;
			this.allowDiagonal = this.settings.distanceToCenter <= 0 &&
				GridHighlightType.MovePath == type &&
				ORK.Battle.Settings.gridSettings.IsSquare &&
				ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove;
		}

		public bool Hidden
		{
			get { return this.hidden; }
			set
			{
				if(this.hidden != value)
				{
					this.hidden = value;

					for(int i = 0; i < this.currentCount; i++)
					{
						if(i < this.spawnedPrefabs.Count &&
							this.spawnedPrefabs[i].activeInHierarchy == this.hidden)
						{
							this.spawnedPrefabs[i].SetActive(!this.hidden);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Highlight(BattleGridCellComponent cell)
		{
			if(!this.cellHash.Contains(cell))
			{
				this.cellHash.Add(cell);
				this.cells.Add(cell);
				this.changed = true;
			}

			if(this.changed)
			{
				this.Update();
			}
		}

		public void Highlight(List<BattleGridCellComponent> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(!this.cellHash.Contains(list[i]))
				{
					this.cellHash.Add(list[i]);
					this.cells.Add(list[i]);
					this.changed = true;
				}
			}

			if(this.changed)
			{
				this.Update();
			}
		}

		public void StopHighlight(BattleGridCellComponent cell)
		{
			if(this.cellHash.Contains(cell))
			{
				this.cellHash.Remove(cell);
				this.cells.Remove(cell);
				this.changed = true;
			}

			if(this.changed)
			{
				this.Update();
			}
		}

		public void StopHighlight(List<BattleGridCellComponent> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(this.cellHash.Contains(list[i]))
				{
					this.cellHash.Remove(list[i]);
					this.cells.Remove(list[i]);
					this.changed = true;
				}
			}

			if(this.changed)
			{
				this.Update();
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Update()
		{
			if(this.changed)
			{
				this.changed = false;

				if(this.cells.Count > 0)
				{
					List<Edge> edges = new List<Edge>();

					int neighbourCount;
					CubeCoord[] directions;
					if(this.settings.enclosedCells &&
						this.settings.distanceToCenter > 0)
					{
						this.GetEdges(new List<BattleGridCellComponent>(this.cells),
							new HashSet<BattleGridCellComponent>(this.cellHash),
							edges, out neighbourCount, out directions, true);
					}
					else
					{
						this.GetEdges(this.cells, this.cellHash, edges, out neighbourCount, out directions, false);
					}

					if(edges.Count > 0)
					{
						int count = 0;
						List<Vector3> positions = new List<Vector3>();
						while(edges.Count > 0)
						{
							this.GetPositions(edges, neighbourCount, positions);

							if(count >= this.spawnedPrefabs.Count)
							{
								this.spawnedPrefabs.Add(GameObject.Instantiate(this.settings.prefab, ORK.Battle.Grid.transform));
								if(this.hidden)
								{
									this.spawnedPrefabs[count].SetActive(false);
								}
							}
							else if(!this.spawnedPrefabs[count].activeInHierarchy &&
								!this.hidden)
							{
								this.spawnedPrefabs[count].SetActive(true);
							}
							LineRenderer lineRenderer = this.spawnedPrefabs[count].GetComponentInChildren<LineRenderer>();
							if(lineRenderer != null)
							{
								lineRenderer.useWorldSpace = true;
								lineRenderer.positionCount = positions.Count;
								lineRenderer.SetPositions(positions.ToArray());
							}
							count++;
						}
						this.currentCount = count;

						if(count < this.spawnedPrefabs.Count)
						{
							for(int i = count; i < this.spawnedPrefabs.Count; i++)
							{
								this.spawnedPrefabs[i].SetActive(false);
							}
						}
					}
					else
					{
						this.currentCount = 0;
						for(int i = 0; i < this.spawnedPrefabs.Count; i++)
						{
							this.spawnedPrefabs[i].SetActive(false);
						}
					}
				}
				else
				{
					this.currentCount = 0;
					for(int i = 0; i < this.spawnedPrefabs.Count; i++)
					{
						this.spawnedPrefabs[i].SetActive(false);
					}
				}
			}
		}

		private void GetEdges(List<BattleGridCellComponent> tmpCells, HashSet<BattleGridCellComponent> tmpHash,
			List<Edge> edges, out int neighbourCount, out CubeCoord[] directions, bool enclosed)
		{
			Dictionary<BattleGridCellComponent, int> checkEnclosed = enclosed ?
				new Dictionary<BattleGridCellComponent, int>() : null;

			// square grid
			if(ORK.Battle.Settings.gridSettings.IsSquare)
			{
				directions = BattleGridHelper.SquareDirectionsDiagonal;
				neighbourCount = directions.Length;

				for(int i = 0; i < tmpCells.Count; i++)
				{
					for(int j = 0; j < neighbourCount; j++)
					{
						if(this.settings.distanceToCenter > 0)
						{
							BattleGridCellComponent neighbourCell = tmpCells[i].parentGrid.GetCell(
								tmpCells[i].CubeCoord + directions[j]);
							if(neighbourCell == null ||
								!tmpHash.Contains(neighbourCell))
							{
								if(j % 2 == 0)
								{
									edges.Add(new EdgeSquare(tmpCells[i], neighbourCell, j));

									if(checkEnclosed != null &&
										neighbourCell != null)
									{
										if(checkEnclosed.ContainsKey(neighbourCell))
										{
											checkEnclosed[neighbourCell]++;
										}
										else
										{
											checkEnclosed.Add(neighbourCell, 1);
										}
									}
								}
								else
								{
									BattleGridCellComponent other = tmpCells[i].parentGrid.GetCell(
										tmpCells[i].CubeCoord + directions[j - 1]);
									if(tmpHash.Contains(other))
									{
										other = tmpCells[i].parentGrid.GetCell(
											tmpCells[i].CubeCoord + directions[j == neighbourCount - 1 ? 0 : j + 1]);
										if(tmpHash.Contains(other))
										{
											edges.Add(new EdgeSquare(tmpCells[i], neighbourCell, j));
										}
									}
								}
							}
						}
						// line
						else
						{
							BattleGridCellComponent neighbourCell = tmpCells[i].parentGrid.GetCell(
								tmpCells[i].CubeCoord + directions[j]);
							if(neighbourCell == null ||
								!tmpHash.Contains(neighbourCell))
							{
								edges.Add(new EdgeSquare(tmpCells[i], neighbourCell, -1));
								break;
							}
						}
					}
				}

				if(checkEnclosed != null &&
					this.CheckEnclosed(tmpCells, tmpHash, edges,
						BattleGridHelper.SquareDirectionsNonDiagonal, checkEnclosed))
				{
					edges.Clear();
					this.GetEdges(tmpCells, tmpHash, edges, out neighbourCount, out directions, false);
				}
			}
			// hex grid
			else
			{
				directions = BattleGridHelper.HexagonalDirections;
				neighbourCount = directions.Length;

				for(int i = 0; i < tmpCells.Count; i++)
				{
					for(int j = 0; j < neighbourCount; j++)
					{
						BattleGridCellComponent neighbourCell = tmpCells[i].parentGrid.GetCell(
							tmpCells[i].CubeCoord +directions[j]);
						if(neighbourCell == null ||
							!tmpHash.Contains(neighbourCell))
						{
							if(this.settings.distanceToCenter > 0)
							{
								edges.Add(new EdgeHex(tmpCells[i], neighbourCell, j));

								if(checkEnclosed != null &&
									neighbourCell != null)
								{
									if(checkEnclosed.ContainsKey(neighbourCell))
									{
										checkEnclosed[neighbourCell]++;
									}
									else
									{
										checkEnclosed.Add(neighbourCell, 1);
									}
								}
							}
							else
							{
								edges.Add(new EdgeHex(tmpCells[i], neighbourCell, -1));
								break;
							}
						}
					}
				}

				if(checkEnclosed != null &&
					this.CheckEnclosed(tmpCells, tmpHash, edges, directions, checkEnclosed))
				{
					edges.Clear();
					this.GetEdges(tmpCells, tmpHash, edges, out neighbourCount, out directions, false);
				}
			}
		}

		private void GetPositions(List<Edge> edges, int neighbourCount, List<Vector3> positions)
		{
			if(edges.Count > 0)
			{
				positions.Clear();

				Edge next = null;
				Edge current = edges[0];
				edges.RemoveAt(0);

				if(this.settings.distanceToCenter > 0)
				{
					positions.Add(ORK.Battle.Settings.gridSettings.GetCorner(
						current.Cell.transform.position +
							current.Cell.Settings.lineHighlightPositionOffset +
							this.settings.positionOffset,
						current.Direction, this.settings.distanceToCenter));
				}
				else
				{
					positions.Add(current.Cell.transform.position +
						current.Cell.Settings.lineHighlightPositionOffset +
						this.settings.positionOffset);
				}

				while(current != null)
				{
					next = null;

					for(int j = 0; j < edges.Count; j++)
					{
						if(current.IsConnected(edges[j], neighbourCount, this.allowDiagonal))
						{
							next = edges[j];
							edges.RemoveAt(j);

							Vector3 tmpPosition = Vector3.zero;
							if(this.settings.distanceToCenter > 0)
							{
								tmpPosition = ORK.Battle.Settings.gridSettings.GetCorner(
									next.Cell.transform.position +
										next.Cell.Settings.lineHighlightPositionOffset +
										this.settings.positionOffset,
									next.Direction, this.settings.distanceToCenter);
							}
							else
							{
								tmpPosition = next.Cell.transform.position +
									next.Cell.Settings.lineHighlightPositionOffset +
									this.settings.positionOffset;
							}

							if(this.settings.mergeDistance > 0 &&
								Vector3.Distance(positions[positions.Count - 1], tmpPosition) <= this.settings.mergeDistance)
							{
								positions[positions.Count - 1] = (positions[positions.Count - 1] + tmpPosition) / 2;
							}
							else
							{
								positions.Add(tmpPosition);
							}

							break;
						}
					}
					current = next;
				}
			}
		}

		private bool CheckEnclosed(List<BattleGridCellComponent> tmpCells,
			HashSet<BattleGridCellComponent> tmpHash,
			List<Edge> edges, CubeCoord[] directions,
			Dictionary<BattleGridCellComponent, int> enclosed)
		{
			bool hasEnclosed = false;
			HashSet<BattleGridCellComponent> ignore = new HashSet<BattleGridCellComponent>();
			HashSet<BattleGridCellComponent> visited = new HashSet<BattleGridCellComponent>();
			foreach(KeyValuePair<BattleGridCellComponent, int> pair in enclosed)
			{
				if(pair.Value != directions.Length &&
					!ignore.Contains(pair.Key) &&
					!visited.Contains(pair.Key))
				{
					this.CheckEnclosedNeighbours(pair.Key, directions, enclosed, ignore, visited);
				}
			}

			HashSet<BattleGridCellComponent> isEnclosed = new HashSet<BattleGridCellComponent>();
			foreach(KeyValuePair<BattleGridCellComponent, int> pair in enclosed)
			{
				int count = pair.Value;
				if(count < directions.Length &&
					!ignore.Contains(pair.Key))
				{
					for(int i = 0; i < directions.Length; i++)
					{
						BattleGridCellComponent neighbourCell = pair.Key.parentGrid.GetCell(
							pair.Key.CubeCoord + directions[i]);
						if(neighbourCell == null ||
							ignore.Contains(neighbourCell))
						{
							break;
						}
						else if(!this.cellHash.Contains(neighbourCell) &&
							enclosed.ContainsKey(neighbourCell))
						{
							count++;
							if(count == directions.Length)
							{
								break;
							}
						}
					}
				}
				if(count == directions.Length)
				{
					tmpCells.Add(pair.Key);
					tmpHash.Add(pair.Key);
					hasEnclosed = true;
				}
			}
			return hasEnclosed;
		}

		private void CheckEnclosedNeighbours(BattleGridCellComponent cell, CubeCoord[] directions,
			Dictionary<BattleGridCellComponent, int> enclosed,
			HashSet<BattleGridCellComponent> ignore, HashSet<BattleGridCellComponent> visited)
		{
			visited.Add(cell);
			for(int i = 0; i < directions.Length; i++)
			{
				BattleGridCellComponent neighbourCell = cell.parentGrid.GetCell(cell.CubeCoord + directions[i]);
				if(neighbourCell == null ||
					ignore.Contains(neighbourCell) ||
					(!this.cellHash.Contains(neighbourCell) &&
						!enclosed.ContainsKey(neighbourCell)))
				{
					if(!ignore.Contains(cell))
					{
						ignore.Add(cell);
						break;
					}
				}
				else if(!visited.Contains(neighbourCell) &&
					enclosed.ContainsKey(neighbourCell))
				{
					this.CheckEnclosedNeighbours(neighbourCell, directions, enclosed, ignore, visited);
					if(ignore.Contains(neighbourCell))
					{
						if(!ignore.Contains(cell))
						{
							ignore.Add(cell);
							break;
						}
					}
				}
			}
		}

		private abstract class Edge
		{
			protected BattleGridCellComponent cell;

			protected BattleGridCellComponent toCell;

			protected int direction = 0;

			public Edge(BattleGridCellComponent cell, BattleGridCellComponent toCell, int direction)
			{
				this.cell = cell;
				this.toCell = toCell;
				this.direction = direction;
			}

			public BattleGridCellComponent Cell
			{
				get { return this.cell; }
			}

			public BattleGridCellComponent ToCell
			{
				get { return this.toCell; }
			}

			public int Direction
			{
				get { return this.direction; }
			}

			public abstract bool IsConnected(Edge other, int neighbourCount, bool allowDiagonal);
		}

		private class EdgeSquare : Edge
		{
			public EdgeSquare(BattleGridCellComponent cell, BattleGridCellComponent toCell, int direction) : base(cell, toCell, direction)
			{

			}

			public override bool IsConnected(Edge other, int directionCount, bool allowDiagonal)
			{
				if(this.direction == -1)
				{
					int distance = this.cell.CubeCoord.Distance(other.Cell.CubeCoord, true);
					if(distance == 1)
					{
						return true;
					}
					else if(allowDiagonal &&
						distance == 2 &&
						CubeCoord.IsSquareDiagonal(this.cell.CubeCoord, other.Cell.CubeCoord))
					{
						return true;
					}
				}
				else
				{
					if(this.cell == other.Cell)
					{
						return this.direction % 2 == 0 &&
							other.Direction % 2 == 0 &&
							(this.direction + 2 == other.Direction ||
								(this.direction == directionCount - 2 &&
									other.Direction == 0));
					}
					else if(this.cell.CubeCoord.Distance(other.Cell.CubeCoord, true) == 1)
					{
						if(this.direction == other.Direction ||
							this.direction == other.Direction + 1 ||
							(this.direction == 0 &&
								other.Direction == directionCount - 1))
						{
							int tmp = this.direction % 2 == 0 ?
								this.direction + 2 : this.direction + 1;
							return this.cell.parentGrid.GetCell(this.cell.CubeCoord +
									BattleGridHelper.SquareDirectionsDiagonal[tmp >= directionCount ? tmp - directionCount : tmp]) ==
								other.Cell;
						}
					}
				}
				return false;
			}
		}

		private class EdgeHex : Edge
		{
			public EdgeHex(BattleGridCellComponent cell, BattleGridCellComponent toCell, int direction) : base(cell, toCell, direction)
			{

			}

			public override bool IsConnected(Edge other, int directionCount, bool allowDiagonal)
			{
				if(this.direction == -1)
				{
					return this.cell.CubeCoord.Distance(other.Cell.CubeCoord) == 1;
				}
				else
				{
					if(this.cell == other.Cell)
					{
						return this.direction + 1 == other.Direction ||
								(this.direction == directionCount - 1 &&
									other.Direction == 0);
					}
					else if(this.cell.CubeCoord.Distance(other.Cell.CubeCoord) == 1)
					{
						if(this.direction == other.Direction + 1 ||
							(this.direction == 0 &&
								other.Direction == directionCount - 1))
						{
							int tmp = this.direction + 1;
							return this.cell.parentGrid.GetCell(this.cell.CubeCoord +
									BattleGridHelper.HexagonalDirections[tmp >= directionCount ? tmp - directionCount : tmp]) ==
								other.Cell;
						}
					}
				}
				return false;
			}
		}
	}
}
