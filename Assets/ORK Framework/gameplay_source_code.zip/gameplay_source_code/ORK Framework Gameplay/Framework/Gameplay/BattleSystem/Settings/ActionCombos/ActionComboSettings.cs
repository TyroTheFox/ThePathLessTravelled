﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionComboSettings : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the action combo.", "")]
		[ORKEditorInfo("Base Settings", "Base settings of this action combo.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Decrease Time", "Select when the available time of combo actions will decrease:\n" +
			"- Always: Always during a combatant's turn.\n" +
			"- While Choosing: While the combatant is selecting an action.\n" +
			"- While In Action: While the combatant is performing an action.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ActionTimeDecreaseType decreaseTime = ActionTimeDecreaseType.Always;


		// actions
		[ORKEditorArray(false, "Add Stage", "Adds an action combo stage.", "",
			"Remove", "Removes this stage.", "",
			isMove=true, isCopy=true, noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Stage", "Define the actions that can trigger this stage and optional actions that replace them.\n" +
				"The stage is reset to stage 0 (first stage) when the action doesn't match one of the required actions " +
				"or the available time runs out.", ""
		})]
		public ActionComboStageSettings[] action = new ActionComboStageSettings[] {
			new ActionComboStageSettings()
		};

		// final action ?


		public ActionComboSettings()
		{

		}

		public ActionComboSettings(string name)
		{
			this.name = name;
		}
	}
}
