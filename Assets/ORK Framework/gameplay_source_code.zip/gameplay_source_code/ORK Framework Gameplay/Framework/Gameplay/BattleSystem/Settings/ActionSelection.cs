
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionSelection : BaseData
	{
		[ORKEditorHelp("Action Type", "Select the action type the combatant will perform:\n" +
			"- Attack: Performs a base attack.\n" +
			"- Counter Attack: Performs a counter attack. Counter attacks can't be countered.\n" +
			"- Ability: Uses an ability.\n" +
			"- Item: Uses an item.\n" +
			"- Defend: Uses the defend command.\n" +
			"- Escape: Uses the escape command.\n" +
			"- Death: The combatant dies.\n" +
			"- None: Does nothing.\n" +
			"- Change Member: The combatant is exchanged with a non-battle group member.\n" +
			"- Class Ability: Performs the combatant's class ability.\n" +
			"- Shortcut: Uses a shortcut slot of the combatant.", "")]
		public ActionSelectType type = ActionSelectType.Attack;


		// attack
		[ORKEditorHelp("Reset Index", "The attack index will be reset to 0 after the attack is used.\n" +
			"This only happens if the attack is used.", "")]
		[ORKEditorLayout("type", ActionSelectType.Attack)]
		public bool resetAttackIndex = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public BaseAttackSelection attack;


		// ability
		[ORKEditorHelp("Ability", "Select the ability the combatant will use.\n" +
			"If the combatant doesn't have the ability, the ability wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("type", ActionSelectType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Use Highest Level", "The highest available level of the ability will be used.", "")]
		public bool abilityUseHighestLevel = true;

		[ORKEditorHelp("Ability Level", "Define the ability level that will be used.\n" +
			"Uses the highest available level when the defined level exceeds the available levels.", "")]
		[ORKEditorLayout("abilityUseHighestLevel", false, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(1, false)]
		public int abilityLevel = 1;


		// item
		[ORKEditorHelp("Item", "Select the item the combatant will use.\n" +
			"If the combatant doesn't have the item in his inventory, the item wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", ActionSelectType.Item, endCheckGroup=true)]
		public int itemID = 0;


		// none
		[ORKEditorHelp("Is Silent", "The 'None' action will be silent, " +
			"i.e. no battle info will be displayed and no battle events will be used.", "")]
		[ORKEditorLayout("type", ActionSelectType.None, endCheckGroup=true)]
		public bool isSilent = false;


		// member index
		[ORKEditorHelp("Member Index", "The index of the non-battle member the combatant will be exchanged with.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("type", ActionSelectType.ChangeMember, endCheckGroup=true)]
		public int memberIndex = 0;


		// shortcut
		[ORKEditorLayout("type", ActionSelectType.Shortcut, endCheckGroup=true, autoInit=true)]
		public ShortcutSlot slot;

		public ActionSelection()
		{

		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public BaseAction GetAction(Combatant combatant, bool checkTime, bool checkUseCosts, bool blockActionCamera)
		{
			BaseAction action = null;
			this.GetAction(out action, combatant, checkTime, checkUseCosts,
				false, false, false, true, false, false, false, blockActionCamera);
			return action;
		}

		public bool GetAction(out BaseAction action, Combatant combatant, bool checkTime, bool checkUseCosts,
			bool onlyCursorOverTarget, bool cursorOverInRange, bool useCursorOverTarget,
			bool useAutoTarget, bool autoTargetOnly, bool noTargetSelection, bool needTargets, bool blockBattleCamera)
		{
			action = null;

			if(ActionSelectType.Attack == this.type)
			{
				if(!combatant.Status.Effects.BlockAttack)
				{
					AbilityShortcut ability = this.attack.GetAttack(combatant);

					if(ability != null &&
						(!onlyCursorOverTarget ||
							(ORK.Battle.CursorOverCombatant != null &&
								ability.CanTarget(combatant, ORK.Battle.CursorOverCombatant) &&
								(!cursorOverInRange || ability.InRange(combatant, ORK.Battle.CursorOverCombatant)))) &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useCursorOverTarget, useAutoTarget, autoTargetOnly,
							noTargetSelection, needTargets, blockBattleCamera, out action))
					{
						if(this.resetAttackIndex)
						{
							combatant.Abilities.ResetBaseAttack();
						}
						return true;
					}
				}
			}
			// counter
			else if(ActionSelectType.CounterAttack == this.type)
			{
				if(!combatant.Status.Effects.BlockAttack)
				{
					AbilityShortcut ability = combatant.Abilities.GetCounterAttack();

					if(ability != null &&
						(!onlyCursorOverTarget ||
							(ORK.Battle.CursorOverCombatant != null &&
								ability.CanTarget(combatant, ORK.Battle.CursorOverCombatant) &&
								(!cursorOverInRange || ability.InRange(combatant, ORK.Battle.CursorOverCombatant)))) &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useCursorOverTarget, useAutoTarget, autoTargetOnly,
							noTargetSelection, needTargets, blockBattleCamera, out action))
					{
						return true;
					}
				}
			}
			// ability
			else if(ActionSelectType.Ability == this.type)
			{
				if(!combatant.Status.Effects.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.Get(this.abilityID);

					if(ability != null &&
						(!onlyCursorOverTarget ||
							(ORK.Battle.CursorOverCombatant != null &&
								ability.CanTarget(combatant, ORK.Battle.CursorOverCombatant) &&
								(!cursorOverInRange || ability.InRange(combatant, ORK.Battle.CursorOverCombatant)))))
					{
						if(this.abilityUseHighestLevel)
						{
							ability.SetHighestUseLevel(combatant);
						}
						else
						{
							ability.SetUseLevel(this.abilityLevel);
						}

						if(ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useCursorOverTarget, useAutoTarget, autoTargetOnly,
							noTargetSelection, needTargets, blockBattleCamera, out action))
						{
							return true;
						}
					}
				}
			}
			// class ability
			else if(ActionSelectType.ClassAbility == this.type)
			{
				if(!combatant.Status.Effects.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.GetClassAbility();

					if(ability != null &&
						(!onlyCursorOverTarget ||
							(ORK.Battle.CursorOverCombatant != null &&
								ability.CanTarget(combatant, ORK.Battle.CursorOverCombatant) &&
								(!cursorOverInRange || ability.InRange(combatant, ORK.Battle.CursorOverCombatant)))) &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useCursorOverTarget, useAutoTarget, autoTargetOnly,
							noTargetSelection, needTargets, blockBattleCamera, out action))
					{
						return true;
					}
				}
			}
			// item
			else if(ActionSelectType.Item == this.type)
			{
				if(!combatant.Status.Effects.BlockItems)
				{
					ItemShortcut item = combatant.Inventory.GetItem(this.itemID);

					if(item != null &&
						(!onlyCursorOverTarget ||
							(ORK.Battle.CursorOverCombatant != null &&
								item.CanTarget(combatant, ORK.Battle.CursorOverCombatant) &&
								(!cursorOverInRange || item.Setting.InRange(combatant, ORK.Battle.CursorOverCombatant)))) &&
						ActionSelection.UseItem(
							combatant, item, checkTime, checkUseCosts,
							useCursorOverTarget, useAutoTarget, autoTargetOnly,
							noTargetSelection, needTargets, blockBattleCamera, out action))
					{
						return true;
					}
				}
			}
			// defend
			else if(ActionSelectType.Defend == this.type)
			{
				if(!combatant.Status.Effects.BlockDefend &&
					(!onlyCursorOverTarget ||
						ORK.Battle.CursorOverCombatant == combatant))
				{
					action = new DefendAction(combatant);
					action.blockBattleCamera = blockBattleCamera;
					return true;
				}
			}
			// escape
			else if(ActionSelectType.Escape == this.type)
			{
				if(!combatant.Status.Effects.BlockEscape &&
					(!onlyCursorOverTarget ||
						ORK.Battle.CursorOverCombatant == combatant))
				{
					action = new EscapeAction(combatant);
					action.blockBattleCamera = blockBattleCamera;
					return true;
				}
			}
			// death
			else if(ActionSelectType.Death == this.type)
			{
				if(!onlyCursorOverTarget ||
					ORK.Battle.CursorOverCombatant == combatant)
				{
					action = new DeathAction(combatant, false);
					action.blockBattleCamera = blockBattleCamera;
					return true;
				}
			}
			// none
			else if(ActionSelectType.None == this.type)
			{
				if(!onlyCursorOverTarget ||
					ORK.Battle.CursorOverCombatant == combatant)
				{
					action = new NoneAction(combatant, this.isSilent);
					action.blockBattleCamera = blockBattleCamera;
					return true;
				}
			}
			// change member
			else if(ActionSelectType.ChangeMember == this.type)
			{
				Combatant target = combatant.Group.NonBattleMemberAt(this.memberIndex);
				if(target != null &&
					(!onlyCursorOverTarget ||
						ORK.Battle.CursorOverCombatant == target))
				{
					action = new ChangeMemberAction(combatant, target);
					action.blockBattleCamera = blockBattleCamera;
					return true;
				}
			}
			// shortcut
			else if(ActionSelectType.Shortcut == this.type)
			{
				Combatant owner = null;
				IShortcut shortcut = this.slot.GetShortcut(combatant, out owner);
				if(shortcut != null)
				{
					// get ability from link
					if(shortcut is AbilityLinkShortcut)
					{
						shortcut = ((AbilityLinkShortcut)shortcut).Shortcut;
					}

					// disable active shortcut on 2nd call
					if(ORK.ShortcutSettings.deactivateOn2ndCall &&
						combatant.Shortcuts.Active == shortcut)
					{
						combatant.Shortcuts.DisableActive();
						return true;
					}

					if(!onlyCursorOverTarget ||
						(ORK.Battle.CursorOverCombatant != null &&
							shortcut.CanTarget(combatant, ORK.Battle.CursorOverCombatant)))
					{
						// equip, special actions
						if(shortcut is EquipShortcut ||
							shortcut is DefendShortcut ||
							shortcut is EscapeShortcut ||
							shortcut is NoneShortcut ||
							shortcut is GridMoveShortcut ||
							shortcut is GridOrientationShortcut ||
							shortcut is GridExamineShortcut)
						{
							List<Combatant> list = new List<Combatant>();
							list.Add(combatant);
							return shortcut.Use(owner, list, true);
						}
						// item
						else if(shortcut is ItemShortcut)
						{
							ItemShortcut item = (ItemShortcut)shortcut;
							return (!onlyCursorOverTarget || !cursorOverInRange ||
									item.Setting.InRange(combatant, ORK.Battle.CursorOverCombatant)) &&
								ActionSelection.UseItem(combatant, item, true, true,
									useCursorOverTarget, useAutoTarget, autoTargetOnly,
									noTargetSelection, needTargets, blockBattleCamera, out action);
						}
						// ability
						else if(shortcut is AbilityShortcut)
						{
							AbilityShortcut ability = (AbilityShortcut)shortcut;
							return (!onlyCursorOverTarget || !cursorOverInRange ||
									ability.InRange(combatant, ORK.Battle.CursorOverCombatant)) &&
								ActionSelection.UseAbility(combatant, ability, true, true,
									useCursorOverTarget, useAutoTarget, autoTargetOnly,
									noTargetSelection, needTargets, blockBattleCamera, out action);
						}
					}
				}
			}

			return false;
		}


		/*
		============================================================================
		Tooltip functions
		============================================================================
		*/
		public bool ShowTooltip(Combatant combatant, float autoCloseTime, bool closeOn2nd)
		{
			if(ActionSelectType.Attack == this.type)
			{
				if(!combatant.Status.Effects.BlockAttack)
				{
					AbilityShortcut ability = this.attack.GetAttack(combatant);

					if(ability != null)
					{
						ORK.GUI.Tooltip.ForceTooltip(
							new PreviewSelection(combatant, null, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// counter
			else if(ActionSelectType.CounterAttack == this.type)
			{
				if(!combatant.Status.Effects.BlockAttack)
				{
					AbilityShortcut ability = combatant.Abilities.GetCounterAttack();

					if(ability != null)
					{
						ORK.GUI.Tooltip.ForceTooltip(
							new PreviewSelection(combatant, null, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// ability
			else if(ActionSelectType.Ability == this.type)
			{
				if(!combatant.Status.Effects.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.Get(this.abilityID);

					if(ability != null)
					{
						if(this.abilityUseHighestLevel)
						{
							ability.SetHighestUseLevel(combatant);
						}
						else
						{
							ability.SetUseLevel(this.abilityLevel);
						}

						ORK.GUI.Tooltip.ForceTooltip(
							new PreviewSelection(combatant, null, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// class ability
			else if(ActionSelectType.ClassAbility == this.type)
			{
				if(!combatant.Status.Effects.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.GetClassAbility();

					if(ability != null)
					{
						ORK.GUI.Tooltip.ForceTooltip(
							new PreviewSelection(combatant, null, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// item
			else if(ActionSelectType.Item == this.type)
			{
				if(!combatant.Status.Effects.BlockItems)
				{
					ItemShortcut item = combatant.Inventory.GetItem(this.itemID);

					if(item != null)
					{
						ORK.GUI.Tooltip.ForceTooltip(
							new PreviewSelection(combatant, null, item, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// shortcut
			else if(ActionSelectType.Shortcut == this.type)
			{
				Combatant owner = null;
				IShortcut shortcut = this.slot.GetShortcut(combatant, out owner);
				if(shortcut != null)
				{
					ORK.GUI.Tooltip.ForceTooltip(
						new PreviewSelection(owner, null, shortcut, true),
						autoCloseTime, closeOn2nd);
					return true;
				}
			}

			return false;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static bool UseAbility(Combatant user, AbilityShortcut ability, bool checkTime, bool checkUseCosts,
			bool useCursorOverTarget, bool useAutoTarget, bool autoTargetOnly, bool noTargetSelection, bool needTargets,
			bool blockBattleCamera, out BaseAction action)
		{
			action = null;
			if(ability != null &&
				ability.CanUse(user, checkTime &&
					AbilityActionType.CounterAttack != ability.Type,
					checkUseCosts))
			{
				TargetSettings targetSettings = TargetSettings.Get(ability);
				// target self
				if(targetSettings.TargetSelf())
				{
					action = new AbilityAction(user, ability);
					action.blockBattleCamera = blockBattleCamera;
					action.SetTarget(user);
				}
				// cursor target
				else if(useCursorOverTarget &&
					ORK.Battle.CursorOverCombatant != null &&
					ability.CanTarget(user, ORK.Battle.CursorOverCombatant) &&
					ability.InRange(user, ORK.Battle.CursorOverCombatant))
				{
					action = new AbilityAction(user, ability);
					action.blockBattleCamera = blockBattleCamera;
					action.SetTarget(ORK.Battle.CursorOverCombatant);
				}
				// auto target
				else if(useAutoTarget &&
					(!autoTargetOnly || ability.GetActiveLevel().targetSettings.useAutoTarget))
				{
					action = new AbilityAction(user, ability);
					action.blockBattleCamera = blockBattleCamera;
					action.AutoTarget(user.Battle.LastTargets,
						ORK.Game.Combatants.Get(user, true, Range.Battle,
							Consider.No, Consider.Ignore, Consider.Yes, null),
						ORK.Game.Combatants.Get(user, false, Range.Battle,
							Consider.Yes, Consider.Ignore, Consider.Yes, null));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetAbilityTarget(user, ability);
					if(target != null &&
						ability.InRange(user, target))
					{
						action = new AbilityAction(user, ability);
						action.blockBattleCamera = blockBattleCamera;
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetAbilityTarget(user, ability);
						if(target != null &&
							ability.InRange(user, target))
						{
							action = new AbilityAction(user, ability);
							action.blockBattleCamera = blockBattleCamera;
							action.SetTarget(target);
						}
						// select target
						else if((!noTargetSelection ||
								ability.IsNoneTarget()) &&
							(!needTargets || ability.HasPossibleTargets(user, null)))
						{
							return user.Battle.BattleMenu.StartTargetSelection(ability, blockBattleCamera);
						}
					}
				}
			}
			return false;
		}

		public static bool UseItem(Combatant user, ItemShortcut item, bool checkTime, bool checkUseCosts,
			bool useCursorOverTarget, bool useAutoTarget, bool autoTargetOnly, bool noTargetSelection, bool needTargets,
			bool blockBattleCamera, out BaseAction action)
		{
			action = null;
			if(item != null && item.CanUse(user, checkTime, checkUseCosts))
			{
				// target self
				if(item.Setting.targetSettings.TargetSelf())
				{
					action = new ItemAction(user, item);
					action.blockBattleCamera = blockBattleCamera;
					action.SetTarget(user);
				}
				// cursor target
				else if(useCursorOverTarget &&
					ORK.Battle.CursorOverCombatant != null &&
					item.CanTarget(user, ORK.Battle.CursorOverCombatant) &&
					item.Setting.InRange(user, ORK.Battle.CursorOverCombatant))
				{
					action = new ItemAction(user, item);
					action.blockBattleCamera = blockBattleCamera;
					action.SetTarget(ORK.Battle.CursorOverCombatant);
				}
				// auto target
				else if(useAutoTarget &&
					(!autoTargetOnly || item.Setting.targetSettings.useAutoTarget))
				{
					action = new ItemAction(user, item);
					action.blockBattleCamera = blockBattleCamera;
					action.AutoTarget(user.Battle.LastTargets,
						ORK.Game.Combatants.Get(user, true, Range.Battle,
							Consider.No, Consider.Ignore, Consider.Yes, null),
						ORK.Game.Combatants.Get(user, false, Range.Battle,
							Consider.Yes, Consider.Ignore, Consider.Yes, null));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetItemTarget(user, item);
					if(target != null &&
						item.Setting.InRange(user, target))
					{
						action = new ItemAction(user, item);
						action.blockBattleCamera = blockBattleCamera;
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetItemTarget(user, item);
						if(target != null &&
							item.Setting.InRange(user, target))
						{
							action = new ItemAction(user, item);
							action.blockBattleCamera = blockBattleCamera;
							action.SetTarget(target);
						}
						// select target
						else if((!noTargetSelection ||
								item.IsNoneTarget()) &&
							(!needTargets || item.HasPossibleTargets(user, null)))
						{
							return user.Battle.BattleMenu.StartTargetSelection(item, blockBattleCamera);
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(ActionSelectType.Ability == this.type)
			{
				return ORK.Abilities.GetName(this.abilityID);
			}
			else if(ActionSelectType.Item == this.type)
			{
				return ORK.Items.GetName(this.itemID);
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
