
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageDealerActivation : BaseData
	{
		// audio settings
		[ORKEditorHelp("Add Audio", "An audio clip is played on the game object hit by the damage dealer (when doing damage).", "")]
		[ORKEditorInfo(labelText="Audio Settings")]
		public bool addAudio = false;

		[ORKEditorHelp("Use Sound Type", "The user or target combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorLayout("addAudio", true)]
		public bool useSoundType = false;

		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;

		[ORKEditorHelp("Use Target", "Use the target combatant's audio clip.\n" +
			"If disabled, the user combatant's audio clip is used.", "")]
		public bool targetSound = false;

		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=null)]
		public AudioClip audioClip;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;


		// prefab settings
		[ORKEditorHelp("Add Prefab", "A prefab is spawned on the position it hit an object when doing damage.\n" +
			"This prefab can't be used by the battle event.\n" +
			"Please note that only using 'Collision' to deal damage will use the hit position, " +
			"using 'Trigger' will use the position of the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Prefab Settings")]
		public bool addPrefab = false;

		[ORKEditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[ORKEditorLayout("addPrefab", true, setDefault=true, defaultValue=null)]
		public GameObject prefab;

		[ORKEditorHelp("Mount Prefab", "Parent/mount the prefab to the combatant that was hit.", "")]
		public bool mountPrefab = false;

		[ORKEditorHelp("Stop Particles", "Particles emitting from the prefab will stop emitting.", "")]
		public bool stopParticles = false;

		[ORKEditorHelp("Stop After (s)", "The time in seconds before emitting particles will stop.", "")]
		[ORKEditorLayout("stopParticles", true, endCheckGroup=true)]
		public float stopAfter = 1;

		[ORKEditorHelp("Destroy After (s)", "The spawned prefab will be destroyed after the set amout of time in seconds.\n" +
			"Set to 0 if you don't want to destroy it after time.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float after = 0;


		// battle animation
		[ORKEditorInfo(separator=true, labelText="Battle Animation")]
		public BattleAnimationSetting battleAnimation = new BattleAnimationSetting();

		public DamageDealerActivation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("animate"))
			{
				this.battleAnimation.UpgradeSetting(data, "animate", "animation");
			}
		}

		public void Add(DamageDealer damage, Combatant user)
		{
			this.AddAudio(damage, user);
			this.AddPrefab(damage);
		}

		public void AddAudio(DamageDealer damage, Combatant user)
		{
			if(this.addAudio)
			{
				if(this.useSoundType)
				{
					if(this.targetSound)
					{
						damage.SetAudioType(this.soundTypeID, this.audio);
					}
					else
					{
						damage.SetAudioClip(user.Animations.GetAudioClip(this.soundTypeID), this.audio);
					}
				}
				else
				{
					damage.SetAudioClip(this.audioClip, this.audio);
				}
			}
		}

		public void AddPrefab(DamageDealer damage)
		{
			if(this.addPrefab)
			{
				damage.SetPrefab(this.prefab, this.mountPrefab,
					this.after, this.stopParticles ? this.stopAfter : -1);
			}
		}
	}
}
