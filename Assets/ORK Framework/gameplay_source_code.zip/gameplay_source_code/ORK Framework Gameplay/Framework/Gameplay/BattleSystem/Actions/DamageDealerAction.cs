
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageDealerAction : BaseAction
	{
		private BaseAction baseAction;

		public DamageDealerAction(BaseAction action, List<Combatant> target, List<BattleEvent> events)
		{
			this.baseAction = action;
			this.user = action.User;
			this.target = target;
			this.events = events;

			this.CheckActionAffiliation();
		}

		public override System.Object GetSelectedData()
		{
			return this.baseAction;
		}

		public override bool IsType(ActionType t)
		{
			return false;
		}

		public override bool ConsumeDone
		{
			get { return this.baseAction.ConsumeDone; }
			set { this.baseAction.ConsumeDone = value; }
		}

		public override bool CanTarget(Combatant combatant)
		{
			return this.baseAction.CanTarget(combatant);
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public override void AutoActivateUserDamageDealers(bool activate)
		{

		}

		public override bool CheckDamageDealer(DamageDealer dealer)
		{
			return false;
		}

		public override string[] GetActivationTags()
		{
			return new string[0];
		}

		public override DamageDealerActivation GetDamageDealerActivation()
		{
			return null;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override void PerformAction()
		{
			// add control blocks
			ORK.Battle.DoAllActionsBlock(1);
			if(ORK.Game.PlayerHandler.IsPlayer(this.user))
			{
				ORK.Battle.DoPlayerActionsBlock(1);
			}

			ORK.Battle.Actions.AddActive(this);

			if(this.CanUse())
			{
				// check target aggression
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
						{
							this.target[i].CheckAggressive(AggressionType.OnAction, this.user);
							this.target[i].Battle.SetAttackedBy(this.user, true);
						}
					}
				}

				// base setup
				if(this.baseAction.IsType(ActionType.Ability) ||
					this.baseAction.IsType(ActionType.Attack) ||
					this.baseAction.IsType(ActionType.Item))
				{
					user.Battle.LastTargets = this.target;
				}

				// start battle event
				if(this.events.Count > 0)
				{
					this.GetNextEvent();
					this.activeEvent.StartEvent(this, this.user.GameObject);
				}
				else
				{
					if(this.target != null && this.target.Count > 0)
					{
						this.Calculate(this.target, 1, true);
					}
					this.EventEnded();
				}
			}
			else
			{
				this.EventEnded();
			}
		}

		protected override void ActionStartSetup()
		{

		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.baseAction.Calculate(ts, damageFactor, animate);
			this.results = this.baseAction.results;
		}

		public override void EventEnded()
		{
			if(this.events != null && this.events.Count > 0)
			{
				this.GetNextEvent();
				this.activeEvent.StartEvent(this, this.user.GameObject);
			}
			else
			{
				this.activeEvent = null;
				if(this.rayObject != null &&
					this.rayObjectCreated)
				{
					UnityWrapper.Destroy(this.rayObject);
				}

				ORK.Battle.Actions.RemoveActive(this);
				ORK.Battle.CheckBattleEnd();

				// remove control blocks
				ORK.Battle.DoAllActionsBlock(-1);
				if(ORK.Game.PlayerHandler.IsPlayer(this.user))
				{
					ORK.Battle.DoPlayerActionsBlock(-1);
				}
			}
		}

		protected override void ActionEndSetup()
		{

		}
	}
}
