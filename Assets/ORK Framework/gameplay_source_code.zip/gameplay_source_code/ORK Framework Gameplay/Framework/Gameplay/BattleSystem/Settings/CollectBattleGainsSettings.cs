﻿
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CollectBattleGainsSettings : BaseData
	{
		// display
		[ORKEditorHelp("Show Gains", "Show the battle gains and level up texts.\n" +
			"The display options are defined in the battle end settings.", "")]
		public bool display = false;

		[ORKEditorHelp("Auto Close", "Automatically close the battle gains after a defined time.", "")]
		[ORKEditorLayout("display", true)]
		public bool autoClose = false;

		[ORKEditorHelp("Close After (s)", "The time in seconds until the gains dialogue closes automatially.\n" +
			"This time is used for each page of the battle gains.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("autoClose", true)]
		public float closeTime = 3;

		[ORKEditorHelp("Block Accept Button", "The accept button is blocked - " +
			"the gains dialogue will only close after its auto close time ran out.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool blockAccept = false;


		// collect
		[ORKEditorHelp("Collect Loot", "Loot (items, equipment and currency) will be collected.\n" +
			"If disabled, the loot will be kept for later collection.", "")]
		[ORKEditorInfo(separator=true)]
		public bool collectLoot = true;

		[ORKEditorHelp("Collect Experience", "Experience will be collected.\n" +
			"If disabled, the experience will be kept for later collection.", "")]
		public bool collectExp = true;


		// item box
		[ORKEditorHelp("Use Item Box", "Store loot in an item box.\n" +
			"If disabled, the loot will be added to the player's inventory.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("collectLoot", true)]
		public bool useItemBox = false;

		[ORKEditorHelp("Use Add Type", "Items and equipment will be added to the " +
			"item box according to their inventory add type (e.g. auto stack).\n" +
			"If disabled, items/equipment will be added as is, i.e. with their defined quantity without grouping them together.", "")]
		[ORKEditorLayout("useItemBox", true)]
		public bool useAddType = true;

		[ORKEditorInfo(labelText="Item Box ID")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public StringValue itemBoxID;

		public CollectBattleGainsSettings()
		{

		}

		public void CollectGains(BaseEvent baseEvent, int next)
		{
			ORK.Battle.CollectGains(this.collectLoot,
				this.collectExp, this.display,
				this.autoClose ? this.closeTime : -1,
				this.autoClose ? this.blockAccept : false,
				this.useItemBox, this.useAddType,
				this.useItemBox ? this.itemBoxID.GetValue() : "",
				baseEvent, next);
		}
	}
}
