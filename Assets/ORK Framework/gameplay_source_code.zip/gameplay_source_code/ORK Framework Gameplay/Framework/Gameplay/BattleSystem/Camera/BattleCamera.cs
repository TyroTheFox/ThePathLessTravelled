
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleCamera : BaseData
	{
		[ORKEditorHelp("Battle Camera Type", "Select the battle camera that will be used:\n" +
			"- None: The battle camera isn't used.\n" +
			"- Block Events: Camera changes by battle events are blocked, performs rotations and look at actions.\n" +
			"- Allow Events: Camera changes by battle events are allowed, performs look at actions (except 'Simple Look').\n" +
			"Please note that rotation and 'Simple Look' look at actions only work with blocked camera controls.", "")]
		public BattleCameraType type = BattleCameraType.None;


		// toggle key
		[ORKEditorInfo(separator=true, labelText="Toggle Key")]
		[ORKEditorLayout("type", BattleCameraType.None, elseCheckGroup=true)]
		public ToggleKeySetting toggleKey = new ToggleKeySetting();

		[ORKEditorHelp("Clear Look Targets", "Clear the current look targets when toggling off the battle camera.", "")]
		[ORKEditorLayout("toggleKey.useKey", true, endCheckGroup=true, endGroups=2)]
		public bool toggleClearLookTargets = false;


		// block events camera
		[ORKEditorHelp("Combatant Center", "The camera will use the center of all combatants " +
			"for it's rotation and look movements.\n" +
			"If disabled, the position of the battle arena is used.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", BattleCameraType.BlockEvents)]
		public bool useCombatantCenter = false;

		[ORKEditorHelp("Remember Position", "The last position of the battle camera is remembered.\n" +
			"If the battle camera changes (e.g. to look at the latest target), " +
			"it will return to the remembered position after it's 'look at' action is finished.", "")]
		public bool rememberPosition = false;

		[ORKEditorHelp("Look Damping", "The damping for 'look at' camera changes.\n" +
			"The higher the value, the faster the camera will get to it's looking position.\n" +
			"A lower value will result in a smoother camera movement.", "")]
		public float lookAtDamping = 5.0f;


		// rotation
		[ORKEditorHelp("Rotation Axis", "Set at the camera's rotation axis by setting it's X, Y and Z rotation.\n" +
			"E.g. X=0, Y=1, Z=0 will rotate along the Y-axis around the battle arena.\n" +
			"A value between 0 and 1 is recommended.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 rotationAxis = Vector3.zero;

		[ORKEditorHelp("Rotation Speed", "The speed at which the camera will rotate.\n" +
			"Set the speed to 0 if no camera rotation is wanted.\n" +
			"Use negative numbers to invert rotation.", "")]
		public float rotationSpeed = 0;


		// rotation limit
		[ORKEditorHelp("Limit Rotation", "The rotation is limited to defined minimum/maximum degrees.\n" +
			"If the camera rotation reaches a limit (rotation at battle start + min/max rotation), " +
			"the rotation is inverted (the camera rotates into the opposite direction).", "")]
		[ORKEditorInfo(separator=true)]
		public bool limitRotation = false;

		[ORKEditorHelp("Minimum Rotation", "The minimum rotation of the camera (left limit) in degree.\n" +
			"The value has to be between -180 and 0.", "")]
		[ORKEditorLayout("limitRotation", true)]
		public Vector3 minRotation = Vector3.zero;

		[ORKEditorHelp("Maximum Rotation", "The maximum rotation of the camera (right limit) in degree.\n" +
			"The value has to be between 0 and 180.", "")]
		[ORKEditorInfo(callbackAfter="check:rotations")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public Vector3 maxRotation = Vector3.zero;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to " +
			"the selecting player combatant, the battle arena or the player.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to " +
			"the selecting player combatant, the battle arena or the player.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorLayout("type", BattleCameraType.None, elseCheckGroup=true)]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Selecting Player Member", "The currently selecting player group member is used as target.\n" +
			"The battle arena or player are used if no selecting player combatant is available.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool cameraControlTargetSelectingPlayer = true;

		[ORKEditorHelp("Battle Arena", "The battle arena is used as target.\n" +
			"The player is used if the battle arena isn't available.", "")]
		public bool cameraControlTargetArena = true;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// look at actions
		// damage
		[ORKEditorInfo("Look At Latest Damage", "The camera can look at the last combatant that was target of an action's calculation.\n" +
			"Beside receiving damage, this also includes missed attacks, death actions, etc.", "")]
		public LookAtSettings latestDamage = new LookAtSettings();

		[ORKEditorInfo("Block Actions", "Block looking at the latest damage from defined actions.", "", 
			endFoldout=true, endFolds=2)]
		public LookAtActionBlock latestDamageActionBlock = new LookAtActionBlock();

		// user
		[ORKEditorInfo("Look At Latest User", "The camera can look at the combatant " +
			"who performs the current action (i.e. the last action that has been started).", "")]
		public LookAtSettings latestUser = new LookAtSettings();

		[ORKEditorInfo("Block Actions", "Block looking at the latest user from defined actions.", "",
			endFoldout=true, endFolds=2)]
		public LookAtActionBlock latestUserActionBlock = new LookAtActionBlock();

		// menu
		[ORKEditorInfo("Look At Selecting User", "The camera can look at the combatant that currently selects an action.\n" +
			"This works like 'Look At Menu User', but isn't limited to player controlled combatants.", "",
			endFoldout=true)]
		public LookAtSettings selectingUser = new LookAtSettings();

		// menu
		[ORKEditorInfo("Look At Menu User", "The camera can look at the combatant with the battle menu opened (i.e. only player controlled combatants).\n" + 
			"When the battle menu isn't opened automatically, the camera will still look at the combatant that starts selecting actions.", "",
			endFoldout=true)]
		public LookAtSettings menuUser = new LookAtSettings();

		// selection
		[ORKEditorInfo("Look At Selection", "The camera can look at the currently selected combatant (target selection).", "",
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public LookAtSettings selection = new LookAtSettings();


		// ingame
		private bool lookingAtSomething = false;

		private bool forceReset = false;

		private int blockedByAnimation = 0;

		private Transform camera = null;

		private Camera cameraComponent = null;

		private bool activated = false;

		private bool toggleState = true;

		private BattleComponent battleComponent = null;

		private int lastLookAtIndex = -1;

		private Vector3 lastPos = Vector3.zero;

		private Quaternion lastRot = Quaternion.identity;

		private float lastFoV = 40;

		private Vector3 useRotationAxis = Vector3.zero;

		private Vector3 startRotationAxis = Vector3.zero;


		// look at reset times
		private float damageTimeout = -1;

		private float userTimeout = -1;

		private float selectingUserTimeout = -1;

		private float menuTimeout = -1;

		private float selectionTimeout = -1;

		public BattleCamera()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("blockEventCams"))
			{
				bool tmp = false;
				data.Get("blockEventCams", ref tmp);
				if(tmp)
				{
					this.type = BattleCameraType.BlockEvents;
				}
			}
		}

		public bool IsNone
		{
			get { return BattleCameraType.None == this.type; }
		}

		public bool IsBlockEvents
		{
			get { return BattleCameraType.BlockEvents == this.type; }
		}

		public bool IsAllowEvents
		{
			get { return BattleCameraType.AllowEvents == this.type; }
		}

		private void SetCameraControlTarget()
		{
			if(this.cameraControlTarget)
			{
				if(this.cameraControlTargetSelectingPlayer &&
					ORK.Battle.SelectingCombatant != null)
				{
					ORK.Control.SetCameraControlTarget(ORK.Battle.SelectingCombatant.GameObject,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
				else if(this.cameraControlTargetArena &&
					ORK.Battle.BattleArena != null)
				{
					ORK.Control.SetCameraControlTarget(ORK.Battle.BattleArena.GameObject,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
				else
				{
					ORK.Control.SetCameraControlTarget(null,
						this.ownControlTargetTransition ? this.controlTargetTransition : null);
				}
			}
		}

		public void SetToggleStartState()
		{
			this.toggleState = this.toggleKey.toggleStartState;
		}


		/*
		============================================================================
		Look at functions
		============================================================================
		*/
		private void ClearLookTargets()
		{
			this.latestDamage.Target = null;
			this.damageTimeout = -1;

			this.latestUser.Target = null;
			this.userTimeout = -1;

			this.selectingUser.Target = null;
			this.selectingUserTimeout = -1;

			this.menuUser.Target = null;
			this.menuTimeout = -1;

			this.selection.Target = null;
			this.selectionTimeout = -1;
		}

		public void SetLatestDamage(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.latestDamage.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.latestDamage.SetTarget(this.camera, target, ref this.damageTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public void SetLatestUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.latestUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.latestUser.SetTarget(this.camera, target, ref this.userTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public void SetSelectingUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.selectingUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.selectingUser.SetTarget(this.camera, target, ref this.selectingUserTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public void SetMenuUser(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.menuUser.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.menuUser.SetTarget(this.camera, target, ref this.menuTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}

		public void SetSelection(Transform user, Transform target)
		{
			if(this.activated &&
				this.toggleState &&
				this.selection.CheckTarget(this.cameraComponent, user, target))
			{
				this.ClearLookTargets();
				if(!this.selection.SetTarget(this.camera, target, ref this.selectionTimeout))
				{
					this.SetCameraControlTarget();
				}
			}
		}


		/*
		============================================================================
		Block functions
		============================================================================
		*/
		public void BlockedByAnimation(bool block)
		{
			if(block)
			{
				this.blockedByAnimation++;
			}
			else
			{
				this.blockedByAnimation--;
			}
			this.forceReset = true;
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.activated)
			{
				bool tmpToggle = this.toggleState;
				this.toggleKey.GetToggleState(ref this.toggleState);

				if(this.toggleClearLookTargets &&
					!this.toggleState &&
					tmpToggle != this.toggleState)
				{
					this.ClearLookTargets();
					this.SetCameraControlTarget();
				}

				if(this.toggleState)
				{
					// reset timers
					if(this.damageTimeout > 0)
					{
						this.damageTimeout -= Time.deltaTime;
						if(this.damageTimeout <= 0)
						{
							this.SetLatestDamage(null, null);
						}
					}
					if(this.userTimeout > 0)
					{
						this.userTimeout -= Time.deltaTime;
						if(this.userTimeout <= 0)
						{
							this.SetLatestUser(null, null);
						}
					}
					if(this.selectingUserTimeout > 0)
					{
						this.selectingUserTimeout -= Time.deltaTime;
						if(this.selectingUserTimeout <= 0)
						{
							this.SetSelectingUser(null, null);
						}
					}
					if(this.menuTimeout > 0)
					{
						this.menuTimeout -= Time.deltaTime;
						if(this.menuTimeout <= 0)
						{
							this.SetMenuUser(null, null);
						}
					}
					if(this.selectionTimeout > 0)
					{
						this.selectionTimeout -= Time.deltaTime;
						if(this.selectionTimeout <= 0)
						{
							this.SetSelection(null, null);
						}
					}

					// rotation
					if(ORK.Control.CameraBlocked &&
						this.IsBlockEvents &&
						this.blockedByAnimation == 0 &&
						this.camera != null)
					{
						int index = -1;
						bool looking = false;
						bool resetBase = true;

						if(this.selection.Target != null && this.selection.CheckCamPos())
						{
							if(this.selection.IsSimpleLook)
							{
								index = 0;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.selection.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.selection.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.selectingUser.Target != null && this.selectingUser.CheckCamPos())
						{
							if(this.selectingUser.IsSimpleLook)
							{
								index = 1;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.selectingUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.selectingUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.menuUser.Target != null && this.menuUser.CheckCamPos())
						{
							if(this.menuUser.IsSimpleLook)
							{
								index = 1;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.menuUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.menuUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.latestDamage.Target != null && this.latestDamage.CheckCamPos())
						{
							if(this.latestDamage.IsSimpleLook)
							{
								index = 2;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.latestDamage.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.latestDamage.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}
						if(resetBase && this.latestUser.Target != null && this.latestUser.CheckCamPos())
						{
							if(this.latestUser.IsSimpleLook)
							{
								index = 2;
								Quaternion rotation = VectorHelper.LookAt(
								this.camera.position, this.latestUser.Target.position);
								this.camera.rotation = Quaternion.Slerp(
									this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
							}
							else
							{
								this.latestUser.Rotate(this.camera);
								looking = true;
							}
							resetBase = false;
							this.lookingAtSomething = true;
						}

						if(!looking)
						{
							if(this.forceReset ||
								(this.lookingAtSomething &&
								(resetBase || index != this.lastLookAtIndex)))
							{
								this.camera.SetPositionAndRotation(this.lastPos, this.lastRot);
								if(this.cameraComponent != null)
								{
									this.cameraComponent.fieldOfView = this.lastFoV;
								}
								this.forceReset = false;
								this.lookingAtSomething = false;
							}

							if(this.rotationSpeed != 0)
							{
								if(this.useCombatantCenter)
								{
									this.camera.RotateAround(ORK.Battle.GetCombatantCenter().transform.position,
										this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
								}
								else
								{
									this.camera.RotateAround(this.battleComponent.transform.position,
										this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
								}

								if(this.limitRotation)
								{
									Vector3 tmpRot = this.camera.eulerAngles - this.startRotationAxis;
									VectorHelper.SecureVector(ref tmpRot, -190, 190, 360);

									// X-axis
									if(tmpRot.x <= this.minRotation.x)
									{
										this.useRotationAxis.x = -this.useRotationAxis.x;
									}
									else if(tmpRot.x >= this.maxRotation.x)
									{
										this.useRotationAxis.x = -this.useRotationAxis.x;
									}
									// Y-axis
									if(tmpRot.y <= this.minRotation.y)
									{
										this.useRotationAxis.y = -this.useRotationAxis.y;
									}
									else if(tmpRot.y >= this.maxRotation.y)
									{
										this.useRotationAxis.y = -this.useRotationAxis.y;
									}
									// Z-axis
									if(tmpRot.z <= this.minRotation.z)
									{
										this.useRotationAxis.z = -this.useRotationAxis.z;
									}
									else if(tmpRot.z >= this.maxRotation.z)
									{
										this.useRotationAxis.z = -this.useRotationAxis.z;
									}
								}
							}

							if(this.rememberPosition)
							{
								this.lastPos = this.camera.position;
								this.lastRot = this.camera.rotation;
								if(this.cameraComponent != null)
								{
									this.lastFoV = this.cameraComponent.fieldOfView;
								}
							}
						}
						this.lastLookAtIndex = index;
					}
				}
			}
		}

		public void StartBattle(BattleComponent battleComponent)
		{
			this.battleComponent = battleComponent;
			this.useRotationAxis = this.rotationAxis;
			this.startRotationAxis = Vector3.zero;
			this.lookingAtSomething = false;
			if(ORK.Game.Camera != null)
			{
				this.camera = ORK.Game.Camera.transform;
				this.cameraComponent = this.camera.GetComponent<Camera>();
				this.lastPos = this.camera.position;
				this.lastRot = this.camera.rotation;
				if(this.cameraComponent != null)
				{
					this.lastFoV = this.cameraComponent.fieldOfView;
				}
				this.startRotationAxis = this.camera.eulerAngles;
			}

			this.ClearLookTargets();
			this.SetCameraControlTarget();
			this.lastLookAtIndex = -1;
			this.blockedByAnimation = 0;
			this.forceReset = false;
			this.activated = true;
		}

		public void EndBattle()
		{
			this.activated = false;
			this.blockedByAnimation = 0;
			this.lookingAtSomething = false;
			this.forceReset = false;
			this.camera = null;
			this.cameraComponent = null;
			this.ClearLookTargets();
			this.battleComponent = null;
			this.lastLookAtIndex = -1;
			this.lastPos = Vector3.zero;
			this.lastRot = Quaternion.identity;
		}
	}
}
