﻿
using UnityEngine;
using System.Collections.Generic;
using System;

namespace ORKFramework.UI
{
	public class AttackBattleMenuItem : BaseBattleMenuItem
	{
		[ORKEditorHelp("Use Ability Information", "Use the name, icon and description of the ability for the button.\n" +
			"The button will also display the use costs of the ability.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Settings")]
		public bool useAbilityInfo = false;


		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorLayout("useAbilityInfo", false, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;

		public AttackBattleMenuItem()
		{

		}

		public AttackBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Attack == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			AbilityShortcut ability = owner.Abilities.GetCurrentBaseAttack();
			ChoiceContent cc = this.useAbilityInfo ?
				bm.contentLayout.GetChoiceContent(ability, owner) :
				bm.contentLayout.GetChoiceContent(this.button);
			this.customSkin.SetSkin(cc);
			list.Add(new AbilityBMItem(ability, cc));
		}
	}
}
