
namespace ORKFramework.UI
{
	public class BaseBMItem : BMItem
	{
		private BMItemType type = BMItemType.End;

		public BaseBMItem(ChoiceContent content, BMItemType type)
		{
			this.content = content;
			this.type = type;
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(BMItemType.Defend == this.type)
			{
				this.content.Active = !owner.Status.Effects.BlockDefend &&
					owner.Battle.CanUse(ORK.Battle.GetDefendActionCost(owner));
			}
			else if(BMItemType.Escape == this.type)
			{
				this.content.Active = ORK.Battle.CanEscape && !owner.Status.Effects.BlockEscape &&
					owner.Battle.CanUse(ORK.Battle.GetEscapeActionCost(owner));
			}
			else if(BMItemType.End == this.type)
			{
				this.content.Active = owner.Battle.CanUse(ORK.Battle.GetNoneActionCost(owner));
			}
			else if(BMItemType.GridMove == this.type)
			{
				this.content.Active = owner.Grid.CanMove &&
					owner.Battle.CanUse(ORK.Battle.GetGridMoveActionCost(owner));
			}
			else if(BMItemType.GridOrientation == this.type)
			{
				this.content.Active = !owner.Status.Effects.BlockAllActions &&
					!owner.Status.Effects.StopMovement;
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			base.Selected(owner);
			PreviewValues preview = null;
			if(BMItemType.Defend == this.type)
			{
				if(ORK.GUI.Settings.preview.defendActionCost)
				{
					preview = new PreviewValues();
					preview.usedActionBarChange += ORK.Battle.GetDefendActionCost(owner);
				}
			}
			else if(BMItemType.Escape == this.type)
			{
				if(ORK.GUI.Settings.preview.escapeActionCost)
				{
					preview = new PreviewValues();
					preview.usedActionBarChange += ORK.Battle.GetEscapeActionCost(owner);
				}
			}
			else if(BMItemType.End == this.type)
			{
				if(ORK.GUI.Settings.preview.noneActionCost)
				{
					preview = new PreviewValues();
					preview.usedActionBarChange += ORK.Battle.GetNoneActionCost(owner);
				}
			}
			else if(BMItemType.GridMove == this.type)
			{
				if(ORK.GUI.Settings.preview.gridMoveActionCost)
				{
					preview = new PreviewValues();
					preview.usedActionBarChange += ORK.Battle.GetGridMoveActionCost(owner);
				}
			}
			if(preview != null)
			{
				ORK.GUI.Tooltip.ForcedPreview = new PreviewSelection(owner, preview);
			}
		}

		public override bool Accepted(Combatant owner)
		{
			if(BMItemType.Defend == this.type)
			{
				owner.Battle.BattleMenu.AddAction(new DefendAction(owner));
			}
			else if(BMItemType.Escape == this.type)
			{
				owner.Battle.BattleMenu.AddAction(new EscapeAction(owner));
			}
			else if(BMItemType.End == this.type)
			{
				owner.Battle.EndTurnCommand(false);
			}
			else if(BMItemType.GridMove == this.type)
			{
				owner.Battle.BattleMenu.StartGridMoveSelection(null, true);
			}
			else if(BMItemType.GridOrientation == this.type)
			{
				owner.Battle.BattleMenu.StartGridOrientationSelection(null, true);
			}
			else if(BMItemType.GridExamine == this.type)
			{
				owner.Battle.BattleMenu.StartGridExamine(owner.Grid.Cell, true);
			}
			return true;
		}
	}
}
