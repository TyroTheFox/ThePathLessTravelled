﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ItemBattleMenuItem : BaseBattleMenuItem
	{
		// single ability
		[ORKEditorHelp("Single Item", "Display only a single item instead of a list of items.\n" +
			"The battle menu item is only displayed if the item is in the combatant's inventory.", "")]
		public bool singleItem = false;

		[ORKEditorHelp("Item", "Select the item that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("singleItem", true)]
		public int itemID = 0;


		// item type
		[ORKEditorHelp("Limit Item Type", "Limit the displayed items to a defined item type and it's sub-types.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool limitItemType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the displayed items.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitItemType", true, endCheckGroup=true)]
		public int itemTypeID = 0;


		// item
		[ORKEditorHelp("Type Display", "Select how item types are displayed:\n" +
			"- Combined: All types are displayed in a combined option. You can display the types in a sub-menu.\n" +
			"- Type: All types are listed individually.\n" +
			"- List: All items are listed directly, without any type list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BMTypeDisplay typeDisplay = BMTypeDisplay.Combined;

		[ORKEditorHelp("Sub Menu", "Display the item types in a sub-menu.\n" +
			"If disabled, all items will be displayed without a type filter.", "")]
		[ORKEditorLayout("typeDisplay", BMTypeDisplay.Combined, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool subMenu = false;


		// sorting
		[ORKEditorInfo(separator=true, labelText="Type Sorting")]
		[ORKEditorLayout(new string[] {"typeDisplay", "subMenu"},
			new System.Object[] {BMTypeDisplay.Type, true},
			needed=Needed.One, endCheckGroup=true)]
		public TypeSorter typeSorter = new TypeSorter();

		[ORKEditorInfo(separator=true, labelText="List Sorting")]
		public ContentSorter contentSorter = new ContentSorter();


		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorLayout("typeDisplay", BMTypeDisplay.Combined, endCheckGroup=true, endGroups=2,
			autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;

		public ItemBattleMenuItem()
		{

		}

		public ItemBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Item == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			// single item
			if(this.singleItem)
			{
				ItemShortcut item = owner.Inventory.GetItem(this.itemID);
				if(item != null)
				{
					ChoiceContent cc = bm.contentLayout.GetChoiceContent(item, owner);
					this.customSkin.SetSkin(cc);
					list.Add(new ItemBMItem(item, cc));
				}
			}
			// item list
			else
			{
				// combined
				if(BMTypeDisplay.Combined == this.typeDisplay)
				{
					ChoiceContent cc = bm.contentLayout.GetChoiceContent(this.button);
					this.customSkin.SetSkin(cc);
					if(this.limitItemType)
					{
						list.Add(new TypeBMItem(ORK.ItemTypes.Get(this.itemTypeID),
							cc, this.itemTypeID, parent, false));
					}
					else
					{
						list.Add(new TypeBMItem(null, cc, -1, parent, false));
					}
				}
				// list types
				else if(BMTypeDisplay.Type == this.typeDisplay)
				{
					List<int> types = owner.Inventory.Items.GetUseableItemTypes(UseableIn.Battle,
							this.limitItemType ? this.itemTypeID : -1);
					this.typeSorter.Sort(ref types, ORKDataType.ItemType);
					for(int i = 0; i < types.Count; i++)
					{
						ItemType itemType = ORK.ItemTypes.Get(types[i]);
						ChoiceContent cc = bm.contentLayout.GetChoiceContent(itemType);
						this.customSkin.SetSkin(cc);
						TypeBMItem tmp = new TypeBMItem(itemType, cc, types[i], parent, false);
						tmp.hasSubTypes = itemType.HasSubTypes();
						list.Add(tmp);
					}
				}
				// list items
				else if(BMTypeDisplay.List == this.typeDisplay)
				{
					List<ItemShortcut> items = this.limitItemType ?
						owner.Inventory.Items.GetUseableItemsByType(this.itemTypeID, UseableIn.Battle, true) :
						owner.Inventory.Items.GetUseableItems(UseableIn.Battle);
					this.contentSorter.Sort(ref items);
					for(int i = 0; i < items.Count; i++)
					{
						ChoiceContent cc = bm.contentLayout.GetChoiceContent(items[i], owner);
						this.customSkin.SetSkin(cc);
						list.Add(new ItemBMItem(items[i] as ItemShortcut, cc));
					}
				}
			}
		}
	}
}
