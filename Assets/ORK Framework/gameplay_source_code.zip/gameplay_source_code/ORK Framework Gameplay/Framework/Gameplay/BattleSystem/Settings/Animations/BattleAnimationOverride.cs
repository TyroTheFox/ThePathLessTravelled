﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleAnimationOverride : BaseData
	{
		[ORKEditorHelp("Action Type", "Select which animation will be overridden:\n" +
			"- Ability: An ability's animation.\n" +
			"- Item: An item's animation.\n" +
			"- Defend: The defend command's animation.\n" +
			"- Escape: The escape command's animation.\n" +
			"- Death: The combatant's death animation.\n" +
			"- None: The none command's animation (doing nothing).\n" +
			"- Retreat: Retreating from battle when changing members.\n" +
			"- Enter Battle: Entering battle when changing members.\n" +
			"- Join Battle: Joining the battle when using 'Auto Join'.\n" +
			"- Grid Move: The grid move command's animation.", "")]
		public BattleAnimationType type = BattleAnimationType.Defend;


		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be overridden.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("type", BattleAnimationType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("All Levels", "All levels of the ability will be overridden.\n" +
			"If disabled, only a defined level will be overridden.", "")]
		public bool abilityAllLevels = true;

		[ORKEditorHelp("Level", "The level of the ability that will be overridden.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("abilityAllLevels", false, endCheckGroup=true, endGroups=2)]
		public int abilityLevel = 1;


		// item
		[ORKEditorHelp("Item", "Select the item that will be overridden.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", BattleAnimationType.Item, endCheckGroup=true)]
		public int itemID = 0;


		// join battle
		[ORKEditorHelp("Look At Enemies", "The combatant will automatically look at his enemies when joining a battle.", "")]
		[ORKEditorLayout(new string[] { "type", "animation.animate" },
			new object[] { BattleAnimationType.JoinBattle, false },
			needed=Needed.All, endCheckGroup=true)]
		public bool joinLookAt = false;


		// animation
		[ORKEditorInfo(separator=true)]
		public BattleAnimationSetting animation = new BattleAnimationSetting();

		public BattleAnimationOverride()
		{

		}

		public void UpgradeSetting(DataObject data, BattleAnimationType type, string animateName, string animationName)
		{
			this.type = type;
			this.animation.UpgradeSetting(data, animateName, animationName);
		}
	}
}
