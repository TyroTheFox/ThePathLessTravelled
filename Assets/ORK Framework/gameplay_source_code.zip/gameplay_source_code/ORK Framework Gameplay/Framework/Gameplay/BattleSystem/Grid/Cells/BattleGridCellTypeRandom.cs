﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridCellTypeRandom : BaseData
	{
		[ORKEditorHelp("Fallback Cell Type", "Select the grid cell type that will be used as fallback cell type.\n" +
			"The fallback cell type is used in case none of the random cell types is selected.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int fallbackCellType = 0;


		// editor prefab
		[ORKEditorInfo(separator=true, labelText="Editor Prefab")]
		public GridCellPrefab prefab = new GridCellPrefab();


		// random cell types
		[ORKEditorInfo(callbackBefore="label:totalchance")]
		[ORKEditorArray(false, "Add Random Cell Type", "Adds a random cell type.", "",
			"Remove", "Removes this random cell type.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[]
			{
				"Random Cell Type", "Define the random cell type and chance that it'll be used.", ""
			})]
		public GridCellTypeChance[] randomCellType = new GridCellTypeChance[0];

		public BattleGridCellTypeRandom()
		{

		}

		public BattleGridCellType GetCellType()
		{
			int index = -1;
			float random = ORK.GameSettings.GetRandom();
			float tmpChance = 0;

			for(int i = 0; i < this.randomCellType.Length; i++)
			{
				if(random >= tmpChance &&
					random <= tmpChance + this.randomCellType[i].chance)
				{
					index = i;
					break;
				}
				else
				{
					tmpChance += this.randomCellType[i].chance;
				}
			}

			if(index >= 0 &&
				index < this.randomCellType.Length)
			{
				return ORK.BattleGridCellTypes.Get(this.randomCellType[index].cellType).GetCellType();
			}
			return ORK.BattleGridCellTypes.Get(this.fallbackCellType).GetCellType();
		}
	}
}
