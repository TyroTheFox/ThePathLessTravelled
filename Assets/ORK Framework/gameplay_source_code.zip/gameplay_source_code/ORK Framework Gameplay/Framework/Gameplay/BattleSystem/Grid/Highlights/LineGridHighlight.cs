﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LineGridHighlight : BaseData
	{
		[ORKEditorHelp("Prefab", "Select the prefab used for the line highlight.\n" +
			"The prefab must have a 'Line Renderer' component attached.", "")]
		[ORKEditorInfo(instanceCallback="check:linerenderer")]
		public GameObject prefab;

		[ORKEditorHelp("Position Offset", "The offset added to the position of the grid cell.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 positionOffset = Vector3.zero;

		[ORKEditorHelp("Distance To Center (0-1)", "Define where on the cell's area the line will be placed.\n" +
			"0 is at the center, creating a path line.\n" +
			"1 is at the edge of the cell, based on the cell size defined in the battle grid settings.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float distanceToCenter = 1;

		[ORKEditorHelp("Merge Distance", "The distance between 2 line positions that'll cause them to merge into one position.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float mergeDistance = 0.1f;

		[ORKEditorHelp("Enclosed Cells", "Cells that are completely enclosed by the outline will be included.\n" +
			"If disabled, enclosed cells will result in a line around them.", "")]
		[ORKEditorLayout("distanceToCenter", 0.0f, elseCheckGroup=true, endCheckGroup=true)]
		public bool enclosedCells = false;

		public LineGridHighlight()
		{

		}
	}
}
