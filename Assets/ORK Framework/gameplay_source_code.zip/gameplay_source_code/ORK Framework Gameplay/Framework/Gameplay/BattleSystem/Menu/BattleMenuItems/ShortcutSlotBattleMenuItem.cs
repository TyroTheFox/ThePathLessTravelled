﻿
using UnityEngine;
using System.Collections.Generic;
using System;

namespace ORKFramework.UI
{
	public class ShortcutSlotBattleMenuItem : BaseBattleMenuItem
	{
		[ORKEditorInfo(label=new string[]
		{
			"Supports ability, item, equipment, defend, escape, none (end battle), grid move, grid examine and grid orientation shortcuts.", 
			"The battle menu item isn't displayed if the shortcut slot is empty or occupied by an unsupported shortcut."
		})]
		public ShortcutSlot slot = new ShortcutSlot();


		// button
		[ORKEditorHelp("Use Shortcut Information", "Use the name, icon and description of " +
			"the shortcut in the defined shortcut slot for the button.\n" +
			"The button will also display the use costs of an ability or quantity of an item.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Settings")]
		public bool useShortcutInfo = true;

		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorLayout("useShortcutInfo", false, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;

		public ShortcutSlotBattleMenuItem()
		{

		}

		public ShortcutSlotBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Attack == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			Combatant tmpOwner;
			IShortcut shortcut = this.slot.GetShortcut(owner, out tmpOwner);
			if(shortcut != null &&
				owner == tmpOwner)
			{
				ChoiceContent cc = this.useShortcutInfo ?
					bm.contentLayout.GetChoiceContent(shortcut, owner) :
					bm.contentLayout.GetChoiceContent(this.button);
				this.customSkin.SetSkin(cc);

				if(shortcut is AbilityLinkShortcut)
				{
					list.Add(new AbilityBMItem(((AbilityLinkShortcut)shortcut).Shortcut, cc));
				}
				else if(shortcut is AbilityShortcut)
				{
					list.Add(new AbilityBMItem((AbilityShortcut)shortcut, cc));
				}
				else if(shortcut is ItemShortcut)
				{
					list.Add(new ItemBMItem((ItemShortcut)shortcut, cc));
				}
				else if(shortcut is DefendShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.Defend));
				}
				else if(shortcut is EscapeShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.Escape));
				}
				else if(shortcut is NoneShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.End));
				}
				else if(shortcut is EquipShortcut)
				{
					list.Add(new EquipmentBMItem(-1, (EquipShortcut)shortcut, cc));
				}
				else if(shortcut is GridExamineShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.GridExamine));
				}
				else if(shortcut is GridMoveShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.GridMove));
				}
				else if(shortcut is GridOrientationShortcut)
				{
					list.Add(new BaseBMItem(cc, BMItemType.GridOrientation));
				}
			}
		}
	}
}
