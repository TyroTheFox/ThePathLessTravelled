﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LookAtActionBlock : BaseData
	{
		[ORKEditorHelp("Block Base Attack", "Base attack doesn't use this look at action.", "")]
		public bool blockBaseAttack = false;

		[ORKEditorHelp("Block Counter Attack", "Counter attack doesn't use this look at action.", "")]
		public bool blockCounterAttack = false;

		[ORKEditorHelp("Block Defend", "Defend doesn't use this look at action.", "")]
		public bool blockDefend = false;

		[ORKEditorHelp("Block Escape", "Escape doesn't use this look at action.", "")]
		public bool blockEscape = false;

		[ORKEditorHelp("Block Death", "Death doesn't use this look at action.", "")]
		public bool blockDeath = false;

		[ORKEditorHelp("Block None", "None (doing nothing) doesn't use this look at action.", "")]
		public bool blockNone = false;

		[ORKEditorHelp("Block Change Member", "Change member doesn't use this look at action.", "")]
		public bool blockChangeMember = false;

		[ORKEditorHelp("Block Join", "Join doesn't use this look at action.", "")]
		public bool blockJoin = false;

		[ORKEditorHelp("Block Grid Move", "Grid move doesn't use this look at action.", "")]
		public bool blockGridMove = false;


		// ability
		[ORKEditorHelp("Block Abilities", "Abilities don't use this look at action.\n" +
			"If disabled, you can optionally define abilities and ability types that will be blocked.", "")]
		[ORKEditorInfo(separator=true)]
		public bool blockAbilities = false;

		[ORKEditorLayout("blockAbilities", false, endCheckGroup=true)]
		public LimitAbility blockAbilityUse = new LimitAbility();


		// item
		[ORKEditorHelp("Block Items", "Items don't use this look at action.\n" +
			"If disabled, you can optionally define items and item types that will be blocked.", "")]
		[ORKEditorInfo(separator=true)]
		public bool blockItems = false;

		[ORKEditorLayout("blockItems", false, endCheckGroup=true)]
		public LimitAbility blockItemUse = new LimitAbility();

		public LookAtActionBlock()
		{

		}

		public bool IsBlocked(BaseAction action)
		{
			if(action.IsType(ActionType.Attack))
			{
				return this.blockBaseAttack;
			}
			else if(action.IsType(ActionType.CounterAttack))
			{
				return this.blockCounterAttack;
			}
			else if(action.IsType(ActionType.Ability))
			{
				return this.blockAbilities ||
					this.blockAbilityUse.Contains(action.Shortcut.ID, action.Shortcut.TypeID);
			}
			else if(action.IsType(ActionType.Item))
			{
				return this.blockItems ||
					this.blockItemUse.Contains(action.Shortcut.ID, action.Shortcut.TypeID);
			}
			else if(action.IsType(ActionType.Death))
			{
				return this.blockDeath;
			}
			else if(action.IsType(ActionType.None))
			{
				return this.blockNone;
			}
			else if(action.IsType(ActionType.GridMove))
			{
				return this.blockGridMove;
			}
			else if(action.IsType(ActionType.Defend))
			{
				return this.blockDefend;
			}
			else if(action.IsType(ActionType.Escape))
			{
				return this.blockEscape;
			}
			else if(action.IsType(ActionType.ChangeMember))
			{
				return this.blockChangeMember;
			}
			else if(action.IsType(ActionType.Join))
			{
				return this.blockJoin;
			}
			return false;
		}
	}
}
