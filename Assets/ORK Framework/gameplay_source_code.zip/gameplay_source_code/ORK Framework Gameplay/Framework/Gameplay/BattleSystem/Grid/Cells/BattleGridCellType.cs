﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridCellType : BaseLanguageData, IContentSimple
	{
		// random cell type
		[ORKEditorHelp("Random Cell Type", "This cell type randomly selects another defined cell type to replace it in-game.\n" +
			"If disabled, this cell type is used as a normal cell type.", "")]
		[ORKEditorInfo("Random Cell Type", "This cell type randomly selects another defined cell type to replace it in-game.\n" +
			"If disabled, this cell type is used as a normal cell type.", "")]
		public bool isRandomCellType = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("isRandomCellType", true, autoInit=true)]
		public BattleGridCellTypeRandom randomCellType;


		// single cell type
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BattleGridCellTypeSingle singleCellType;

		public BattleGridCellType()
		{

		}

		public BattleGridCellType(string name) : base(name)
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("name"))
			{
				string name = "";
				data.Get("name", ref name);
				this.languageInfo = new LanguageInfo[ORK.Languages.Count];
				for(int i = 0; i < this.languageInfo.Length; i++)
				{
					this.languageInfo[i] = new LanguageInfo(name);
				}
			}
			if(!this.isRandomCellType &&
				data.Contains<bool>("blocked"))
			{
				this.singleCellType = new BattleGridCellTypeSingle();
				this.singleCellType.SetData(data);
			}
		}

		public BattleGridCellType GetCellType()
		{
			if(this.isRandomCellType)
			{
				return this.randomCellType.GetCellType();
			}
			return this;
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject CreatePrefabInstance(BattleGridCellComponent cell, bool isEditor)
		{
			if(isEditor)
			{
				if(this.isRandomCellType)
				{
					return this.randomCellType.prefab.CreatePrefabInstance(cell, false);
				}
				else if(this.singleCellType.editorPrefab != null)
				{
					return this.singleCellType.prefab.CreatePrefabInstance(cell,
						this.singleCellType.editorPrefab, false);
				}
				else
				{
					return this.singleCellType.prefab.CreatePrefabInstance(cell, false);
				}
			}
			else if(!this.isRandomCellType)
			{
				return this.singleCellType.CreatePrefabInstance(cell);
			}
			return null;
		}


		/*
		============================================================================
		Cost functions
		============================================================================
		*/
		public bool CanMoveFrom(BattleGridCellComponent fromCell)
		{
			if(!this.isRandomCellType)
			{
				return this.singleCellType.CanMoveFrom(fromCell);
			}
			return true;
		}

		public string ReplaceMoveCosts(string text, Combatant user)
		{
			float cost = this.GetMoveCost(user);
			return text.
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}

		public float GetMoveCost(Combatant user)
		{
			return this.isRandomCellType ? 0 : this.singleCellType.GetMoveCost(user);
		}

		public float GetMoveCost(Combatant user, BattleGridCellComponent fromCell)
		{
			return this.isRandomCellType ? 0 : this.singleCellType.GetMoveCost(user, fromCell);
		}

		public float GetActionCost(Combatant user)
		{
			return this.isRandomCellType ? 0 : this.singleCellType.GetActionCost(user);
		}

		public float GetActionCost(Combatant user, BattleGridCellComponent fromCell)
		{
			return this.isRandomCellType ? 0 : this.singleCellType.GetActionCost(user, fromCell);
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetName(),
				ORK.Game.ActiveGroup.Leader);
		}

		public string GetName(Combatant user)
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetName(), user);
		}

		public string GetDescription()
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetDescription(),
				ORK.Game.ActiveGroup.Leader);
		}

		public string GetDescription(Combatant user)
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetDescription(), user);
		}

		public string GetIconTextCode()
		{
			return TextCode.BattleGridCellIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			GUIContent content = this.languageInfo[ORK.Game.Language].GetContent();
			content.text = this.ReplaceMoveCosts(content.text, ORK.Game.ActiveGroup.Leader);
			return content;
		}

		public GUIContent GetContent(Combatant user)
		{
			GUIContent content = this.languageInfo[ORK.Game.Language].GetContent();
			content.text = this.ReplaceMoveCosts(content.text, user);
			return content;
		}
	}
}
