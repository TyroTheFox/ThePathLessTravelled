﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridHighlightSettings : BaseData
	{
		// base highlights
		[ORKEditorHelp("Hide Unused Prefabs", "Spawned prefabs that are currently not in use " +
			"(e.g. the replaced cell prefab or the highlight prefab when stopping the highlight) will be hidden instead of disabled.\n" +
			"Hiding will disable the renderer and projector components on the prefab.\n" +
			"If disabled, the prefabs will be disabled.\n" +
			"Using this setting can have performance improvements when using prefabs as highlights.", "")]
		[ORKEditorInfo("Base Highlight Settings", "Define the base highlights that can be used by other grid highlights.", "")]
		public bool hideUnusedPrefabs = true;

		[ORKEditorInfo("Area Highlight", "Used for 'Area' highligting, e.g. move range.", "",
			endFoldout=true)]
		public BaseGridHighlight areaHighlight = new BaseGridHighlight();

		[ORKEditorInfo("Selection Highlight", "Used for 'Selection' highligting, e.g. target cell selection.", "",
			endFoldout=true)]
		public BaseGridHighlight selectionHighlight = new BaseGridHighlight();

		[ORKEditorInfo("No Selection Highlight", "Used for 'No Selection' highligting, e.g. cells not available for movement.", "",
			endFoldout=true, endFolds=2)]
		public BaseGridHighlight noSelectionHighlight = new BaseGridHighlight();


		// combatant cell
		[ORKEditorHelp("Use Combatant Cells", "Highlight the cell a combatant is currently occupying.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will be displayed permanently and overridden by all other highlights (e.g. combatant selection).", "")]
		[ORKEditorInfo("Combatant Cell", "Optionally highlight the cells currently occupied by combatants.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"TThese highlights will be displayed permanently and overridden by all other highlights (e.g. combatant selection).", "")]
		public bool useCombatantCells = false;

		[ORKEditorHelp("UI Hides Cells", "Combatant cell highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorLayout("useCombatantCells", true)]
		public bool uiHidesCombatantCells = false;

		[ORKEditorHelp("Use Turn Ended Cells", "Use different highlights for combatants that ended their turn.\n" +
			"Using turn ended highlights but not using a highlight for player/ally/enemy will fall back to the regular combatant cell highlights.", "")]
		public bool useTurnEndedCombatantCells = false;

		[ORKEditorInfo("Player Cell", "The player cell highlight is used to display the cells occupied by player group members.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantCellPlayer;

		[ORKEditorInfo("Ally Cell", "The ally cell highlight is used to display the cells occupied by allies of the player.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantCellAlly;

		[ORKEditorInfo("Enemy Cell", "The enemy cell highlight is used to display the cells occupied by enemies of the player.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantCellEnemy;

		[ORKEditorInfo("Turn Ended Player Cell", "The turn ended player cell highlight is used to display the cells occupied by " +
			"player group members that finished their turn.", "",
			endFoldout=true)]
		[ORKEditorLayout("useTurnEndedCombatantCells", true, autoInit=true)]
		public GridHighlight combatantCellPlayerTurnEnded;

		[ORKEditorInfo("Turn Ended Ally Cell", "The turn ended ally cell highlight is used to display the cells occupied by "+
			"allies of the player that finished their turn.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantCellAllyTurnEnded;

		[ORKEditorInfo("Turn Ended Enemy Cell", "The turn ended enemy cell highlight is used to display the cells occupied by "+
			"enemies of the player that finished their turn.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public GridHighlight combatantCellEnemyTurnEnded;


		// combatant selection
		[ORKEditorHelp("Use Combatant Selections", "Use different grid highlights when a cell with a combatant is selected.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will override other selection highlights (e.g. for move command or examine grid), " +
			"the highlights still have to be enabled to actually show the override highlight.", "")]
		[ORKEditorInfo("Combatant Selections", "Optionally use different selection highlights when a cell with a combatant is selected.\n" +
			"You can define different highlights for player group members, allies and enemies of the player.\n" +
			"These highlights will override other selection highlights (e.g. for move command or examine grid), " +
			"the highlights still have to be enabled to actually show the override highlight.", "")]
		public bool useCombatantSelections = false;

		[ORKEditorHelp("UI Hides Selections", "Combatant selection highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorLayout("useCombatantSelections", true)]
		public bool uiHidesCombatantSelections = false;

		[ORKEditorInfo("Player Selection", "The player selection highlight is used to display the currently selected cell " +
			"when a player group member is placed on the cell.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantSelectionPlayer;

		[ORKEditorInfo("Ally Selection", "The ally selection highlight is used to display the currently selected cell " +
			"when an ally of the player is placed on the cell.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public GridHighlight combatantSelectionAlly;

		[ORKEditorInfo("Enemy Selection", "The enemy selection highlight is used to display the currently selected cell " +
			"when an enemy of the player is placed on the cell.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public GridHighlight combatantSelectionEnemy;


		// placement
		[ORKEditorHelp("UI Hides Placement", "Combatant placement highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Combatant Placement", "Highlight settings for selecting a combatant's placement on the grid.", "")]
		public bool uiHidesPlacement = false;

		[ORKEditorInfo("Placement", "The placement highlight is used to display cells that are available for placing combatants.", "",
			endFoldout=true)]
		public GridHighlight placementHighlight = new GridHighlight(BaseGridHighlightType.Area);

		[ORKEditorInfo("Placement Selection", "The placement selection highlight is used to display " +
			"the currently selected cell that is available for placement.", "",
			endFoldout=true)]
		public GridHighlight placementSelectionHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("No Placement Selection", "The no placement selection highlight is used to display " +
			"the currently selected cell that is not available for placement.", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight noPlacementSelectionHighlight = new GridHighlight(BaseGridHighlightType.NoSelection);


		// move command
		[ORKEditorHelp("UI Hides Move Command", "Move command highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Move Command", "Highlight settings for selecting a combatant's move target for the grid move command.", "")]
		public bool uiHidesMoveCommand = false;

		[ORKEditorHelp("Blocked Highlight Occupied", "Cells occupied by a combatant are highlighted by the " +
			"'Move Range (Blocked)' and 'Move Range (Passable)' highlights.\n" +
			"If disabled, occupied cells aren't highlighted as blocked.", "")]
		public bool moveRangeBlockedHighlightOccupied = true;

		[ORKEditorInfo("Move Range", "The move range highlight is used to display cells that are available for moving.", "",
			endFoldout=true)]
		public GridHighlight moveRangeHighlight = new GridHighlight(BaseGridHighlightType.Area);

		[ORKEditorInfo("Move Range (Blocked)", "The move range highlight is used to display blocked cells within move range.", "",
			endFoldout=true)]
		public GridHighlight moveRangeBlockedHighlight = new GridHighlight();

		[ORKEditorInfo("Move Range (Passable)", "The move range highlight is used to display blocked cells within move range that are passable.", "",
			endFoldout=true)]
		public GridHighlight moveRangePassableHighlight = new GridHighlight();

		[ORKEditorInfo("Move Selection", "The move selection highlight is used to display " +
			"the currently selected cell that is available for movement when selecting a move target.", "",
			endFoldout=true)]
		public GridHighlight moveSelectionHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("No Move Selection", "The no move selection highlight is used to display " +
			"the currently selected cell that is not available for movement when selecting a move target.", "",
			endFoldout=true)]
		public GridHighlight noMoveSelectionHighlight = new GridHighlight(BaseGridHighlightType.NoSelection);

		[ORKEditorInfo("Move Path", "The move path highlight is used to display " +
			"the path to the currently selected cell when selecting a move target.", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight movePathHighlight = new GridHighlight();


		// available target
		[ORKEditorHelp("UI Hides Available Target", "Available target highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Available Target", "Highlight settings for available targets during target selection for an action.", "")]
		public bool uiHidesAvailableTarget = false;

		[ORKEditorHelp("In Action Selection", "The available targets of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the available target cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool availableTargetActionSelection = false;

		[ORKEditorHelp("In Target Selection", "The available targets of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the available target cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool availableTargetTargetSelection = false;

		[ORKEditorInfo("Available Target (Player)", "The available player target highlight is used to display " +
			"the available targets that are members of the player group during target selection (not target cell selection).", "",
			endFoldout=true)]
		public GridHighlight availableTargetPlayerHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("Available Target (Ally)", "The available ally target highlight is used to display " +
			"the available targets that are allies of the player during target selection (not target cell selection).", "",
			endFoldout=true)]
		public GridHighlight availableTargetAllyHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("Available Target (Enemy)", "The available enemy target highlight is used to display " +
			"the available targets that are enemies of the player during target selection (not target cell selection).", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight availableTargetEnemyHighlight = new GridHighlight(BaseGridHighlightType.Selection);


		// target cell selection
		[ORKEditorHelp("UI Hides Target Cell", "Target cell highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Target Cell", "Highlight settings for target cell selection for an action.", "")]
		public bool uiHidesTargetCell = false;

		[ORKEditorInfo("Target Cell Selection", "The target cell selection highlight is used to display " +
			"the currently selected cell that is a valid target.", "",
			endFoldout=true)]
		public GridHighlight targetCellSelectionHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("No Target Cell Selection", "The no target cell selection highlight is used to display " +
			"the currently selected cell that is not a valid target.", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight noTargetCellSelectionHighlight = new GridHighlight(BaseGridHighlightType.NoSelection);


		// orientation
		[ORKEditorHelp("UI Hides Orientation", "Orientation highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Orientation Selection", "The orientation selection highlight is used to display " +
			"the currently selected orientation cell (i.e. the cell the combatant will turn to) when selecting the orientation.", "")]
		public bool uiHidesOrientation = false;

		[ORKEditorInfo(endFoldout=true)]
		public GridHighlight orientationSelectionHighlight = new GridHighlight(BaseGridHighlightType.Selection);


		// marked cell
		[ORKEditorHelp("UI Hides Marked Cell", "Marked cell highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Marked Cell", "The marked cell highlight is used to display grid cells that are marked for a combatant " +
			"(e.g. being the target of a grid move command).\n" +
			"The marked cell highlight is always displayed while a cell is marked for a combatant.", "")]
		public bool uiHidesMarkedCell = false;

		[ORKEditorInfo(endFoldout=true)]
		public GridHighlight markedCellHighlight = new GridHighlight(BaseGridHighlightType.Area);


		// use range
		[ORKEditorHelp("UI Hides Use Range", "Use range highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Use Range", "The use range highlight is used to display use ranges of abilities and items.", "")]
		public bool uiHidesUseRange = false;

		[ORKEditorHelp("In Action Selection", "The use range of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the use range cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool useRangeActionSelection = false;

		[ORKEditorHelp("In Target Selection", "The use range of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the use range cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool useRangeTargetSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		public GridHighlight useRangeHighlight = new GridHighlight(BaseGridHighlightType.Area);


		// affect range
		[ORKEditorHelp("UI Hides Affect Range", "Affect range highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Affect Range", "The affect range highlight is used to display affect ranges of abilities and items.", "")]
		public bool uiHidesAffectRange = false;

		[ORKEditorHelp("In Action Selection", "The affect range of an ability/item will be highlighted in the action selection of the battle menu.\n" +
			"I.e. the affect range cells will be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool affectRangeActionSelection = false;

		[ORKEditorHelp("In Target Selection", "The affect range of an ability/item will be highlighted in the target selection.\n" +
			"I.e. the affect range cells will be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool affectRangeTargetSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		public GridHighlight affectRangeHighlight = new GridHighlight(BaseGridHighlightType.Area);


		// examine grid
		[ORKEditorHelp("UI Hides Examine", "Examine highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Examine Selection", "Highlight settings for the examine cell selection.", "")]
		public bool uiHidesExamine = false;

		[ORKEditorHelp("Combatant Is Blocked", "Combatants use the blocked selection cursor.", "")]
		public bool examineCombatantIsBlocked = false;

		[ORKEditorInfo("Examine (Not Blocked)", "The examine selection highlight is used to display " +
			"the currently selected cell (not blocked) during grid examination.", "",
			endFoldout=true)]
		public GridHighlight examineHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("Examine (Blocked)", "The examine blocked selection highlight is used to display " +
			"the currently selected cell (blocked) during grid examination.", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight examineBlockedHighlight = new GridHighlight(BaseGridHighlightType.Selection);


		// selecting combatant
		[ORKEditorHelp("UI Hides Selecting Combatant", "Selecting combatant highlights are hidden while the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorInfo("Selecting Combatant", "Highlight settings for the selecting combatant.", "")]
		public bool uiHidesSelectingCombatant = false;

		[ORKEditorHelp("Prioritize Selecting", "The selecting combatant highlights will be prioritized, " +
			"i.e. they'll be displayed instead of all other highlights (e.g. selection cursors).", "")]
		public bool selectingPriority = false;

		[ORKEditorHelp("In Action Selection", "The selecting combatant will also be highlighted in the action selection of the battle menu.\n" +
			"I.e. the selecting combatant's cell will also be highlighted upon selecting (not accepting) the base attack or an ability/item in the battle menu.", "")]
		public bool selectingCombatantActionSelection = false;

		[ORKEditorHelp("In Target Selection", "The selecting combatant will also be highlighted in the target selection.\n" +
			"I.e. the selecting combatant's cell will also be highlighted while selecting (not accepting) a target for the ability/item.", "")]
		public bool selectingCombatantTargetSelection = false;

		[ORKEditorInfo("Selecting Player", "The selecting player highlight is used to display " +
			"the currently selecting members of the player group.", "",
			endFoldout=true)]
		public GridHighlight selectingPlayerHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("Selecting Ally", "The selecting ally highlight is used to display " +
			"the currently selecting combatants that are allies of the player.", "",
			endFoldout=true)]
		public GridHighlight selectingAllyHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		[ORKEditorInfo("Selecting Enemy", "The selecting enemy highlight is used to display " +
			"the currently selecting combatants that are enemies of the player.", "",
			endFoldout=true, endFolds=2)]
		public GridHighlight selectingEnemyHighlight = new GridHighlight(BaseGridHighlightType.Selection);

		public BattleGridHighlightSettings()
		{

		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Tick()
		{
			float deltaTime = ORK.Game.DeltaTime;

			this.areaHighlight.Tick(deltaTime);
			this.selectionHighlight.Tick(deltaTime);
			this.noSelectionHighlight.Tick(deltaTime);
			this.placementHighlight.Tick(deltaTime);
			this.placementSelectionHighlight.Tick(deltaTime);
			this.noPlacementSelectionHighlight.Tick(deltaTime);
			this.moveRangeHighlight.Tick(deltaTime);
			this.moveRangeBlockedHighlight.Tick(deltaTime);
			this.moveRangePassableHighlight.Tick(deltaTime);
			this.moveSelectionHighlight.Tick(deltaTime);
			this.noMoveSelectionHighlight.Tick(deltaTime);
			this.movePathHighlight.Tick(deltaTime);
			this.targetCellSelectionHighlight.Tick(deltaTime);
			this.noTargetCellSelectionHighlight.Tick(deltaTime);
			this.orientationSelectionHighlight.Tick(deltaTime);
			this.markedCellHighlight.Tick(deltaTime);
			this.useRangeHighlight.Tick(deltaTime);
			this.affectRangeHighlight.Tick(deltaTime);
			this.examineHighlight.Tick(deltaTime);
			this.examineBlockedHighlight.Tick(deltaTime);
			this.availableTargetPlayerHighlight.Tick(deltaTime);
			this.availableTargetAllyHighlight.Tick(deltaTime);
			this.availableTargetEnemyHighlight.Tick(deltaTime);
			this.selectingPlayerHighlight.Tick(deltaTime);
			this.selectingAllyHighlight.Tick(deltaTime);
			this.selectingEnemyHighlight.Tick(deltaTime);

			if(this.useCombatantCells)
			{
				this.combatantCellPlayer.Tick(deltaTime);
				this.combatantCellAlly.Tick(deltaTime);
				this.combatantCellEnemy.Tick(deltaTime);
				if(this.useTurnEndedCombatantCells)
				{
					this.combatantCellPlayerTurnEnded.Tick(deltaTime);
					this.combatantCellAllyTurnEnded.Tick(deltaTime);
					this.combatantCellEnemyTurnEnded.Tick(deltaTime);
				}
			}

			if(this.useCombatantSelections)
			{
				this.combatantSelectionPlayer.Tick(deltaTime);
				this.combatantSelectionAlly.Tick(deltaTime);
				this.combatantSelectionEnemy.Tick(deltaTime);
			}

			if(this.uiHidesCombatantCells ||
				this.uiHidesCombatantSelections ||
				this.uiHidesPlacement ||
				this.uiHidesMoveCommand ||
				this.uiHidesAvailableTarget ||
				this.uiHidesTargetCell ||
				this.uiHidesOrientation ||
				this.uiHidesUseRange ||
				this.uiHidesAffectRange ||
				this.uiHidesExamine ||
				this.uiHidesSelectingCombatant)
			{
				ORK.Battle.Grid.HighlightsHidden = ORK.GUI.IsCursorOver;
			}
		}

		public bool IsHidden(GridHighlightType type)
		{
			if(ORK.GUI.IsCursorOver)
			{
				// placement
				return (this.uiHidesCombatantCells &&
						(GridHighlightType.CellPlayer == type ||
						GridHighlightType.CellAlly == type ||
						GridHighlightType.CellEnemy == type)) ||
					// placement
					(this.uiHidesPlacement &&
						(GridHighlightType.Placement == type ||
						GridHighlightType.PlacementSelection == type ||
						GridHighlightType.NoPlacementSelection == type)) ||
					// move command
					(this.uiHidesMoveCommand &&
						(GridHighlightType.MovePath == type ||
						GridHighlightType.MoveRange == type ||
						GridHighlightType.MoveRangeBlocked == type ||
						GridHighlightType.MoveRangePassable == type ||
						GridHighlightType.MoveSelection == type ||
						GridHighlightType.NoMoveSelection == type)) ||
					// available targets
					(this.uiHidesAvailableTarget &&
						(GridHighlightType.AvailableTargetAlly == type ||
						GridHighlightType.AvailableTargetEnemy == type ||
						GridHighlightType.AvailableTargetPlayer == type)) ||
					// target cell
					(this.uiHidesTargetCell &&
						(GridHighlightType.TargetCellSelection == type ||
						GridHighlightType.NoTargetCellSelection == type)) ||
					// orientation
					(this.uiHidesOrientation &&
						GridHighlightType.OrientationSelection == type) ||
					// marked cell
					(this.uiHidesMarkedCell &&
						GridHighlightType.MarkedCell == type) ||
					// use range
					(this.uiHidesUseRange &&
						GridHighlightType.UseRange == type) ||
					// affect range
					(this.uiHidesAffectRange &&
						GridHighlightType.AffectRange == type) ||
					// examine
					(this.uiHidesExamine &&
						(GridHighlightType.ExamineSelection == type ||
						GridHighlightType.ExamineSelectionBlocked == type ||
						GridHighlightType.ExamineMoveRange == type ||
						GridHighlightType.ExamineMoveRangeBlocked == type ||
						GridHighlightType.ExamineMoveRangePassable == type ||
						GridHighlightType.ExamineUseRange == type)) ||
					// selecting combatant
					(this.uiHidesSelectingCombatant &&
						(GridHighlightType.SelectingAlly == type ||
						GridHighlightType.SelectingEnemy == type ||
						GridHighlightType.SelectingPlayer == type)) ||
					// combatant selection
					(this.uiHidesCombatantSelections &&
						(GridHighlightType.PlacementSelectionPlayer == type ||
						GridHighlightType.PlacementSelectionEnemy == type ||
						GridHighlightType.PlacementSelectionAlly == type ||
						GridHighlightType.MoveSelectionPlayer == type ||
						GridHighlightType.MoveSelectionAlly == type ||
						GridHighlightType.MoveSelectionEnemy == type ||
						GridHighlightType.OrientationSelectionPlayer == type ||
						GridHighlightType.OrientationSelectionAlly == type ||
						GridHighlightType.OrientationSelectionEnemy == type ||
						GridHighlightType.TargetCellSelectionPlayer == type ||
						GridHighlightType.TargetCellSelectionAlly == type ||
						GridHighlightType.TargetCellSelectionEnemy == type ||
						GridHighlightType.ExamineSelectionPlayer == type ||
						GridHighlightType.ExamineSelectionAlly == type ||
						GridHighlightType.ExamineSelectionEnemy == type));
			}
			return false;
		}

		public GridHighlightType GetSelectionHighlight(GridHighlightType type, BattleGridCellComponent cell)
		{
			if(this.useCombatantSelections &&
				cell != null && cell.Combatant != null)
			{
				// player
				if(cell.Combatant.IsPlayerControlled())
				{
					if(this.combatantSelectionPlayer.enable)
					{
						// placement
						if(GridHighlightType.PlacementSelection == type ||
							GridHighlightType.NoPlacementSelection == type)
						{
							return GridHighlightType.PlacementSelectionPlayer;
						}
						// move command
						else if(GridHighlightType.MoveSelection == type ||
							GridHighlightType.NoMoveSelection == type)
						{
							return GridHighlightType.MoveSelectionPlayer;
						}
						// orientation
						else if(GridHighlightType.OrientationSelection == type)
						{
							return GridHighlightType.OrientationSelectionPlayer;
						}
						// target cell
						else if(GridHighlightType.TargetCellSelection == type ||
							GridHighlightType.NoTargetCellSelection == type)
						{
							return GridHighlightType.TargetCellSelectionPlayer;
						}
						// examine
						else if(GridHighlightType.ExamineSelection == type ||
							GridHighlightType.ExamineSelectionBlocked == type)
						{
							return GridHighlightType.ExamineSelectionPlayer;
						}
					}
				}
				// enemy
				else if(cell.Combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(this.combatantSelectionEnemy.enable)
					{
						// placement
						if(GridHighlightType.PlacementSelection == type ||
							GridHighlightType.NoPlacementSelection == type)
						{
							return GridHighlightType.PlacementSelectionEnemy;
						}
						// move command
						else if(GridHighlightType.MoveSelection == type ||
							GridHighlightType.NoMoveSelection == type)
						{
							return GridHighlightType.MoveSelectionEnemy;
						}
						// orientation
						else if(GridHighlightType.OrientationSelection == type)
						{
							return GridHighlightType.OrientationSelectionEnemy;
						}
						// target cell
						else if(GridHighlightType.TargetCellSelection == type ||
							GridHighlightType.NoTargetCellSelection == type)
						{
							return GridHighlightType.TargetCellSelectionEnemy;
						}
						// examine
						else if(GridHighlightType.ExamineSelection == type ||
							GridHighlightType.ExamineSelectionBlocked == type)
						{
							return GridHighlightType.ExamineSelectionEnemy;
						}
					}
				}
				// ally
				else if(this.combatantSelectionAlly.enable)
				{
					// placement
					if(GridHighlightType.PlacementSelection == type ||
							GridHighlightType.NoPlacementSelection == type)
					{
						return GridHighlightType.PlacementSelectionAlly;
					}
					// move command
					else if(GridHighlightType.MoveSelection == type ||
						GridHighlightType.NoMoveSelection == type)
					{
						return GridHighlightType.MoveSelectionAlly;
					}
					// orientation
					else if(GridHighlightType.OrientationSelection == type)
					{
						return GridHighlightType.OrientationSelectionAlly;
					}
					// target cell
					else if(GridHighlightType.TargetCellSelection == type ||
						GridHighlightType.NoTargetCellSelection == type)
					{
						return GridHighlightType.TargetCellSelectionAlly;
					}
					// examine
					else if(GridHighlightType.ExamineSelection == type ||
						GridHighlightType.ExamineSelectionBlocked == type)
					{
						return GridHighlightType.ExamineSelectionAlly;
					}
				}
			}
			return type;
		}

		public GridHighlightType GetCombatantCellHighlight(Combatant combatant)
		{
			if(this.useCombatantCells &&
				combatant != null)
			{
				// player
				if(combatant.IsPlayerControlled())
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellPlayerTurnEnded.enable)
					{
						return GridHighlightType.CellPlayerTurnEnded;
					}
					else if(this.combatantCellPlayer.enable)
					{
						return GridHighlightType.CellPlayer;
					}
				}
				// enemy
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellEnemyTurnEnded.enable)
					{
						return GridHighlightType.CellEnemyTurnEnded;
					}
					else if(this.combatantCellEnemy.enable)
					{
						return GridHighlightType.CellEnemy;
					}
				}
				// ally
				else
				{
					if(CombatantTurnState.AfterTurn == combatant.Battle.TurnState &&
						this.useTurnEndedCombatantCells &&
						this.combatantCellAllyTurnEnded.enable)
					{
						return GridHighlightType.CellAllyTurnEnded;
					}
					else if(this.combatantCellAlly.enable)
					{
						return GridHighlightType.CellAlly;
					}
				}
			}
			return GridHighlightType.None;
		}

		public bool IsEnabled(GridHighlightType type)
		{
			GridHighlight highlight = this.GetHighlight(type);
			return highlight != null && highlight.enable;
		}

		public GridHighlight GetHighlight(GridHighlightType type)
		{
			// combatant cell
			// player
			if(GridHighlightType.CellPlayerTurnEnded == type)
			{
				return this.combatantCellPlayerTurnEnded;
			}
			else if(GridHighlightType.CellPlayer == type)
			{
				return this.combatantCellPlayer;
			}
			// ally
			else if(GridHighlightType.CellAllyTurnEnded == type)
			{
				return this.combatantCellAllyTurnEnded;
			}
			else if(GridHighlightType.CellAlly == type)
			{
				return this.combatantCellAlly;
			}
			// enemey
			else if(GridHighlightType.CellEnemyTurnEnded == type)
			{
				return this.combatantCellEnemyTurnEnded;
			}
			else if(GridHighlightType.CellEnemy == type)
			{
				return this.combatantCellEnemy;
			}
			// combatant selection override
			else if(GridHighlightType.PlacementSelectionPlayer == type ||
				GridHighlightType.MoveSelectionPlayer == type ||
				GridHighlightType.OrientationSelectionPlayer == type ||
				GridHighlightType.TargetCellSelectionPlayer == type ||
				GridHighlightType.ExamineSelectionPlayer == type)
			{
				return this.combatantSelectionPlayer;
			}
			else if(GridHighlightType.PlacementSelectionAlly == type ||
				GridHighlightType.MoveSelectionAlly == type ||
				GridHighlightType.OrientationSelectionAlly == type ||
				GridHighlightType.TargetCellSelectionAlly == type ||
				GridHighlightType.ExamineSelectionAlly == type)
			{
				return this.combatantSelectionAlly;
			}
			else if(GridHighlightType.PlacementSelectionEnemy == type ||
				GridHighlightType.MoveSelectionEnemy == type ||
				GridHighlightType.OrientationSelectionEnemy == type ||
				GridHighlightType.TargetCellSelectionEnemy == type ||
				GridHighlightType.ExamineSelectionEnemy == type)
			{
				return this.combatantSelectionEnemy;
			}
			// placement
			else if(GridHighlightType.Placement == type)
			{
				return this.placementHighlight;
			}
			else if(GridHighlightType.PlacementSelection == type)
			{
				return this.placementSelectionHighlight;
			}
			else if(GridHighlightType.NoPlacementSelection == type)
			{
				return this.noPlacementSelectionHighlight;
			}
			// move
			else if(GridHighlightType.MoveRange == type)
			{
				return this.moveRangeHighlight;
			}
			else if(GridHighlightType.MoveRangeBlocked == type)
			{
				return this.moveRangeBlockedHighlight;
			}
			else if(GridHighlightType.MoveRangePassable == type)
			{
				return this.moveRangePassableHighlight;
			}
			else if(GridHighlightType.MoveSelection == type)
			{
				return this.moveSelectionHighlight;
			}
			else if(GridHighlightType.NoMoveSelection == type)
			{
				return this.noMoveSelectionHighlight;
			}
			else if(GridHighlightType.MovePath == type)
			{
				return this.movePathHighlight;
			}
			// orientation
			else if(GridHighlightType.OrientationSelection == type)
			{
				return this.orientationSelectionHighlight;
			}
			// marked cell
			else if(GridHighlightType.MarkedCell == type)
			{
				return this.markedCellHighlight;
			}
			// use/affect range
			else if(GridHighlightType.UseRange == type)
			{
				return this.useRangeHighlight;
			}
			else if(GridHighlightType.AffectRange == type)
			{
				return this.affectRangeHighlight;
			}
			// available target
			else if(GridHighlightType.AvailableTargetPlayer == type)
			{
				return this.availableTargetPlayerHighlight;
			}
			else if(GridHighlightType.AvailableTargetAlly == type)
			{
				return this.availableTargetAllyHighlight;
			}
			else if(GridHighlightType.AvailableTargetEnemy == type)
			{
				return this.availableTargetEnemyHighlight;
			}
			// target cell
			else if(GridHighlightType.TargetCellSelection == type)
			{
				return this.targetCellSelectionHighlight;
			}
			else if(GridHighlightType.NoTargetCellSelection == type)
			{
				return this.noTargetCellSelectionHighlight;
			}
			// examine
			else if(GridHighlightType.ExamineSelection == type)
			{
				return this.examineHighlight;
			}
			else if(GridHighlightType.ExamineSelectionBlocked == type)
			{
				return this.examineBlockedHighlight;
			}
			else if(GridHighlightType.ExamineMoveRange == type)
			{
				return this.moveRangeHighlight;
			}
			else if(GridHighlightType.ExamineMoveRangeBlocked == type)
			{
				return this.moveRangeBlockedHighlight;
			}
			else if(GridHighlightType.ExamineMoveRangePassable == type)
			{
				return this.moveRangePassableHighlight;
			}
			else if(GridHighlightType.ExamineUseRange == type)
			{
				return this.useRangeHighlight;
			}
			// selecting combatant
			else if(GridHighlightType.SelectingPlayer == type)
			{
				return this.selectingPlayerHighlight;
			}
			else if(GridHighlightType.SelectingAlly == type)
			{
				return this.selectingAllyHighlight;
			}
			else if(GridHighlightType.SelectingEnemy == type)
			{
				return this.selectingEnemyHighlight;
			}
			return null;
		}
	}
}
