﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class DefendBattleMenuItem : BaseBattleMenuItem
	{
		// button
		[ORKEditorHelp("Use Action Info", "Use the 'Defend Command' content information defined in the 'Battle Texts' settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		public bool useActionInfo = false;

		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("useActionInfo", false, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;

		public DefendBattleMenuItem()
		{

		}

		public DefendBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Defend == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			ChoiceContent cc = this.useActionInfo ?
				bm.contentLayout.GetChoiceContent(ORK.BattleTexts.defendCommandText) :
				bm.contentLayout.GetChoiceContent(this.button);
			this.customSkin.SetSkin(cc);
			list.Add(new BaseBMItem(cc, BMItemType.Defend));
		}
	}
}
