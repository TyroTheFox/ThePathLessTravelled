﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveHeightLimit : BaseData
	{
		// upward movement
		[ORKEditorHelp("Limit Upward Move", "Moving upward is limited to a defined maximum height difference.\n" +
			"A combatant can only move from a cell to another cell if the other cell isn't higher than a defined distance.", "")]
		public bool limitUpwardMove = false;

		[ORKEditorHelp("Max Upward Distance", "The maximum height distance a cell can be above to allow movement to it.", "")]
		[ORKEditorLayout("limitUpwardMove", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float maxUpwardDistance = 1;


		// downward movement
		[ORKEditorHelp("Limit Downward Move", "Moving downward is limited to a defined maximum height difference.\n" +
			"A combatant can only move from a cell to another cell if the other cell isn't lower than a defined distance.", "")]
		[ORKEditorInfo(separator=true)]
		public bool limitDownwardMove = false;

		[ORKEditorHelp("Max Downward Distance", "The maximum height distance a cell can be below to allow movement to it.", "")]
		[ORKEditorLayout("limitDownwardMove", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float maxDownwardDistance = 1;

		public GridMoveHeightLimit()
		{

		}

		public bool Check(BattleGridCellComponent origin, BattleGridCellComponent target)
		{
			// upward
			if(this.limitUpwardMove &&
				target.transform.position.y - origin.transform.position.y > this.maxUpwardDistance)
			{
				return false;
			}

			// downward
			if(this.limitDownwardMove &&
				origin.transform.position.y - target.transform.position.y > this.maxDownwardDistance)
			{
				return false;
			}

			return true;
		}
	}
}
