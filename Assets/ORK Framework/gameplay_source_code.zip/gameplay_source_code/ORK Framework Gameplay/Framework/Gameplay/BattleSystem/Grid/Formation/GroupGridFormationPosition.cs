﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupGridFormationPosition
	{
		private int index = 0;

		private BattleGridFormationPosition settings;

		private CubeCoord coord;

		private Combatant combatant;

		public GroupGridFormationPosition(int index, BattleGridFormationPosition settings)
		{
			this.index = index;
			this.settings = settings;
		}


		/*
		============================================================================
		Properties functions
		============================================================================
		*/
		public int Index
		{
			get { return this.index; }
		}

		public BattleGridFormationPosition Settings
		{
			get { return this.settings; }
		}

		public CubeCoord CubeCoord
		{
			get { return this.coord; }
			set { this.coord = value; }
		}

		public BattleGridCellComponent Cell
		{
			get { return ORK.Battle.Grid != null ? ORK.Battle.Grid.GetCell(this.coord) : null; }
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
			set { this.combatant = value; }
		}

		public bool OnPosition
		{
			get
			{
				return this.combatant != null &&
					this.combatant.Grid.Cell != null &&
					this.coord == this.combatant.Grid.Cell.CubeCoord;
			}
		}

		public int DistanceToPosition
		{
			get
			{
				return this.combatant != null && this.combatant.Grid.Cell != null ?
					this.coord.Distance(this.combatant.Grid.Cell.CubeCoord) : -1;
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CanReach(BattleGridCellComponent cell, bool keepBlockedCells)
		{
			if(this.combatant != null &&
				this.combatant.Grid.Cell != null &&
				ORK.Battle.Grid != null)
			{
				return GridPathFinder.CanReach(this.combatant, cell,
					keepBlockedCells, true, MoveRangeType.Current, null, null);
			}
			return false;
		}
	}
}
