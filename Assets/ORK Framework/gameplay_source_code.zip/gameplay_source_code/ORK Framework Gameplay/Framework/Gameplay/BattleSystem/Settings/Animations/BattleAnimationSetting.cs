﻿
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleAnimationSetting : BaseData
	{
		[ORKEditorHelp("Animate Action", "This action will perform a series of battle events when used.", "")]
		public bool animate = false;

		[ORKEditorArray(false, "Add Animation", "Adds a battle event to this action.\n" +
			"All battle events (passing the chance/requirement check) will be performed one by one.", "",
			"Remove", "Removes this battle event from the list.", "",
			isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Battle Event", "Define the battle event, chance and battle systems the event will be performed in.", ""
			})]
		[ORKEditorLayout("animate", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] animation;

		public BattleAnimationSetting()
		{

		}

		public void UpgradeSetting(DataObject data, string animateName, string animationName)
		{
			data.Get(animateName, ref this.animate);
			if(this.animate)
			{
				DataObject[] animationData = data.GetFileArray(animationName);
				if(animationData != null)
				{
					this.animation = new BattleAnimation[animationData.Length];
					for(int i = 0; i < this.animation.Length; i++)
					{
						this.animation[i] = new BattleAnimation();
						this.animation[i].SetData(animationData[i]);
					}
				}
				else
				{
					this.animate = false;
				}
			}
		}

		public void GetBattleAnimation(Combatant combatant, ref List<BattleEvent> list)
		{
			if(this.animate &&
				this.animation != null)
			{
				for(int i = 0; i < this.animation.Length; i++)
				{
					this.animation[i].GetEvent(combatant, ref list);
				}
			}
		}
	}
}
