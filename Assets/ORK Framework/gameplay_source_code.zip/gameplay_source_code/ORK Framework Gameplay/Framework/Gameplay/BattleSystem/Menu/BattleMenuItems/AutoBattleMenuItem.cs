﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AutoBattleMenuItem : BaseBattleMenuItem
	{
		[ORKEditorHelp("Whole Group", "All members of the user's battle group will use the 'Auto' command once.\n" +
			"If disabled, only the user will use the 'Auto' command.\n" +
			"This isn't used in 'Real Time' battles.", "")]
		public bool groupAuto = false;

		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);

		public AutoBattleMenuItem()
		{

		}

		public AutoBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("wholeGroup"))
			{
				data.Get("wholeGroup", ref this.groupAuto);
			}
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.Auto == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			ChoiceContent cc = bm.contentLayout.GetChoiceContent(this.button);
			this.customSkin.SetSkin(cc);
			list.Add(new AutoBMItem(cc, this.groupAuto));
		}
	}
}
