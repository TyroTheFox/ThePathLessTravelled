
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.UI;

namespace ORKFramework
{
	public class BattleMenuItem : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the battle menu option/command:\n" +
			"- Attack: The combatant's base or counter attack.\n" +
			"- Ability: Lists the combatant's abilities.\n" +
			"- Class Ability: The combatant's class ability (will only be displayed if a class ability is available).\n" +
			"- Item: Lists the combatant's items.\n" +
			"- Defend: Uses the combatant's defend command.\n" +
			"- Escape: Uses the combatant's escape command.\n" +
			"- End: Ends the combatant's turn.\n" +
			"- Auto: Automatically selects a command using the combatant's AI settings.\n" +
			"- Equipment: Lists the combatant's equipment parts and allows changing the equipment (similar to the equipment menu).\n" +
			"- Command: Give a member of the combatant's group a command (i.e. the next action they should use).\n" +
			"- Change Member: Lists the combatant group's non-battle members and allows changing the combatant.\n" +
			"- Grid Move: Uses the combatant's move command after selecting a grid cell as target. Only available in grid battles.\n" +
			"- Grid Orientation: Allows selecting the orientation (rotation) on a battle's grid. Only available in grid battles.\n" +
			"- Grid Examine: Allows examining the battle's grid. Only available in grid battles.\n" +
			"- AI Behaviour: Lists the combatant's AI behaviour slots and allows changing the equipped AI behaviours.\n" +
			"- AI Ruleset: Lists the combatant's AI ruleset slots and allows changing the equipped AI rulesets.\n" +
			"- Shortcut Slot: Displays the shortcut assigned to a defined shortcut slot.", "")]
		public BMItemType type = BMItemType.Attack;


		// settings
		[ORKEditorLayout(autoSetup=true)]
		public BaseBattleMenuItem settings = new AttackBattleMenuItem();

		public BattleMenuItem()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<DataObject>("settings"))
			{
				this.EditorAutoSetup("settings");

				if(BMItemType.Attack == this.type &&
					data.Contains<DataObject>("attack"))
				{
					this.settings.SetData(data.GetFile("attack"));
				}
				else if(BMItemType.Ability == this.type &&
					data.Contains<DataObject>("ability"))
				{
					this.settings.SetData(data.GetFile("ability"));
				}
				else if(BMItemType.ClassAbility == this.type &&
					data.Contains<DataObject>("classAbility"))
				{
					this.settings.SetData(data.GetFile("classAbility"));
				}
				else if(BMItemType.Item == this.type &&
					data.Contains<DataObject>("item"))
				{
					this.settings.SetData(data.GetFile("item"));
				}
				else if(BMItemType.Auto == this.type &&
					data.Contains<DataObject>("auto"))
				{
					this.settings.SetData(data.GetFile("auto"));
				}
				else if(BMItemType.Equipment == this.type &&
					data.Contains<DataObject>("equipment"))
				{
					this.settings.SetData(data.GetFile("equipment"));
				}
				else if(BMItemType.Command == this.type &&
					data.Contains<DataObject>("command"))
				{
					this.settings.SetData(data.GetFile("command"));
				}
				else if(BMItemType.AIBehaviour == this.type &&
					data.Contains<DataObject>("aiBehaviour"))
				{
					this.settings.SetData(data.GetFile("aiBehaviour"));
				}
				else if(BMItemType.AIRuleset == this.type &&
					data.Contains<DataObject>("aiRuleset"))
				{
					this.settings.SetData(data.GetFile("aiRuleset"));
				}
				else
				{
					this.settings.SetData(data);
				}
			}
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();

				if(BMItemType.Attack == this.type)
				{
					this.settings = new AttackBattleMenuItem(data);
				}
				else if(BMItemType.Ability == this.type)
				{
					this.settings = new AbilityBattleMenuItem(data);
				}
				else if(BMItemType.ClassAbility == this.type)
				{
					this.settings = new ClassAbilityBattleMenuItem(data);
				}
				else if(BMItemType.Item == this.type)
				{
					this.settings = new ItemBattleMenuItem(data);
				}
				else if(BMItemType.Defend == this.type)
				{
					this.settings = new DefendBattleMenuItem(data);
				}
				else if(BMItemType.Escape == this.type)
				{
					this.settings = new EscapeBattleMenuItem(data);
				}
				else if(BMItemType.End == this.type)
				{
					this.settings = new EndBattleMenuItem(data);
				}
				else if(BMItemType.Auto == this.type)
				{
					this.settings = new AutoBattleMenuItem(data);
				}
				else if(BMItemType.Equipment == this.type)
				{
					this.settings = new EquipmentBattleMenuItem(data);
				}
				else if(BMItemType.Command == this.type)
				{
					this.settings = new CommandBattleMenuItem(data);
				}
				else if(BMItemType.ChangeMember == this.type)
				{
					this.settings = new ChangeMemberBattleMenuItem(data);
				}
				else if(BMItemType.GridMove == this.type)
				{
					this.settings = new GridMoveBattleMenuItem(data);
				}
				else if(BMItemType.GridOrientation == this.type)
				{
					this.settings = new GridOrientationBattleMenuItem(data);
				}
				else if(BMItemType.GridExamine == this.type)
				{
					this.settings = new GridExamineBattleMenuItem(data);
				}
				else if(BMItemType.AIBehaviour == this.type)
				{
					this.settings = new AIBehaviourBattleMenuItem(data);
				}
				else if(BMItemType.AIRuleset == this.type)
				{
					this.settings = new AIRulesetBattleMenuItem(data);
				}
				else if(BMItemType.ShortcutSlot == this.type)
				{
					this.settings = new ShortcutSlotBattleMenuItem(data);
				}
			}
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm)
		{
			this.settings.AddToMenu(ref list, owner, bm, this);
		}
	}
}
