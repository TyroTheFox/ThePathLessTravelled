﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LookAtRequirement : BaseData
	{
		// check distance settings
		[ORKEditorHelp("Use Minimum Distance", "Check for a minimum distance to the target.", "")]
		[ORKEditorInfo(labelText="Check Distance")]
		public bool useMinDistance = false;

		[ORKEditorHelp("Minimum Distance", "The minimum distance to the target.", "")]
		[ORKEditorLayout("useMinDistance", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minDistance = 1;

		[ORKEditorHelp("Use Maximum Distance", "Check for a maximum distance to the target.", "")]
		public bool useMaxDistance = false;

		[ORKEditorHelp("Maximum Distance", "The maximum distance to the target.", "")]
		[ORKEditorLayout("useMaxDistance", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float maxDistance = 10;

		[ORKEditorHelp("Ignore Height Distance", "The distance along the height axis will be ignored.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorLayout(new string[] { "useMinDistance", "useMaxDistance" },
			new object[] { true, true },
			needed=Needed.One)]
		public bool ignoreHeightDistance = true;

		[ORKEditorHelp("Distance Origin", "Select from where the distance is measured:\n" +
			"- User: The user of the action that caused the camera change (can be the same as the target in some cases).\n" +
			"- Camera Control Target: From the current camera control target.\n" +
			"- Player: From the player.\n" +
			"- Arena: From the battle arena.\n" +
			"Please note that the player is used if camera control target or arena are not available.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public BattleCameraDistanceOrigin distanceOrigin = BattleCameraDistanceOrigin.User;


		// check viewport settings
		[ORKEditorHelp("Use Viewport", "Check the position of the new camera target in viewport space of the camera.\n" +
			"The camera change will be performed if the position is outside of the " +
			"defined horizontal or vertical viewport values (from the center).", "")]
		[ORKEditorInfo(separator=true, labelText="Check Viewport")]
		public bool useViewport = false;

		[ORKEditorHelp("Horizontal Viewport", "The horizontal viewport value.\n" +
			"E.g. 0.25 means that the camera change will be performed if the target is 25% off the center to the left or right.", "")]
		[ORKEditorLayout("useViewport", true)]
		[ORKEditorLimit(0.0f, false)]
		public float horizontalViewport = 0.25f;

		[ORKEditorHelp("Vertical Viewport", "The vertical viewport value.\n" +
			"E.g. 0.25 means that the camera change will be performed if the target is 25% off the center to the top or bottom.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float verticalViewport = 0.25f;

		public LookAtRequirement()
		{

		}

		public bool Check(Camera camera, Transform user, Transform target)
		{
			return this.CheckDistance(user, target) &&
				this.CheckViewport(camera, target);
		}

		public bool CheckDistance(Transform user, Transform target)
		{
			if(target != null &&
				(this.useMinDistance ||
					this.useMaxDistance))
			{
				bool found = false;
				float distance = 0;
				if(BattleCameraDistanceOrigin.User == this.distanceOrigin)
				{
					if(user != null)
					{
						found = true;
						distance = VectorHelper.Distance(user.transform.position,
							target.transform.position, this.ignoreHeightDistance);
					}
				}
				else if(BattleCameraDistanceOrigin.CameraControlTarget == this.distanceOrigin)
				{
					if(ORK.Control.CameraControlTarget != null)
					{
						found = true;
						distance = VectorHelper.Distance(
							ORK.Control.CameraControlTarget.transform.position,
							target.transform.position, this.ignoreHeightDistance);
					}
				}
				else if(BattleCameraDistanceOrigin.Player == this.distanceOrigin)
				{
					GameObject player = ORK.Game.GetPlayer();
					if(player != null)
					{
						found = true;
						distance = VectorHelper.Distance(player.transform.position,
							target.transform.position, this.ignoreHeightDistance);
					}
				}
				else if(BattleCameraDistanceOrigin.Arena == this.distanceOrigin)
				{
					if(ORK.Battle.BattleArena != null)
					{
						found = true;
						distance = VectorHelper.Distance(ORK.Battle.BattleArena.transform.position,
							target.transform.position, this.ignoreHeightDistance);
					}
				}

				return found &&
					(!this.useMinDistance || distance >= this.minDistance) &&
					(!this.useMaxDistance || distance <= this.maxDistance);
			}
			return true;
		}

		public bool CheckViewport(Camera camera, Transform target)
		{
			if(camera != null &&
				target != null &&
				this.useViewport)
			{
				Vector3 point = camera.WorldToViewportPoint(target.position);
				if(ORK.Control.IsCameraTargetTransition() &&
					ORK.Control.CameraControlTarget != null)
				{
					Vector3 point2 = camera.WorldToViewportPoint(ORK.Control.CameraControlTarget.transform.position);
					point.x -= (point2.x - 0.5f);
					point.y -= (point2.y - 0.5f);
				}
				point.x = Mathf.Abs(point.x - 0.5f);
				point.y = Mathf.Abs(point.y - 0.5f);

				if(point.x > this.horizontalViewport ||
					point.y > this.verticalViewport)
				{
					return true;
				}
				return false;
			}
			return true;
		}
	}
}
