﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CastTimeSettings : BaseData
	{
		[ORKEditorHelp("Use Cast Time", "This action will be casted before using.", "")]
		public bool useCastTime = false;

		[ORKEditorInfo(separator=true, labelText="Cast Time")]
		[ORKEditorLayout("useCastTime", true, autoInit=true)]
		public FloatValue castTimeValue;

		[ORKEditorHelp("Cancelable", "The action can be canceled while casting.\n" +
			"The action will only be canceled when the caster is attacked by an attack with cancel action option selected.", "")]
		[ORKEditorInfo(separator=true)]
		public bool cancelable = false;

		[ORKEditorHelp("Move While Casting", "The combatant can move while casting this action.\n" +
			"If disabled, the combatant can't move (like a status effect with 'Stop Movement').", "")]
		public bool castMove = false;


		// audio settings
		[ORKEditorHelp("Play Sound", "A sound will be played on the user when starting to cast this action.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public bool castPlaySound = false;

		[ORKEditorLayout("castPlaySound", true, endCheckGroup=true, autoInit=true)]
		public PlayAudioCombatant castAudioSettings;


		// event settings
		[ORKEditorHelp("Start Casting Event", "Select the game event asset used when a combatant starts casting.\n" +
			"The combatant will be used as starting object, " + 
			"the casted action is available as selected data via the key 'action'.", "")]
		[ORKEditorInfo(separator=true, labelText="Game Event Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=null)]
		public ORKGameEvent startCastingEvent;

		[ORKEditorHelp("Cancel Casting Event", "Select the game event asset used when a combatant cancels casting.\n" +
			"The combatant will be used as starting object, " +
			"the casted action is available as selected data via the key 'action'.", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=null)]
		public ORKGameEvent cancelCastingEvent;

		public CastTimeSettings()
		{

		}
		public void StartCastingEvent(Combatant combatant, SelectedDataHandler selectedData)
		{
			if(combatant != null &&
				this.useCastTime &&
				this.startCastingEvent != null)
			{
				if(combatant.GameObject != null)
				{
					combatant.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.startCastingEvent, combatant, selectedData, false, null);
				}
				else
				{
					ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.startCastingEvent, combatant, selectedData, false, null);
				}
			}
		}
		public void CancelCastingEvent(Combatant combatant, SelectedDataHandler selectedData)
		{
			if(combatant != null &&
				this.useCastTime &&
				this.cancelCastingEvent != null)
			{
				if(combatant.GameObject != null)
				{
					combatant.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.cancelCastingEvent, combatant, selectedData, false, null);
				}
				else
				{
					ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.cancelCastingEvent, combatant, selectedData, false, null);
				}
			}
		}
	}
}
