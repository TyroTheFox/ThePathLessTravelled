
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleAnimation : BaseData
	{
		[ORKEditorHelp("Battle Event", "Select the battle event that will be performed.", "")]
		public ORKBattleEvent evt;

		[ORKEditorHelp("Chance", "The chance this battle event will be performed.", "")]
		public float chance = 100;


		// system types
		[ORKEditorHelp("Field", "Available in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Perform In")]
		public bool field = false;

		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();


		// override prefabs
		[ORKEditorHelp("Set Prefabs", "Override the battle event's prefabs.\n" +
			"This allows you to replace prefabs used in the battle event's setup.", "")]
		[ORKEditorInfo(separator=true, labelText="Prefabs Settings")]
		public bool setPrefabs = false;

		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this animation.\n" +
			"The prefabs will override the battle animation's prefabs.\n" +
			"Keep in mind that you need to add prefabs in the battle event as well, " +
			"or you wont be able to select them in the event steps.", "",
			"Remove", "Removes this prefab from the event.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {"Prefab", "This prefab can be used in the event steps.", ""})]
		[ORKEditorLayout("setPrefabs", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public EventPrefab[] prefab;


		// override audio clips
		[ORKEditorHelp("Set Audio Clips", "Override the battle event's audio clips.\n" +
			"This allows you to replace audio clips used in the battle event's setup.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Clip Settings")]
		public bool setAudioClips = false;

		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this animation.\n" +
			"The audio clips will override the battle animation's audio clips.\n" +
			"Keep in mind that you need to add audio clips in the battle event as well, " +
			"or you wont be able to select them in the event steps.", "",
			"Remove", "Removes this audio clip from the event.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {"Audio Clip", "This audio clip can be used in the event steps.", ""})]
		[ORKEditorLayout("setAudioClips", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public EventAudio[] audioClip;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Requirements", "Performing a battle event can depend on status requirements and " +
			"game variable conditions.\n" +
			"If the requirements aren't met, the battle event wont be performed.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;

		public BattleAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<bool>("turnBased"))
			{
				this.battleSystemCheck.SetData(data);
			}
		}

		public void GetEvent(Combatant user, ref List<BattleEvent> list)
		{
			if(this.evt != null &&
				ORK.GameSettings.CheckRandom(this.chance) &&
				((!user.Battle.InBattle && this.field) ||
					(user.Battle.InBattle && this.battleSystemCheck.Check())) &&
				(!this.useRequirements || this.requirement.Check(user)))
			{
				BattleEvent be = new BattleEvent();
				be.SetData(this.evt.GetData().ToDataObject());

				if(this.setPrefabs)
				{
					be.SetPrefabs(this.prefab);
				}
				if(this.setAudioClips)
				{
					be.SetAudioClips(this.audioClip);
				}

				list.Add(be);
			}
		}
	}
}
