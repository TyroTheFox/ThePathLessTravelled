﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HexagonalGridHelper : IGridHelper
	{
		private bool isHorizontal = false;

		public HexagonalGridHelper(BattleSystemSettings settings)
		{
			this.isHorizontal = settings.gridSettings.IsHorizontalHex;
		}


		/*
		============================================================================
		Direction functions
		============================================================================
		*/
		public CubeCoord GetDirection(int direction)
		{
			if(direction < 0)
			{
				direction += (int)(Mathf.Ceil((-direction) / 6.0f)) * 6;
			}
			else if(direction > 5)
			{
				direction -= (int)(Mathf.Floor(direction / 6.0f)) * 6;
			}
			return BattleGridHelper.HexagonalDirections[direction];
		}

		public CubeCoord GetDirectionNonDiagonal(int direction)
		{
			if(direction < 0)
			{
				direction += (int)(Mathf.Ceil((-direction) / 6.0f)) * 6;
			}
			else if(direction > 5)
			{
				direction -= (int)(Mathf.Floor(direction / 6.0f)) * 6;
			}
			return BattleGridHelper.HexagonalDirections[direction];
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public int AngleToDirection(float angle, bool allowSquareDiagonal)
		{
			if(this.isHorizontal)
			{
				angle += 60.0f;
				ValueHelper.SecureRotation(ref angle);
				return (int)(angle / 60.0f);
			}
			else
			{
				angle += 30.0f;
				ValueHelper.SecureRotation(ref angle);
				return (int)(angle / 60.0f);
			}
		}

		public float DirectionToAngle(int direction, bool allowSquareDiagonal)
		{
			if(this.isHorizontal)
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction > 5)
				{
					direction -= 6;
				}
				float angle = direction * 60.0f;
				angle -= 30.0f;
				ValueHelper.SecureRotation(ref angle);
				return angle;
			}
			else
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction > 5)
				{
					direction -= 6;
				}
				float angle = direction * 60.0f;
				ValueHelper.SecureRotation(ref angle);
				return angle;
			}
		}


		/*
		============================================================================
		Neighbour functions
		============================================================================
		*/
		public float GetNeighbourAngle()
		{
			return 60.0f;
		}

		public float GetNeighbourAngleOffset()
		{
			if(this.isHorizontal)
			{
				return 0.0f;
			}
			else
			{
				return 30.0f;
			}
		}

		public BattleGridCellComponent GetNeighbourCell(BattleGridCellComponent cell, int index)
		{
			if(cell != null && index >= 0)
			{
				if(index < BattleGridHelper.HexagonalDirections.Length)
				{
					return cell.parentGrid.GetCell(
						cell.CubeCoord + BattleGridHelper.HexagonalDirections[index]);
				}
			}
			return cell;
		}

		public bool IsNeighbourCell(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null && cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, BattleGridHelper.HexagonalDirections[i]);
					BattleGridCellComponent tmpCell = origin.parentGrid.GetCell(coord);

					if(cell == tmpCell &&
						(check == null || check(cell)))
					{
						return true;
					}
				}
			}
			return false;
		}

		public void UsePathNeighbourCells(BattleGridCellComponent origin, UsePathCell useCell,
			bool allowSquareDiagonal, GridCellCheck check, GridCellCheck checkDiagonal)
		{
			CubeCoord coord = new CubeCoord();
			for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
			{
				coord.SetAdd(origin.CubeCoord, BattleGridHelper.HexagonalDirections[i]);
				BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

				if(cell != null &&
					cell.IsPassable &&
					(check == null || check(cell)))
				{
					useCell(cell, i);
				}
			}
		}

		public void UsePathNeighbourCells(BattleGridCellComponent origin,
			UsePathCell useCell, ref List<BattleGridCellComponent> blockedList,
			bool allowSquareDiagonal, bool blockedOccupied, GridCellCheck check, GridCellCheck checkDiagonal)
		{
			CubeCoord coord = new CubeCoord();
			for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
			{
				coord.SetAdd(origin.CubeCoord, BattleGridHelper.HexagonalDirections[i]);
				BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

				if(cell != null)
				{
					if(cell.IsPassable &&
						(check == null || check(cell)))
					{
						useCell(cell, i);
					}
					else if((blockedOccupied || cell.IsEmpty) && 
						!blockedList.Contains(cell))
					{
						blockedList.Add(cell);
					}
				}
			}
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public void GetRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					int max = Mathf.Max(-maxDistance, -dx - maxDistance);
					int min = Mathf.Min(maxDistance, -dx + maxDistance);

					for(int dy = max; dy <= min; dy++)
					{
						int dz = -dx - dy;
						int tmpDistance = CubeCoord.ZeroDistanceHexagonal(dx, dy, dz);
						if(tmpDistance >= minDistance &&
							tmpDistance <= maxDistance)
						{
							coord.SetAdd(origin.CubeCoord, dx, dy, dz);
							BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

							if(cell != null &&
								(addOrigin || origin != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)) &&
								!contains.Contains(cell))
							{
								list.Add(cell);
								contains.Add(cell);
							}
						}
					}
				}
			}
		}

		public void GetRange(Combatant user, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			if(user != null &&
				user.Grid.Cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					int max = Mathf.Max(-maxDistance, -dx - maxDistance);
					int min = Mathf.Min(maxDistance, -dx + maxDistance);

					for(int dy = max; dy <= min; dy++)
					{
						for(int i = 0; i < user.Grid.CellCount; i++)
						{
							BattleGridCellComponent origin = user.Grid.GetCell(i);
							if(origin != null)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, -dx - dy);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									user.Grid.InRange(cell, false, minDistance, maxDistance, check) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
							}
						}
					}
				}
			}
		}

		public void GetRangeCombatants(BattleGridCellComponent origin, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
		   bool allowSquareDiagonal, GridCellCheck check)
		{
			CubeCoord coord = new CubeCoord();
			for(int dx = -maxDistance; dx <= maxDistance; dx++)
			{
				int max = Mathf.Max(-maxDistance, -dx - maxDistance);
				int min = Mathf.Min(maxDistance, -dx + maxDistance);

				for(int dy = max; dy <= min; dy++)
				{
					int dz = -dx - dy;
					int tmpDistance = CubeCoord.ZeroDistanceHexagonal(dx, dy, dz);
					if(tmpDistance >= minDistance &&
						tmpDistance <= maxDistance)
					{
						coord.SetAdd(origin.CubeCoord, dx, dy, dz);
						BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

						if(cell != null &&
							!cell.IsEmpty &&
							(addOrigin || origin != cell) &&
							(addBlocked || !cell.IsBlocked) &&
							(addNotPassable || cell.IsPassable) &&
							(check == null || check(cell)))
						{
							cell.GetCombatants(ref list, null);
						}
					}
				}
			}
		}

		public void GetRangeCombatants(Combatant user, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			if(user != null &&
				   user.Grid.Cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					int max = Mathf.Max(-maxDistance, -dx - maxDistance);
					int min = Mathf.Min(maxDistance, -dx + maxDistance);

					for(int dy = max; dy <= min; dy++)
					{
						for(int i = 0; i < user.Grid.CellCount; i++)
						{
							BattleGridCellComponent origin = user.Grid.GetCell(i);
							if(origin != null)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, -dx - dy);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									!cell.IsEmpty &&
									user.Grid.InRange(cell, false, minDistance, maxDistance, check))
								{
									cell.GetCombatants(ref list, null);
								}
							}
						}
					}
				}
			}
		}

		public bool CheckRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					int max = Mathf.Max(-maxDistance, -dx - maxDistance);
					int min = Mathf.Min(maxDistance, -dx + maxDistance);

					for(int dy = max; dy <= min; dy++)
					{
						int dz = -dx - dy;
						int tmpDistance = CubeCoord.ZeroDistanceHexagonal(dx, dy, dz);
						if(tmpDistance >= minDistance &&
							tmpDistance <= maxDistance)
						{
							coord.SetAdd(origin.CubeCoord, dx, dy, dz);
							BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

							if(cell == null ||
								(!addOrigin && origin == cell) ||
								(!addBlocked && cell.IsBlocked) ||
								(!addNotPassable && !cell.IsPassable) ||
								(check != null && !check(cell)))
							{
								return false;
							}
						}
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Ring functions
		============================================================================
		*/
		public void GetRing(BattleGridCellComponent center, int radius,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					list.Add(center);
				}
				else
				{
					CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(4) * radius;

					for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
					{
						for(int j = 0; j < radius; j++)
						{
							BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
							if(cell != null &&
								(addOrigin || center != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)) &&
								!contains.Contains(cell))
							{
								list.Add(cell);
								contains.Add(cell);
							}
							coord.Add(BattleGridHelper.GetDirection(i));
						}
					}
				}
			}
		}

		public void GetRingCombatants(BattleGridCellComponent center, int radius,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					center.GetCombatants(ref list, null);
				}
				else
				{
					CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(4) * radius;

					for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
					{
						for(int j = 0; j < radius; j++)
						{
							BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
							if(cell != null &&
								!cell.IsEmpty &&
								(addOrigin || center != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)))
							{
								cell.GetCombatants(ref list, null);
							}
							coord.Add(BattleGridHelper.GetDirection(i));
						}
					}
				}
			}
		}

		public bool CheckRing(BattleGridCellComponent center, int radius,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					return true;
				}
				else
				{
					CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(4) * radius;

					for(int i = 0; i < BattleGridHelper.HexagonalDirections.Length; i++)
					{
						for(int j = 0; j < radius; j++)
						{
							BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
							if(cell == null ||
								(!addOrigin && center == cell) ||
								(!addBlocked && cell.IsBlocked) ||
								(!addNotPassable && !cell.IsPassable) ||
								(check != null && !check(cell)))
							{
								return false;
							}
							coord.Add(BattleGridHelper.GetDirection(i));
						}
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		public void GetLine(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool ignoreBlocked)
		{
			int distance = origin.CubeCoord.Distance(target.CubeCoord);
			for(int i = 0; i <= distance; i++)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(
					CubeCoord.Round(CubeCoord.Lerp(
						origin.CubeCoord, target.CubeCoord,
						1.0f / distance * i)));

				if(cell != null)
				{
					if(!ignoreBlocked && cell.IsBlocked)
					{
						return;
					}
					else if(!contains.Contains(cell))
					{
						list.Add(cell);
					}
				}
			}
		}


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		public bool CheckLineOfSight(Combatant user, BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			bool valid = true;
			if(origin != target)
			{
				int distance = origin.CubeCoord.Distance(target.CubeCoord);
				Vector3 targetV3 = target.CubeCoord.ToVector3();

				if(!this.CheckLineOfSightOffset(
					user, origin, target, blockLOS, distance, targetV3))
				{
					valid = false;
				}

				if(!valid && cellArea > 0)
				{
					valid = true;

					// X+
					if(!this.CheckLineOfSightOffset(
						user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(cellArea, 0, 0)) &&
						// X-
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(-cellArea, 0, 0)) &&
						// Y+
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, cellArea, 0)) &&
						// Y-
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, -cellArea, 0)) &&
						// Z+
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, 0, cellArea)) &&
						// Z-
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							distance, targetV3 + new Vector3(0, 0, -cellArea)))
					{
						valid = false;
					}
				}
			}
			return valid;
		}

		private bool CheckLineOfSightOffset(Combatant user,
			BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, int distance, Vector3 targetV3)
		{
			for(int i = 0; i <= distance; i++)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(
					CubeCoord.Round(CubeCoord.Lerp(
						origin.CubeCoord, targetV3,
						1.0f / distance * i)));

				if(cell != null &&
					cell != origin &&
					cell != target &&
					blockLOS != null &&
					blockLOS(user, origin, cell))
				{
					return false;
				}
			}
			return true;
		}


		/*
		============================================================================
		CubeCoord functions
		============================================================================
		*/
		public CubeCoord Rotate(CubeCoord origin, int turns)
		{
			if(turns >= 6 ||
				turns <= -6)
			{
				turns -= (turns / 6) * 6;
			}
			if(turns < 0)
			{
				turns += 6;
			}

			if(turns == 0)
			{
				return new CubeCoord(origin);
			}
			else if(turns == 1)
			{
				return new CubeCoord(-origin.z, -origin.x, -origin.y);
			}
			else if(turns == 2)
			{
				return new CubeCoord(origin.y, origin.z, origin.x);
			}
			else if(turns == 3)
			{
				return new CubeCoord(-origin.x, -origin.y, -origin.z);
			}
			else if(turns == 4)
			{
				return new CubeCoord(origin.z, origin.x, origin.y);
			}
			else if(turns == 5)
			{
				return new CubeCoord(-origin.y, -origin.z, -origin.x);
			}
			return new CubeCoord(origin);
		}

		public int Distance(CubeCoord origin, CubeCoord target)
		{
			return (Mathf.Abs(origin.x - target.x) +
				Mathf.Abs(origin.y - target.y) +
				Mathf.Abs(origin.z - target.z)) / 2;
		}

		public int Distance(CubeCoord origin, CubeCoord target, bool blockDiagonalDistance1)
		{
			return (Mathf.Abs(origin.x - target.x) +
				Mathf.Abs(origin.y - target.y) +
				Mathf.Abs(origin.z - target.z)) / 2;
		}
	}
}
