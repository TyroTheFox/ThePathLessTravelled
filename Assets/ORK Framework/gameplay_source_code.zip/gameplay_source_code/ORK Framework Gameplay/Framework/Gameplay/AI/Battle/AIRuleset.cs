﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleset : BaseLanguageData, IContent
	{
		// base settings
		[ORKEditorHelp("AI Type", "Select the AI type of this AI ruleset.", "")]
		[ORKEditorInfo("Base Settings", "Define the base settings of this AI ruleset.", "",
			ORKDataType.AIType)]
		public int typeID = 0;

		[ORKEditorHelp("Use Quantity", "This AI ruleset uses quantity mechanics.\n" +
			"I.e. it can be collected multiple times and each unit " +
			"will be unavailable while being equipped on an AI ruleset slot.\n" +
			"If disabled, the AI ruleset can only be collected once and " +
			"equipping it on a slot doesn't make it unavailable for other combatants/slots.", "")]
		public bool useQuantity = false;

		// prefab
		[ORKEditorHelp("Item Prefab", "The prefab spawned by the item collector when collecting this AI ruleset.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject prefab;

		[ORKEditorHelp("Spawn Offset", "Offset added to the game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		// sympathy
		[ORKEditorHelp("Sympathy Change", "Additional to the faction's take item sympathy change, this value will be added to the change.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo(separator=true)]
		public float sympathyChange = 0;

		// chance
		[ORKEditorInfo("Chance (%)", "The chance this AI ruleset will be used.", "",
			endFoldout=true, endFolds=2)]
		public FloatValue chanceValue = new FloatValue(100);


		// sale settings
		[ORKEditorInfo("Price Settings", "Set the prices for buying and selling this AI ruleset.", "",
			endFoldout=true)]
		public PriceSettings price = new PriceSettings();


		// move AI
		[ORKEditorHelp("Change On Use", "Only change the move AI when an action of this AI ruleset is used.", "")]
		[ORKEditorInfo("Move AI Settings", "Equipping this AI ruleset can influence the move AI of the combatant.", "")]
		public bool moveAIChangeOnUse = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		public MoveAIChange moveAIChange = new MoveAIChange();


		// equip requirements
		[ORKEditorHelp("Single Equip", "A combatant can only equip one AI ruleset of this kind.\n" +
			"If disabled, a combatant can equip this AI ruleset multiple times on different slots.", "")]
		[ORKEditorInfo("Equip Requirements", "Equipping this AI ruleset on an AI ruleset slot " +
			"can depend on status requirements and game variable conditions.\n" +
			"The combatant equipping the AI ruleset is used for status checks and object game variables.", "")]
		public bool singleEquip = true;

		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to determine if this AI ruleset can be equipped.", "")]
		public bool useEquipRequirements = false;

		[ORKEditorHelp("Auto Unequip", "Automatically unequip this AI ruleset when the equip requirements are no longer valid.", "")]
		[ORKEditorLayout("useEquipRequirements", true)]
		public bool autoUnequip = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement equipRequirement;


		// user requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to determine if this AI ruleset can be used.", "")]
		[ORKEditorInfo("User Requirements", "Using this AI ruleset can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the AI ruleset is used for status checks and object game variables.", "")]
		public bool useUserRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useUserRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement userRequirement;


		// notifications
		[ORKEditorHelp("Own Notifications", "This AI ruleset overrides the default item notifications.", "")]
		[ORKEditorInfo("Notification Settings", "AI rulesets can override the default item notifications.", "")]
		public bool ownNotifications = false;

		[ORKEditorInfo("AI Ruleset Added", "This notification will be displayed " +
			"when this AI ruleset is added to the player.", "", endFoldout=true)]
		[ORKEditorLayout("ownNotifications", true, autoInit=true)]
		public AINotification addedNotification;

		[ORKEditorInfo("AI Ruleset Removed", "This notification will be displayed " +
			"when this AI ruleset is removed from the player.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public AINotification removedNotification;


		// console texts
		[ORKEditorHelp("Own Add Text", "This AI ruleset overrides the default console add text.", "")]
		[ORKEditorInfo("Console Texts", "An AI ruleset can override the default console texts.", "")]
		public bool ownConsoleAdd = false;

		[ORKEditorInfo("Add Text", "The text displayed for adding this AI ruleset to the player.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleAdd", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAI consoleAdd;

		[ORKEditorHelp("Own Remove Text", "This AI ruleset overrides the default console remove text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleRemove = false;

		[ORKEditorInfo("Remove Text", "The text displayed for removing this AI ruleset from the player.", "", endFoldout=true, endFolds=2)]
		[ORKEditorLayout("ownConsoleRemove", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAI consoleRemove;


		// portraits
		[ORKEditorInfo("Portraits", "The AI ruleset can display a portrait in menus when it's selected.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Portrait", "Adds a portrait.", "",
			"Remove", "Removes this portrait.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Portrait", "Define the portrait that will be used.", ""
			})]
		public TypePrefabViewPortrait[] portrait = new TypePrefabViewPortrait[0];


		// rules
		[ORKEditorArray(false, "Add Rule", "Adds a rule to this AI ruleset.\n" +
			"The rules will be used in the order they're added (i.e. starting with 'Rule 0').", "",
			"Remove", "Removes this rule.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Rule", "Define the rule.", ""
			})]
		public AIRule[] rule = new AIRule[0];

		public AIRuleset()
		{

		}

		public AIRuleset(string name) : base(name)
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("usePortrait"))
			{
				this.portrait = TypePrefabViewPortrait.UpgradeData(data, "usePortrait", "portrait");
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject GetPrefabInstance()
		{
			if(this.prefab != null)
			{
				return UnityWrapper.Instantiate(this.prefab);
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CanEquip(Combatant user)
		{
			return (!this.singleEquip || !user.AI.IsAIRulesetEquipped(this.ID)) &&
				(!this.useEquipRequirements || this.equipRequirement.Check(user));
		}

		public bool CheckRequirements(Combatant user)
		{
			return ORK.GameSettings.CheckRandom(this.chanceValue.GetValue(user, user)) &&
				(!this.useUserRequirements || this.userRequirement.Check(user));
		}

		public bool CheckTargetRequirements(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			// target rule requirement
			for(int i = 0; i < this.rule.Length; i++)
			{
				if(AIRuleType.Target == this.rule[i].type &&
					this.rule[i].target.useTargetRequirements &&
					this.rule[i].target.isUseRequirement &&
					!this.rule[i].target.CheckRequirements(user, allies, enemies))
				{
					return false;
				}
			}
			return true;
		}


		/*
		============================================================================
		Ruleset functions
		============================================================================
		*/
		public BaseAction GetAction(BattleAICall call)
		{
			BaseAction action = null;
			if(this.CheckRequirements(call.user) &&
				this.CheckTargetRequirements(call.user, call.allies, call.enemies))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Action == this.rule[i].type)
					{
						action = this.rule[i].action.GetAction(call.user);
						// check AI blocks
						if(!call.user.AI.CanUseAction(action))
						{
							action = null;
						}
						else if(action != null)
						{
							call.user.AI.SetActionTargets(action, call.user.Battle.LastTargets, call.allies, call.enemies);
							break;
						}
					}
					else if(AIRuleType.BattleAI == this.rule[i].type)
					{
						for(int j = 0; j < this.rule[i].battleAI.battleAI.Length; j++)
						{
							action = this.rule[i].battleAI.battleAI[j].GetAction(call);
							// check AI blocks
							if(!call.user.AI.CanUseAction(action))
							{
								action = null;
							}
							if(action != null)
							{
								break;
							}
						}
					}
				}
			}

			// action move AI and target changes
			if(action != null)
			{
				// target rule binding
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Target == this.rule[i].type &&
						this.rule[i].target.bindToRuleset)
					{
						if(this.rule[i].target.SetActionTargets(action, call.user, call.allies, call.enemies))
						{
							break;
						}
					}
				}

				// move AI changes
				if(this.moveAIChangeOnUse)
				{
					this.moveAIChange.Change(call.user);
				}
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.MoveAI == this.rule[i].type &&
						this.rule[i].moveAI.moveAIChangeOnUse)
					{
						if(this.rule[i].moveAI.moveAIChange.Change(call.user))
						{
							break;
						}
					}
				}
			}

			return action;
		}

		public bool ChangeMoveAI(Combatant user)
		{
			if(this.CheckRequirements(user))
			{
				if(!this.moveAIChangeOnUse &&
					this.moveAIChange.Change(user))
				{
					return true;
				}

				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.MoveAI == this.rule[i].type &&
						!this.rule[i].moveAI.moveAIChangeOnUse &&
						this.rule[i].moveAI.moveAIChange.Change(user))
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool SetActionTargets(BaseAction action, Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Target == this.rule[i].type &&
						!this.rule[i].target.bindToRuleset)
					{
						if(this.rule[i].target.SetActionTargets(action, user, allies, enemies))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool CanUseAbility(Combatant user, int abilityID)
		{
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockAbility == this.rule[i].type &&
						!this.rule[i].blockAbility.CanUse(abilityID))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseAttack(Combatant user)
		{
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockAttack == this.rule[i].type)
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseCounterAttack(Combatant user)
		{
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockCounterAttack == this.rule[i].type)
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseItem(Combatant user, int itemID)
		{
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockItem == this.rule[i].type &&
						!this.rule[i].blockItem.CanUse(itemID))
					{
						return false;
					}
				}
			}
			return true;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public int TypeID
		{
			get { return this.typeID; }
		}

		public int ItemTypeID
		{
			get { return ORK.AITypes.Get(this.typeID).itemTypeID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return TextCode.AIRulesetIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return ORK.AITypes.Get(this.typeID);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}

		public IPortrait GetPortrait(int typeID)
		{
			TypePrefabViewPortrait found = TypePrefabViewPortrait.GetPortrait(typeID, this.portrait);
			if(found != null &&
				found.CanSetPrefab)
			{
				found.SetPrefab(this.prefab);
			}
			return found;
		}
	}
}
