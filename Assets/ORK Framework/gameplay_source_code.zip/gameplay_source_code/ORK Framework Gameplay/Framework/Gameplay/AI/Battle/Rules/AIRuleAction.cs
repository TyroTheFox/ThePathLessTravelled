﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleAction : BaseData
	{
		public ActionSelection actionSettings = new ActionSelection();

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		// TODO: target settings, e.g. use requirements?

		public AIRuleAction()
		{

		}

		public BaseAction GetAction(Combatant combatant)
		{
			return this.actionSettings.GetAction(combatant, false, true, this.blockBattleCamera);
		}
	}
}
