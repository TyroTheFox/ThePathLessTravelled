
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKNodeInfo("Base")]
	public class RandomStep : BaseAIStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};

		public RandomStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.random[UnityWrapper.Range(0, this.random.Length)];
			return null;
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}

		public override int GetNextCount()
		{
			return this.random.Length;
		}

		public override int GetNext(int index)
		{
			return this.random[index];
		}

		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}

	[ORKEditorHelp("Battle AI", "Executes another battle AI to find a battle action.\n" +
		"If no action is found, 'Next' will be executed.\n" +
		"Keep in mind that using the same battle AI can result in a loop and will ultimately crash the game.", "")]
	[ORKNodeInfo("Base")]
	public class BattleAIStep : BaseAIStep
	{
		[ORKEditorHelp("Battle AI", "Select the battle AI that will be executed.", "")]
		[ORKEditorInfo(ORKDataType.BattleAI)]
		public int id = 0;

		public BattleAIStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.next;
			if(this.id >= 0 && this.id < ORK.BattleAIs.Count)
			{
				return ORK.BattleAIs.Get(this.id).GetAction(call);
			}
			else
			{
				return null;
			}
		}
	}

	[ORKEditorHelp("Comment", "Leave a comment in your battle AI.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKNodeInfo("Base")]
	public class CommentStep : BaseAIStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";

		public CommentStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}

	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). When using a formula, the user of the battle AI is used as user and target.\n" +
		"If the random number is less or equal to the defined chance, 'Success' is executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class CheckChanceStep : BaseAICheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public AIFloat chance = new AIFloat();

		public CheckChanceStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(call, call.user, call.user)))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}

	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). " +
		"When using a formula, the user of the battle AI is used as user and target.\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class ChanceForkStep : BaseAIStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "",
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceAINextNode[] range = new ChanceAINextNode[] {new ChanceAINextNode()};

		public ChanceForkStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.next;

			float chance = ORK.GameSettings.GetRandom();

			for(int i = 0; i < this.range.Length; i++)
			{
				if(this.range[i].Contains(call, chance, call.user, call.user))
				{
					currentStep = this.range[i].next;
					break;
				}
			}

			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " +
					this.range[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Check Difficulty", "Checks the game's currently selected difficulty.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class CheckDifficultyStep : BaseAICheckStep
	{
		public DifficultyCheck difficultyCheck = new DifficultyCheck();

		public CheckDifficultyStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.difficultyCheck.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.difficultyCheck.Check())
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.difficultyCheck.ToString();
		}
	}
}
