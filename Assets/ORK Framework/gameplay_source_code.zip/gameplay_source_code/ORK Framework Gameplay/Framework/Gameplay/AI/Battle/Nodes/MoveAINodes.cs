﻿
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Change Move AI", "Changes the move AI of the user.", "")]
	[ORKNodeInfo("Move AI")]
	public class ChangeMoveAIStep : BaseAIStep
	{
		[ORKEditorHelp("Restore Move AI", "Restore the move AI to the one originally used by the combatant.", "")]
		public bool restore = false;

		[ORKEditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[ORKEditorInfo(ORKDataType.MoveAI)]
		[ORKEditorLayout("restore", false, endCheckGroup=true)]
		public int moveID = 0;

		public ChangeMoveAIStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.ChangeMoveAI(this.restore ?
					call.user.Object.MoveAI.originalMoveID : this.moveID);
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : ORK.MoveAIs.GetName(this.moveID);
		}
	}

	[ORKEditorHelp("Change Move AI Mode", "Changes the use mode of the user's move AI.", "")]
	[ORKNodeInfo("Move AI")]
	public class ChangeMoveAIModeStep : BaseAIStep
	{
		[ORKEditorHelp("Restore Default", "Restore the default use mode of the move AI (defined in the settings).", "")]
		public bool restore = false;

		[ORKEditorHelp("Use Mode", "Select the use mode of the move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.", "")]
		[ORKEditorLayout("restore", false, endCheckGroup=true)]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public ChangeMoveAIModeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.useMode = this.restore ?
					call.user.Object.MoveAI.settings.useMode : this.useMode;
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.useMode.ToString();
		}
	}

	[ORKEditorHelp("Check Move AI Detection", "Checks if the targets are detected by the combatant's move AI detection.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Move AI", "Check")]
	public class CheckMoveAIDetectionStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIDetectionStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null && 
				user.Object.MoveAI.settings.useDetection)
			{
				// check for status requirements
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.Detect(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
	}

	[ORKEditorHelp("Check Move AI Hunting", "Checks if the targets are valid for hunting due to the " +
		"combatant's move AI hunting conditions. " +
		"The combatant needs to be aggressive in order to hunt targets.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Move AI", "Check")]
	public class CheckMoveAIHuntingStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIHuntingStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null && 
				user.Object.MoveAI.settings.hunting.enabled)
			{
				// check for status requirements
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.hunting.IsHunting(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
	}

	[ORKEditorHelp("Check Move AI Flee", "Checks if the targets are valid for fleeing due to the " +
		"combatant's move AI flee conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Move AI", "Check")]
	public class CheckMoveAIFleeStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIFleeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null && 
				user.Object.MoveAI.settings.flee.enabled)
			{
				// check for status requirements
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.flee.IsFlee(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
	}

	[ORKEditorHelp("Check Move AI Caution", "Checks if the targets are valid for being cautious due to the " +
		"combatant's move AI caution conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Move AI", "Check")]
	public class CheckMoveAICautionStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAICautionStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null && 
				user.Object.MoveAI.settings.caution.enabled)
			{
				// check for status requirements
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.caution.IsCautious(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
	}

	[ORKEditorHelp("Check Move AI Target", "Checks if the targets are the current target of the combatant's move AI.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Move AI", "Check")]
	public class CheckMoveAITargetStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAITargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null && 
				user.Object.MoveAI.settings.useDetection)
			{
				// check for status requirements
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.IsTarget(list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}
	}
}
