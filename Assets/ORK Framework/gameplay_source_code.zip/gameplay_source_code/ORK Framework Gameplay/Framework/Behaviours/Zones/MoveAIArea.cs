﻿
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Move AI Area")]
	public class MoveAIArea : BaseColliderZone
	{
		public bool allowMoveAI = false;

		public bool usedInField = true;

		public bool usedInBattle = true;

		void Start()
		{
			this.gameObject.layer = 2;
			if(this.GetComponent<Collider>() == null &&
				this.GetComponent<Collider2D>() == null)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddMoveAIArea(this);
			}
		}
	}
}
