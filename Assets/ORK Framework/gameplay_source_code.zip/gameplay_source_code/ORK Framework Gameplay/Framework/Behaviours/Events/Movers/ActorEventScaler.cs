
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ActorEventScaler : MonoBehaviour
	{
		private Transform actor;
	
		private float time;

		private float time2;
	
		private Function interpolate;

		private Vector3 startScale;

		private Vector3 scaleDistance;

		private bool scale = false;
	
		private Vector3 direction = Vector3.zero;
	
		public void StopMoving()
		{
			this.actor = null;
			this.scale = false;
			this.interpolate = null;
		}
		
		
		/*
		============================================================================
		Scale functions
		============================================================================
		*/
		public void Scale(Transform a, float t, Vector3 s, EaseType et)
		{
			this.StopMoving();
		
			this.actor = a;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			this.scaleDistance = s - this.actor.localScale;
			this.startScale = this.actor.localScale;
			
			this.scale = true;
		}
	
	
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void Update()
		{
			if(!ORK.Game.Paused)
			{
				if(this.scale)
				{
					this.time += ORK.Game.DeltaTime;
					this.actor.localScale = Interpolate.Ease(this.interpolate, this.startScale, this.scaleDistance, this.time, this.time2);
					if(this.time >= this.time2)
					{
						this.scale = false;
					}
				}
			}
		}
	}
}
