
using UnityEngine;
using System.Collections;
using ORKFramework;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class InteractionForwarder : BaseInteraction
	{
		public BaseInteraction baseInteraction;

		public override InteractionType Type
		{
			get
			{
				if(this.baseInteraction != null)
				{
					return this.baseInteraction.Type;
				}
				else
				{
					return InteractionType.Any;
				}
			}
		}

		public override bool CanInteract(EventStartType type, GameObject gameObject)
		{
			if(this.baseInteraction != null)
			{
				return this.baseInteraction.CanInteract(type, gameObject);
			}
			return false;
		}

		public override bool Interact()
		{
			if(this.baseInteraction != null)
			{
				return this.baseInteraction.ForwardInteract();
			}
			return false;
		}

		public override void TouchInteract()
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardTouchInteract();
			}
		}

		public override bool DropInteract(DragInfo drag)
		{
			if(this.baseInteraction != null)
			{
				return this.baseInteraction.ForwardDropInteract(drag);
			}
			return false;
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerEnter(other);
			}
		}

		void OnTriggerExit(Collider other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerExit(other);
			}
		}

		void OnTriggerStay(Collider other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerStay(other);
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerEnter2D(other);
			}
		}

		void OnTriggerExit2D(Collider2D other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerExit2D(other);
			}
		}

		void OnTriggerStay2D(Collider2D other)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnTriggerStay2D(other);
			}
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		void OnCollisionEnter(Collision collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionEnter(collision);
			}
		}

		void OnCollisionExit(Collision collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionExit(collision);
			}
		}

		void OnCollisionStay(Collision collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionStay(collision);
			}
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		void OnCollisionEnter2D(Collision2D collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionEnter2D(collision);
			}
		}

		void OnCollisionExit2D(Collision2D collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionExit2D(collision);
			}
		}

		void OnCollisionStay2D(Collision2D collision)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.ForwardOnCollisionStay2D(collision);
			}
		}


		/*
		============================================================================
		UI functions
		============================================================================
		*/
		public override void UIStart()
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.UIStart();
			}
		}

		public override void UIStart(GameObject startingObject)
		{
			if(this.baseInteraction != null)
			{
				this.baseInteraction.UIStart(startingObject);
			}
		}
	}
}