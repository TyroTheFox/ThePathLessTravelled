
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/ORK Game Starter")]
	public class GameStarter : MonoBehaviour
	{
		public ORKProjectAsset project;
		
		
		// call main menu
		public bool callMainMenu = false;
		
		public float callAfter = 0;
		
		
		// start game
		public bool startGame = false;
	
		void Awake()
		{
			if(!ORK.Initialized)
			{
				if(this.project != null)
				{
					ORK.Initialize(this.project);
				}
				else
				{
					Debug.LogError("You must select an ORK Project Asset!");
				}
				
				if(!ORK.Game.Running)
				{
					if(this.callMainMenu)
					{
						this.StartCoroutine(this.CallMainMenu());
					}
					else if(this.startGame)
					{
						ORK.Game.NewGame(false);
					}
				}
			}
		}
		
		private IEnumerator CallMainMenu()
		{
			if(this.callAfter > 0)
			{
				yield return new WaitForSeconds(this.callAfter);
			}
			ORK.MainMenu.menu.Show();
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "GameStarter.psd");
		}
	}
}
