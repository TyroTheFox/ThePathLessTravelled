
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Scene Object")]
	public class SceneObjectComponent : MonoBehaviour, IContent
	{
		[ORKEditorInfo(ORKDataType.SceneObject)]
		public int sceneObjectID = 0;

		public CustomTextCode[] customTextCode = new CustomTextCode[0];


		// variable conditions
		public bool autoDestroy = true;

		public bool repeatDestroy = false;

		public float destroyCheckTime = 1;

		public bool checkObjectVariables = false;

		public VariableCondition variableCondition = new VariableCondition();


		// quest conditions
		public QuestCondition questCondition = new QuestCondition();


		// ingame
		protected SceneObject sceneObject;

		protected SceneObjectTypeWrapper sceneObjectType;

		protected bool isInvoking = false;

		protected bool cursorChanged = false;

		public IContent GetSceneObject()
		{
			if(this.CheckConditions())
			{
				return this;
			}
			else
			{
				return null;
			}
		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				this.sceneObject = ORK.SceneObjects.Get(this.sceneObjectID);
				this.sceneObjectType = new SceneObjectTypeWrapper(
					ORK.SceneObjectTypes.Get(this.sceneObject.typeID), this);
				if(this.sceneObject.useObjectVariables)
				{
					this.sceneObject.objectVariables.AddComponent(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public bool CheckConditions()
		{
			return this.CheckVariables() && this.questCondition.Check();
		}

		public bool CheckVariables()
		{
			if(this.checkObjectVariables)
			{
				ObjectVariablesComponent comp = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				if(comp != null)
				{
					return this.variableCondition.CheckVariables(comp.GetHandler());
				}
			}
			else
			{
				return this.variableCondition.CheckVariables();
			}
			return false;
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public void CursorEnter()
		{
			if(this.CheckConditions())
			{
				this.cursorChanged = ORK.Control.Cursor.ShowCustomCursor(this.sceneObject.Cursor);
			}
		}

		public void CursorExit()
		{
			if(this.cursorChanged)
			{
				this.cursorChanged = false;
				ORK.Control.Cursor.RemoveCustomCursor(this.sceneObject.Cursor);
			}
		}


		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		protected bool CheckAutoDestroy()
		{
			if(this.autoDestroy)
			{
				if(!this.CheckConditions())
				{
					UnityWrapper.Destroy(this.gameObject);
					return true;
				}
				else if(this.repeatDestroy && !this.isInvoking)
				{
					this.isInvoking = true;
					this.InvokeRepeating("AutoDestroy", this.destroyCheckTime, this.destroyCheckTime);
				}
			}
			return false;
		}

		protected void AutoDestroy()
		{
			if(this.CheckAutoDestroy())
			{
				UnityWrapper.Destroy(this.gameObject);
				this.CancelInvoke("AutoDestroy");
				this.isInvoking = false;
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "SceneObject.psd");
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public string ReplaceCustomTextCodes(string text)
		{
			for(int i = 0; i < this.customTextCode.Length; i++)
			{
				text = this.customTextCode[i].Replace(text);
			}
			return text;
		}

		public int ID
		{
			get { return this.sceneObject.ID; }
		}

		public int TypeID
		{
			get { return this.sceneObject.TypeID; }
		}

		public IContentSimple GetTypeContent()
		{
			return this.sceneObjectType;
		}

		public string GetName()
		{
			if(this.sceneObject.useObjectVariableTextCodes)
			{
				ObjectVariablesComponent objVariables = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				return TextHelper.ReplaceSpecials(
					this.ReplaceCustomTextCodes(this.sceneObject.GetName()),
					objVariables != null ? objVariables.GetHandler() : null);
			}
			else
			{
				return this.ReplaceCustomTextCodes(this.sceneObject.GetName());
			}
		}

		public string GetDescription()
		{
			if(this.sceneObject.useObjectVariableTextCodes)
			{
				ObjectVariablesComponent objVariables = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				return TextHelper.ReplaceSpecials(
					this.ReplaceCustomTextCodes(this.sceneObject.GetDescription()),
					objVariables != null ? objVariables.GetHandler() : null);
			}
			else
			{
				return this.ReplaceCustomTextCodes(this.sceneObject.GetDescription());
			}
		}

		public string GetIconTextCode()
		{
			return this.sceneObject.GetIconTextCode();
		}

		public Texture GetIcon()
		{
			return this.sceneObject.GetIcon();
		}

		public GUIContent GetContent()
		{
			GUIContent content = this.sceneObject.GetContent();
			content.text = this.ReplaceCustomTextCodes(content.text);
			if(this.sceneObject.useObjectVariableTextCodes)
			{
				ObjectVariablesComponent objVariables = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				content.text = TextHelper.ReplaceSpecials(content.text,
					objVariables != null ? objVariables.GetHandler() : null);
			}
			return content;
		}

		public string GetInfo(Combatant c)
		{
			return this.sceneObject.GetInfo(c);
		}
	}
}
