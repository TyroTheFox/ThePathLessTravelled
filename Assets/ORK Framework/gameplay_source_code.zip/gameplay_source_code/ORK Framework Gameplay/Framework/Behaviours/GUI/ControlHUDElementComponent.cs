
using UnityEngine;
using ORKFramework;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class ControlHUDElementComponent : MonoBehaviour
	{
		private RectTransform button;

		private RectTransform pressedButton;

		private HUDControl setting;

		public void Init(RectTransform button, RectTransform pressedButton, HUDControl setting)
		{
			this.button = button;
			this.pressedButton = pressedButton;
			this.setting = setting;
		}

		void Update()
		{
			if(this.setting.IsPressed && this.setting.usePressed &&
				this.pressedButton != null)
			{
				// activate pressed button
				if(!this.pressedButton.gameObject.activeInHierarchy)
				{
					this.pressedButton.gameObject.SetActive(true);
					if(this.button != null)
					{
						this.button.gameObject.SetActive(false);
					}
				}
				// update position (only axis/joystick)
				if(HUDControlType.Axis == this.setting.type ||
					HUDControlType.Joystick == this.setting.type)
				{
					this.pressedButton.anchoredPosition = new Vector2(
						this.setting.PositionOffset.x + this.setting.pImgBounds.x + this.setting.axisCenter.x,
						-(this.setting.PositionOffset.y + this.setting.pImgBounds.y + this.setting.axisCenter.y));
				}
			}
			else if(this.button != null)
			{
				// activate button
				if(!this.button.gameObject.activeInHierarchy)
				{
					this.button.gameObject.SetActive(true);
					if(this.pressedButton != null)
					{
						this.pressedButton.gameObject.SetActive(false);
					}
				}
				// update position (only axis/joystick)
				if(HUDControlType.Axis == this.setting.type ||
					HUDControlType.Joystick == this.setting.type)
				{
					this.button.anchoredPosition = new Vector2(
						this.setting.PositionOffset.x + this.setting.imgBounds.x + this.setting.axisCenter.x,
						-(this.setting.PositionOffset.y + this.setting.imgBounds.y + this.setting.axisCenter.y));
				}
			}
		}
	}
}
