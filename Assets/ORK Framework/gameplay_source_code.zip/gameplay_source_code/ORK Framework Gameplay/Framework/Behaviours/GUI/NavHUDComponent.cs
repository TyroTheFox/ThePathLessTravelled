
using UnityEngine;
using ORKFramework;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class NavHUDComponent : MonoBehaviour
	{
		private Dictionary<NavigationHUDContent, MultiNavigationHUDContent> hudContent = 
			new Dictionary<NavigationHUDContent, MultiNavigationHUDContent>();
		
		public bool HasHUDContent(NavigationHUDContent navHUD)
		{
			return this.hudContent.ContainsKey(navHUD);
		}
		
		public void SetHUDContent(NavigationHUDContent navHUD, MultiNavigationHUDContent content)
		{
			if(this.hudContent.ContainsKey(navHUD))
			{
				this.hudContent[navHUD] = content;
			}
			else
			{
				this.hudContent.Add(navHUD, content);
			}
		}
		
		public MultiNavigationHUDContent GetHUDContent(NavigationHUDContent navHUD)
		{
			if(this.hudContent.ContainsKey(navHUD))
			{
				return this.hudContent[navHUD];
			}
			return null;
		}
	}
}
