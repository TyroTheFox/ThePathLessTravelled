
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/No Camera Control")]
	public class NoCameraControl : MonoBehaviour
	{
	
	}
}
