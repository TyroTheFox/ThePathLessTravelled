
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Interaction Controller")]
	public class InteractionController : MonoBehaviour
	{
		public bool interactWithNearest = false;

		public bool nearestIgnoreHeightDistance = false;

		public Vector3 nearestOffset = Vector3.zero;


		// in-game
		protected bool interacting = false;

		protected List<BaseInteraction> list = new List<BaseInteraction>();

		protected List<BaseInteraction> triggerList = new List<BaseInteraction>();

		protected InteractionDistanceSorter sorter;

		protected Vector3 lastPosition;

		protected virtual void Start()
		{
			this.sorter = new InteractionDistanceSorter(this);
			this.lastPosition = this.transform.position;
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public virtual void SortInteractions()
		{
			if(this.interactWithNearest &&
				this.list.Count > 1)
			{
				this.lastPosition = this.transform.position;
				this.sorter.UpdatePosition();
				this.list.Sort(this.sorter);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool InteractionAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			for(int i = 0; i < this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled &&
					this.list[i].CanInteract(EventStartType.Interact, player) &&
					(InteractionType.Any == type ||
						(type == this.list[i].Type &&
						(customType == "" || this.list[i].customType == customType))))
				{
					return true;
				}
			}
			return false;
		}

		public virtual BaseInteraction GetFirstAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			this.SortInteractions();
			for(int i = 0; i < this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled &&
					this.list[i].CanInteract(EventStartType.Interact, player) &&
					(InteractionType.Any == type ||
						(type == this.list[i].Type &&
						(customType == "" || this.list[i].customType == customType))))
				{
					return this.list[i];
				}
			}
			return null;
		}

		public virtual int AvailableCount
		{
			get
			{
				int count = 0;
				GameObject player = ORK.Game.GetPlayer();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(EventStartType.Interact, player))
					{
						count++;
					}
				}
				return count;
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType &&
					!this.list.Contains(this.triggerList[i]))
				{
					this.list.Add(this.triggerList[i]);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType)
				{
					this.list.Remove(this.triggerList[i]);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType &&
					!this.list.Contains(this.triggerList[i]))
				{
					this.list.Add(this.triggerList[i]);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType)
				{
					this.list.Remove(this.triggerList[i]);
				}
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual bool Interact()
		{
			if(!this.interacting && ORK.Control.CanInteract)
			{
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled)
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public virtual bool Interact(InteractionType type, string customType)
		{
			if(!this.interacting &&
				ORK.Control.CanInteract)
			{
				GameObject player = ORK.Game.GetPlayer();
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(EventStartType.Interact, player) &&
						(InteractionType.Any == type ||
							(type == this.list[i].Type &&
							(customType == "" || this.list[i].customType == customType))))
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		protected virtual IEnumerator BlockInteraction()
		{
			this.interacting = true;
			yield return null;
			this.interacting = false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "InteractionController.psd");
		}

		protected virtual void OnDrawGizmosSelected()
		{
			if(this.interactWithNearest)
			{
				Gizmos.color = Color.green;
				Gizmos.DrawWireCube(
					this.transform.TransformPoint(this.nearestOffset),
					new Vector3(0.05f, 0.05f, 0.05f));
			}
		}
	}
}