
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Touch Camera")]
	public class TouchCamera : BaseCameraControl
	{
		public string onChild = "";

		public float distance = 10.0f;

		public float minHeight = 5.0f;

		private float startHeight = 5.0f;

		public float height = 5.0f;

		public float maxHeight = 30.0f;

		public float heightDamping = 2.0f;


		// rotation
		public bool allowRotation = true;

		public bool rememberRotation = false;

		private float startRotation = 0;

		public float rotation = 0;

		public float rotationDamping = 3.0f;

		public float rotationFactor = 1;

		public bool cameraTargetChangeResetRotation = false;

		public bool cameraTargetChangeBlockRotation = false;


		// zoom
		public bool allowZoom = true;

		public bool rememberZoom = false;

		public float zoomFactor = 1;

		public AxisControl zoomAxis = new AxisControl();

		public float zoomKeyChange = 3;

		public bool cameraTargetChangeResetZoom = false;

		public bool cameraTargetChangeBlockZoom = false;

		public bool limitChange = true;

		public MouseTouchControl mouseTouch = new MouseTouchControl(false, 1, true, 2, 1, MouseTouch.Move);


		// in-game
		private float lastTargetRotation = 0;

		private float lastTargetHeight = 0;

		void Start()
		{
			this.lastTargetRotation = this.transform.eulerAngles.y;
			this.lastTargetHeight = this.transform.position.y;
			this.startRotation = this.rotation;
			this.startHeight = this.height;

			if(this.rememberRotation &&
				this.AllowRotation)
			{
				ORK.GameControls.cameraControl.mouseControl.GetStoredRotation(
					ref this.rotation, ref this.lastTargetRotation);
			}
			if(this.rememberZoom &&
				this.AllowZoom)
			{
				ORK.GameControls.cameraControl.mouseControl.GetStoredZoom(
					ref this.height, ref this.lastTargetRotation);
			}
		}

		protected void OnDestroy()
		{
			if(this.rememberRotation &&
				this.AllowRotation)
			{
				ORK.GameControls.cameraControl.mouseControl.StoreRotation(
					this.rotation, this.lastTargetRotation);
			}
			if(this.rememberZoom &&
				this.AllowZoom)
			{
				ORK.GameControls.cameraControl.mouseControl.StoreZoom(
					this.height, this.lastTargetRotation);
			}
		}

		public override void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{
			if(this.cameraTargetChangeResetRotation)
			{
				this.ResetRotation();
			}
			if(this.cameraTargetChangeResetZoom)
			{
				this.ResetZoom();
			}
		}

		public virtual void ResetRotation()
		{
			this.rotation = this.startRotation;
		}

		public virtual void ResetZoom()
		{
			this.height = this.startHeight;
		}

		private bool AllowZoom
		{
			get
			{
				return this.allowZoom &&
					(!this.cameraTargetChangeBlockZoom ||
						!this.IsCameraTargetTransition);
			}
		}

		private bool AllowRotation
		{
			get
			{
				return this.allowRotation &&
					(!this.cameraTargetChangeBlockRotation ||
						!this.IsCameraTargetTransition);
			}
		}

		void LateUpdate()
		{
			GameObject targetObject = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(targetObject != null)
			{
				Vector3 add = Vector3.zero;
				if((this.AllowRotation || this.AllowZoom) &&
					this.mouseTouch.Interacted(ref add))
				{
					add = this.mouseTouch.GetLastChange();

					if(this.AllowRotation &&
						this.AllowZoom &&
						this.limitChange)
					{
						if(Mathf.Abs(add.x) >= Mathf.Abs(add.y))
						{
							add.y = 0;
						}
						else
						{
							add.x = 0;
						}
					}

					if(this.AllowRotation)
					{
						this.rotation += add.x * this.rotationFactor;
					}
					if(this.AllowZoom)
					{
						this.height += add.y * this.zoomFactor;
					}

					if(this.rotation < -36000)
					{
						int change = (this.rotation > -36000 ?
							1 : (int)(-this.rotation / 36000)) * 36000;
						this.rotation += change;
						this.lastTargetRotation += change;
					}
					else if(this.rotation >= 36000)
					{
						int change = ((int)(this.rotation / 36000)) * 36000;
						this.rotation -= change;
						this.lastTargetRotation -= change;
					}
				}

				if(this.AllowZoom)
				{
					this.height += this.zoomAxis.GetAxis(true) * this.zoomKeyChange;
				}

				if(this.height < this.minHeight)
				{
					this.height = this.minHeight;
				}
				else if(this.height > this.maxHeight)
				{
					this.height = this.maxHeight;
				}

				float wantedHeight = targetObject.transform.position.y + this.height;
				if(this.heightDamping > 0)
				{
					this.lastTargetHeight = Mathf.Lerp(this.lastTargetHeight, wantedHeight,
						this.heightDamping * Time.deltaTime);
				}
				else
				{
					this.lastTargetHeight = wantedHeight;
				}

				Vector3 position = targetObject.transform.position - Vector3.forward * distance;
				position.y = this.lastTargetHeight;

				float targetRotation = this.rotation;
				if(this.rotationDamping > 0)
				{
					targetRotation = Mathf.Lerp(this.lastTargetRotation, this.rotation,
						this.rotationDamping * Time.deltaTime);
				}
				this.lastTargetRotation = targetRotation;

				position = VectorHelper.RotateAround(
					position, targetObject.transform.position,
					Quaternion.Euler(0, targetRotation, 0));

				this.UpdatePosition(position,
					VectorHelper.LookAt(position, targetObject.transform.position));
			}
		}
	}
}
