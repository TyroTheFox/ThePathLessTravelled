﻿
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LanguageInfoButton : BaseData
	{
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);

		[ORKEditorInfo(separator=true, labelText="Custom Skin")]
		public CustomChoiceSkin customSkin = new CustomChoiceSkin();

		public LanguageInfoButton()
		{

		}

		public LanguageInfoButton(string name)
		{
			for(int i = 0; i < this.button.Length; i++)
			{
				this.button[i].name = name;
			}
		}

		public void DataUpgrade(DataObject[] data)
		{
			if(data != null)
			{
				for(int i = 0; i < data.Length; i++)
				{
					if(i < this.button.Length)
					{
						this.button[i].SetData(data[i]);
					}
				}
			}
		}

		public ChoiceContent GetChoiceContent()
		{
			ChoiceContent content = new ChoiceContent(this.button[ORK.Game.Language].GetContent());
			customSkin.SetSkin(content);
			return content;
		}
	}
}
