
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework
{
	public class PluginSetting : BaseData
	{
		// base settings
		[ORKEditorHelp("Plugin Name", "The name of this plugin.", "")]
		[ORKEditorInfo("Plugin Settings", "The base settings of this plugin.\n" +
			"To successfully load a plugin, you need to define the name of the DLL and the namespace of the plugin.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Is Script File", "The plugin is provided as a script file, not a DLL.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isScriptFile = false;

		[ORKEditorHelp("DLL Name", "The name of the DLL assembly (without .dll extension).", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("isScriptFile", false, endCheckGroup=true)]
		public string dllName = "";

		[ORKEditorHelp("Namespace", "The namespace in which the plugin's 'Settings' class can be found.\n" +
			"Keep in mind that each plugin needs to have it's own namespace, " +
			"otherwise there will be a conflict with the settings.", "")]
		[ORKEditorInfo(expandWidth=true, callbackAfter="button:checkplugin")]
		public string nameSpace = "";


		// call settings
		[ORKEditorHelp("Use Tick", "The plugin's 'Tick' function will be called on every 'Update' tick.", "")]
		[ORKEditorInfo(separator=true, labelText="Call Settings")]
		public bool useTick = false;

		[ORKEditorHelp("Use GUI Tick", "The plugin's 'GUITick' function will be called on every 'OnGUI' tick.", "")]
		public bool useGUITick = false;

		[ORKEditorHelp("Use Scene Loaded", "The plugin's 'SceneLoaded' function will be called on when a new scene has been loaded ('SceneManager.sceneLoaded').", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool useSceneLoaded = false;


		// data
		public CorePlugin settings;

		public PluginSetting()
		{

		}

		public PluginSetting(string name)
		{
			this.name = name;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.LoadPlugin();
			if(this.settings != null)
			{
				DataObject tmp = data.GetFile("settings");
				if(tmp != null)
				{
					this.settings.SetData(tmp);
				}
			}
		}


		/*
		============================================================================
		Plugin functions
		============================================================================
		*/
		public void LoadPlugin()
		{
			if(this.nameSpace != "")
			{
				System.Object tmp = null;

				if(this.isScriptFile)
				{
					try
					{
						tmp = ReflectionTypeHandler.Instance.CreateInstance(
							ReflectionTypeHandler.Instance.SerializerGetType(
								this.nameSpace + ".Settings"));
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Plugin (" + this.name +
							") in namespace " + this.nameSpace +
							" not found:\n" + ex.StackTrace);
					}
				}
				else if(this.dllName != "")
				{
					try
					{
						Assembly assembly = Assembly.Load(this.dllName);

						if(assembly != null)
						{
							tmp = ReflectionTypeHandler.Instance.CreateInstance(
								assembly.GetType(this.nameSpace + ".Settings"));
						}
					}
					catch(System.Exception ex)
					{
						Debug.LogWarning("Plugin (" + this.name + "): Assembly (" +
							this.dllName + ") or namespace (" + this.nameSpace +
							") not found:\n" + ex.StackTrace);
					}
				}

				if(tmp is CorePlugin)
				{
					DataObject data = null;
					if(this.settings != null)
					{
						data = this.settings.GetData();
					}
					this.settings = tmp as CorePlugin;
					if(data != null)
					{
						this.settings.SetData(data);
					}
				}
			}
		}
	}
}
