
using UnityEngine;
using ORKFramework.Animations;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AnimationTypesSettings : BaseSettings
	{
		[ORKEditorInfo(hide=true)]
		public AnimationType[] data = new AnimationType[] {
			new AnimationType("Idle"),
			new AnimationType("Walk"),
			new AnimationType("Run"),
			new AnimationType("Sprint"),
			new AnimationType("Jump"),
			new AnimationType("Fall"),
			new AnimationType("Land"),
			new AnimationType("Damage"),
			new AnimationType("Evade"),
			new AnimationType("Death"),
			new AnimationType("Revive"),
			new AnimationType("Victory"),
			new AnimationType("Attack")
		};


		// default animation types
		// movement
		[ORKEditorHelp("Idle Type", "Select the animation type used for the idle animation " +
			"(i.e. when the combatant isn't moving).", "")]
		[ORKEditorInfo("Default Animation Types", "Select the animation types for the default animations used by ORK, " +
			"e.g. damage, evade, etc.\n" +
			"The default animation types are displayed in all animation types, but you only need to define them once.", "",
			ORKDataType.AnimationType, labelText="Movement Animation Types")]
		public int idleID = 0;

		[ORKEditorHelp("Walk Type", "Select the animation type used for the walk animation " +
			"(i.e. when the combatant is walking (walk speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int walkID = 1;

		[ORKEditorHelp("Run Type", "Select the animation type used for the run animation " +
			"(i.e. when the combatant is running (run speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int runID = 2;

		[ORKEditorHelp("Sprint Type", "Select the animation type used for the sprint animation " +
			"(i.e. when the combatant is sprinting (sprint speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int sprintID = 3;

		[ORKEditorHelp("Jump Type", "Select the animation type used for the jump animation " +
			"(i.e. when the combatant jumps).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int jumpID = 4;

		[ORKEditorHelp("Fall Type", "Select the animation type used for the fall animation " +
			"(i.e. when the combatant falls).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int fallID = 5;

		[ORKEditorHelp("Land Type", "Select the animation type used for the land animation " +
			"(i.e. when the combatant lands on the ground after falling).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int landID = 6;


		// battle
		[ORKEditorHelp("Action Choose Idle Type", "Select the animation type used for the idle animation when choosing an action " +
			"(e.g. when the player chooses the combatant's next action in the battle menu and isn't moving).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType, separator=true, labelText="Battle Animation Types")]
		public int actionChooseIdleID = 0;

		[ORKEditorHelp("Action Wait Idle Type", "Select the animation type used for the idle animation when waiting to perform an action " +
			"(i.e. when the combatant already chose the next action and isn't moving).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int actionWaitIdleID = 0;

		[ORKEditorHelp("Action Cast Idle Type", "Select the animation type used for the idle animation when casting an action " +
			"(i.e. when the combatant is casting an action and isn't moving).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int actionCastIdleID = 0;

		[ORKEditorHelp("Turn Ended Idle Type", "Select the animation type used for the idle animation when a combatant's turn ended " +
			"(i.e. when the combatant finished all actions).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int turnEndedIdleID = 0;

		[ORKEditorHelp("Death Type", "Select the animation type used for the death animation " +
			"(i.e. when the combatant dies).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int deathID = 9;

		[ORKEditorHelp("Revive Type", "Select the animation type used for the revive animation " +
			"(i.e. when the combatant is revived while being dead.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int reviveID = 10;

		[ORKEditorHelp("Victory Type", "Select the animation type used for the victory animation " +
			"(i.e. when the combatant wins a battle.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType, endFoldout=true)]
		public int victoryID = 11;

		public AnimationTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("damageID") && ORK.DamageTypes.Count > 0)
			{
				data.Get("damageID", ref ORK.DamageTypes.Get(0).damageAnimationTypeID);
				data.Get("criticalDamageID", ref ORK.DamageTypes.Get(0).criticalDamageAnimationTypeID);
				data.Get("evadeID", ref ORK.DamageTypes.Get(0).evadeAnimationTypeID);
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "animationTypes"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "AnimationType(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}

		public override int Count
		{
			get { return this.data.Length; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new AnimationType("New"));
			DataHelper.Added(ORKDataType.AnimationType);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.AnimationType);
			return this.data.Length - 1;
		}

		public AnimationType GetCopy(int index)
		{
			AnimationType c = new AnimationType();
			if(index >= 0 && index < this.data.Length)
			{
				c.SetData(this.data[index].GetData());
			}
			return c;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.AnimationType, index);
		}

		public AnimationType Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.AnimationType, down, index);
		}
	}
}
