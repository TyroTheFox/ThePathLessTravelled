
using UnityEngine;

namespace ORKFramework
{
	public class StatusEffectsSettings : BaseLanguageSettings
	{
		public StatusEffectSetting[] data = new StatusEffectSetting[] {new StatusEffectSetting("Default Effect")};
		
		public StatusEffectsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "statusEffects"; }
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			StatusEffectSetting newData = new StatusEffectSetting("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.StatusEffect);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			StatusEffectSetting newData = this.GetCopy(index);
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.StatusEffect);
			return this.data.Length - 1;
		}
		
		public StatusEffectSetting GetCopy(int index)
		{
			StatusEffectSetting tmp = new StatusEffectSetting();
			if(index >= 0 && index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.StatusEffect, index);
		}
		
		public StatusEffectSetting Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}
		
		public StatusEffect Create(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return new StatusEffect(index);
			}
			return null;
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.StatusEffect, down, index);
		}
		
		
		/*
		============================================================================
		Auto apply/remove functions
		============================================================================
		*/
		public void CheckAuto(Combatant c)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				this.data[i].CheckAuto(c);
			}
		}
		
		public void RegisterStatusChanges(Combatant c)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].autoApply)
				{
					for(int j=0; j<this.data[i].applyRequirement.Length; j++)
					{
						this.data[i].applyRequirement[j].RegisterStatusChanges(c, this.data[i]);
					}
				}
				if(this.data[i].autoRemove)
				{
					for(int j=0; j<this.data[i].removeRequirement.Length; j++)
					{
						this.data[i].removeRequirement[j].RegisterStatusChanges(c, this.data[i]);
					}
				}
			}
		}

		public void UnregisterStatusChanges(Combatant c)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].autoApply)
				{
					for(int j = 0; j < this.data[i].applyRequirement.Length; j++)
					{
						this.data[i].applyRequirement[j].UnregisterStatusChanges(c, this.data[i]);
					}
				}
				if(this.data[i].autoRemove)
				{
					for(int j = 0; j < this.data[i].removeRequirement.Length; j++)
					{
						this.data[i].removeRequirement[j].UnregisterStatusChanges(c, this.data[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "StatusEffect " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].GetDescription();
			}
			else
			{
				return "StatusEffect " + index + " not found";
			}
		}
		
		public override Texture GetIcon(int index)
		{
			Texture tex = null;
			
			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}
	}
}
