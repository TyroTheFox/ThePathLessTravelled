
using UnityEngine;

namespace ORKFramework
{
	public class BattleEndSettings : BaseSettings
	{
		// general settings
		// experience
		[ORKEditorHelp("Split Experience Rewards", "The experience points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the experience.", "")]
		[ORKEditorInfo("Base Settings", "Define the experience and normal status value gain options.", "",
			labelText="Experience Reward Settings")]
		public bool splitExp = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive experience.\n" +
			"If the experience is splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyExp = false;

		[ORKEditorHelp("Dead Receive Exp.", "Dead group members will also receive experience.\n" +
			"If disabled, only group members who are alive will receive experience.", "")]
		public bool deadExp = false;

		// normal
		[ORKEditorHelp("Split Normal Rewards", "The 'Normal' status value points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the 'Normal' status value reward.", "")]
		[ORKEditorInfo(separator=true, labelText="Normal Status Value Reward Settings")]
		public bool splitNormalSV = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive 'Normal' status value rewards.\n" +
			"If the 'Normal' status value rewards are splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyNormalSV = false;

		[ORKEditorHelp("Dead Receive Normal", "Dead group members will also receive 'Normal' status value rewards.\n" +
			"If disabled, only group members who are alive will receive 'Normal' status value rewards.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool deadNormalSV = false;


		// victory gains
		[ORKEditorInfo("Victory Gain Notification", "The text for the spoils of a battle are defined here.\n" +
			"The order of the single notifications can be changed by changing the total gains text.\n" +
			"All spoils will be displayed in one message.", "",
			endFoldout=true)]
		public BattleGainsText victoryGains = new BattleGainsText();


		// combatant gains
		[ORKEditorInfo("Combatant Gain Notification", "The text for an individual combatant's spoils of a battle are defined here.\n" +
			"The order of the single notifications can be changed by changing the total gains text.\n" +
			"All spoils will be displayed in one message per combatant.", "",
			endFoldout=true)]
		public CombatantGainsText combatantGains = new CombatantGainsText();


		// level up
		[ORKEditorInfo("Level Up Notification", "The notification shown when a combatant's level increases.\n" +
			"The order of the single notifications can be changed by changing the total level up text.\n" +
			"All texts will be displayed in one message.", "",
			endFoldout=true)]
		public LevelUpText levelUp = new LevelUpText();

		public BattleEndSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("showGains"))
			{
				this.victoryGains.SetData(data);
				this.levelUp.SetData(data);
			}
			if(data.Contains<DataObject>("end"))
			{
				DataObject tmpData = data.GetFile("end");
				if(tmpData != null)
				{
					tmpData.Get("guiBoxID", ref this.victoryGains.guiBoxID);
					bool tmp = false;
					tmpData.Get("useLevelUpBox", ref tmp);
					if(tmp)
					{
						tmpData.Get("levelUpBoxID", ref this.combatantGains.guiBoxID);
						this.levelUp.guiBoxID = this.combatantGains.guiBoxID;
					}
					else
					{
						this.combatantGains.guiBoxID = this.victoryGains.guiBoxID;
						this.levelUp.guiBoxID = this.victoryGains.guiBoxID;
					}

					data.Get("useTitle", ref this.victoryGains.useTitle);
					if(this.victoryGains.useTitle)
					{
						data.Get("title", ref this.victoryGains.title);
						this.combatantGains.useTitle = true;
						data.Get("title", ref this.combatantGains.title);
						this.levelUp.useTitle = true;
						data.Get("title", ref this.levelUp.title);
					}
				}
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleEnd"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
