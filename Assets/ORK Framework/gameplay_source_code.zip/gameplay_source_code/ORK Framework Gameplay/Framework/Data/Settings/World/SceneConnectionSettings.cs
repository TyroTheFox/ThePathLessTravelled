
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SceneConnectionSettings : BaseSettings
	{
		[ORKEditorHelp("Connection Path Search", "Select how many paths are searched:\n" +
			"- One: The first found path will be used.\n" +
			"- Multi: All (unique) paths with the same number of scenes will be used.\n" +
			"- All: All (unique) paths will be used.", "")]
		[ORKEditorInfo("General Settings", "General scene connection and path settings.", "", endFoldout=true)]
		public SceneConnectionSearch connectionSearch = SceneConnectionSearch.One;

		// added data
		[ORKEditorInfo("Scene Connections", "Add scene connection information manually.\n" +
			"The manually added connection information wont be lost when scanning the scenes.\n" +
			"Scene connection information is used to find the correct way to a marker in navigation HUDs.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Scene Connection", "Adds scene connection information.", "",
			"Remove", "Removes this scene connection.", "", foldout=true, foldoutText=new string[] {
			"Scene Connection", "The name and connection data of the scene.", ""
		})]
		public SceneConnection[] connections = new SceneConnection[0];


		// scanned data
		[ORKEditorInfo(hide=true)]
		[ORKEditorArray(isRemove=true, removeText=new string[] {"Remove", "Removes this scanned scene.", ""},
			foldout=true, foldoutText=new string[] {"Scanned Scene", "The scene changers found in this scene.", ""})]
		public SceneConnection[] scannedConnections;

		public SceneConnectionSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "sceneConnections"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Navigation functions
		============================================================================
		*/
		public bool Find(string currentScene, string targetScene, NavigationMarker marker)
		{
			bool found = false;
			Dictionary<string, List<SceneConnectionSceneChanger>> list = this.CreateSceneList();

			if(list.ContainsKey(currentScene))
			{
				List<SceneConnectionSceneChanger> originalChangers = list[currentScene];
				list.Remove(currentScene);

				Dictionary<int, List<string>> tmp = new Dictionary<int, List<string>>();
				Dictionary<int, List<string>> tmp2;

				for(int i = 0; i < originalChangers.Count; i++)
				{
					if(originalChangers[i].variableCondition.CheckVariables() &&
						originalChangers[i].questCondition.Check())
					{
						bool found2 = false;
						List<string> scenes = new List<string>();
						if(originalChangers[i].CheckTargets(targetScene, ref scenes))
						{
							marker.AddPosition(originalChangers[i].position);

							if(SceneConnectionSearch.One == this.connectionSearch)
							{
								return true;
							}
							else
							{
								found = true;
								found2 = true;
							}
						}
						if(!found2 && scenes.Count > 0)
						{
							tmp.Add(i, scenes);
						}
					}
				}

				while((SceneConnectionSearch.All == this.connectionSearch || !found) &&
					tmp.Count > 0)
				{
					List<string> removeList = new List<string>();
					tmp2 = new Dictionary<int, List<string>>();

					foreach(KeyValuePair<int, List<string>> pair in tmp)
					{
						bool found2 = false;
						List<string> scenes = new List<string>();
						if(this.CheckScene(pair.Value, targetScene, ref list, ref scenes))
						{
							marker.AddPosition(originalChangers[pair.Key].position);

							if(SceneConnectionSearch.One == this.connectionSearch)
							{
								return true;
							}
							else
							{
								found = true;
								found2 = true;
							}
						}
						if(!found2 && scenes.Count > 0)
						{
							tmp2.Add(pair.Key, scenes);
						}
						removeList.AddRange(pair.Value);
					}

					for(int i = 0; i < removeList.Count; i++)
					{
						list.Remove(removeList[i]);
					}

					tmp = tmp2;
				}
			}
			return found;
		}

		private bool CheckScene(List<string> currentScene, string targetScene,
			ref Dictionary<string, List<SceneConnectionSceneChanger>> list, ref List<string> scenes)
		{
			for(int i = 0; i < currentScene.Count; i++)
			{
				if(list.ContainsKey(currentScene[i]))
				{
					List<SceneConnectionSceneChanger> sceneChangers = list[currentScene[i]];

					for(int j = 0; j < sceneChangers.Count; j++)
					{
						if(sceneChangers[j].variableCondition.CheckVariables() &&
							sceneChangers[j].questCondition.Check() &&
							sceneChangers[j].CheckTargets(targetScene, ref scenes))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		private Dictionary<string, List<SceneConnectionSceneChanger>> CreateSceneList()
		{
			Dictionary<string, List<SceneConnectionSceneChanger>> list = new Dictionary<string, List<SceneConnectionSceneChanger>>();

			for(int i = 0; i < this.connections.Length; i++)
			{
				if(list.ContainsKey(this.connections[i].sceneName))
				{
					list[this.connections[i].sceneName].AddRange(this.connections[i].sceneChanger);
				}
				else
				{
					list.Add(this.connections[i].sceneName,
						new List<SceneConnectionSceneChanger>(this.connections[i].sceneChanger));
				}
			}
			if(this.scannedConnections != null)
			{
				for(int i = 0; i < this.scannedConnections.Length; i++)
				{
					if(list.ContainsKey(this.scannedConnections[i].sceneName))
					{
						list[this.scannedConnections[i].sceneName].AddRange(this.scannedConnections[i].sceneChanger);
					}
					else
					{
						list.Add(this.scannedConnections[i].sceneName,
							new List<SceneConnectionSceneChanger>(this.scannedConnections[i].sceneChanger));
					}
				}
			}

			return list;
		}
	}
}
